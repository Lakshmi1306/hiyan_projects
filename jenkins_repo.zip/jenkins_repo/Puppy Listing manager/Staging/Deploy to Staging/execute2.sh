#!/bin/sh

######
## BUILD/TEST
######
rm -R ./jenkinsbuilddir/ > /dev/null 2>&1

# Prepare build environment (dont change this, workaround to prevent stderr)
mkdir -p ../jenkinsbuilddir
cp -R . ../jenkinsbuilddir/
mv ../jenkinsbuilddir ./
cd ./jenkinsbuilddir

# Update required libs
npm cache clear
npm install
bower install


# Run Unit Tests
#ember test --reporter=xunit --silent
#UNITTESTS="$(ember test --silent)"
#UNITTESTS="$(ember test --reporter=xunit --silent)"
#${UNITTESTS} > ../results.xml
ember test > ../results.tap

# Check Unit Test Status AFTER we've injected the environment variables
#if echo "${UNITTESTS}" | grep -q 'failures="0"'; then
#if echo "${UNITTESTS}" | grep -q '# fail  0'; then
#    echo "-----Unit Tests PASSED!:: "
#    echo "${UNITTESTS}"
#else
#	echo "-----Unit Tests FAILED!:: "
#    echo "${UNITTESTS}"
#    exit 1
#fi

