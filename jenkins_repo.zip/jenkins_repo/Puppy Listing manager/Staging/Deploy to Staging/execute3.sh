######
## DEPLOYMENT
######
cd ./jenkinsbuilddir


LOWERCASE_ENV="$(echo ${Environment} | tr '[:upper:]' '[:lower:]' 2>&1)"
#echo "host = http\://${LOWERCASE_ENV}" > host.properties


export ASSETS_AWS_KEY="AKIAIWZOKYJBDNKWNQIA"
export ASSETS_AWS_SECRET="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"
export ASSETS_REGION="us-west-2"

if echo "${Environment}" | grep -q "Stage-01"; then
	CORE_API_HOST="https://api-stage-01.puppyspot.com"
	S3_DOMAIN="plm-stage-01.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage01/leadtracker/";
    CONSUMER_DOMAIN="https://consumer-stage-01.puppyspot.com";
    CLOUDSEARCH_PLM_DOMAIN="https://search-stage-01-plm-listings-bqw5yjpz24z5333cwq6mzsbcuu.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "Stage-02"; then
    CORE_API_HOST="https://api-stage-02.puppyspot.com"
	S3_DOMAIN="plm-stage-02.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage-02.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage02/leadtracker/";
    CLOUDSEARCH_PLM_DOMAIN="https://jenkins.puppyspot.com/job/Puppy%20Listings%20Manager/job/Staging/job/Deploy%20to%20Staging/configure";
fi

if echo "${Environment}" | grep -q "Stage-03"; then
    CORE_API_HOST="https://api-stage-03.puppyspot.com"
	S3_DOMAIN="plm-stage-03.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage-03.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage03/leadtracker/";
    CLOUDSEARCH_PLM_DOMAIN="https://search-stage-03-plm-listings-o56mbd5vglzj45na7mo4hs4sam.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "Stage-04"; then
    CORE_API_HOST="https://api-stage-04.puppyspot.com"
	S3_DOMAIN="plm-stage-04.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage-04.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage04/leadtracker/";
    CLOUDSEARCH_PLM_DOMAIN="https://search-stage-04-plm-listings-7ms7yuoadfm36rw4fhc7zvka4a.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "Stage-05"; then
    CORE_API_HOST="https://api-stage-05.puppyspot.com"
	S3_DOMAIN="plm-stage-05.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage-05.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage05/leadtracker/";
    CLOUDSEARCH_PLM_DOMAIN="https://search-stage-05-plm-listings-zjyqfzomcbrmbggltd567b52am.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "sandbox"; then
    CORE_API_HOST="https://api-sandbox.puppyspot.com"
	S3_DOMAIN="plm-sandbox.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-sandbox.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.sandbox/leadtracker/";
    CLOUDSEARCH_PLM_DOMAIN="https://search-sandbox-plm-listings-kgm4cwkwhvia2niou2f6l5wgfe.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "Eng-01"; then
    CORE_API_HOST="https://api-eng-01.puppyspot.com"
	S3_DOMAIN="plm-eng-01.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-eng-01.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage01/leadtracker/";
    CLOUDSEARCH_PLM_DOMAIN="https://search-eng-01-plm-listings-twdyveueooo6vu25ijuk3fwfwy.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "Eng-02"; then
    CORE_API_HOST="https://api-eng-02.puppyspot.com"
	S3_DOMAIN="plm-eng-02.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-eng-02.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage02/leadtracker/";
    CLOUDSEARCH_PLM_DOMAIN="https://search-eng-02-plm-listings-vn4xi6cno6fr3ag5ilcecimmcq.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "green"; then
    CORE_API_HOST="https://api-green.puppyspot.com"
	S3_DOMAIN="plm-green.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-green.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.green/leadtracker/";
    CLOUDSEARCH_PLM_DOMAIN="https://search-green-plm-listings-ravxksmeq5wc6gvsg2ziav6cna.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "Old-UAT"; then
	CORE_API_HOST="https://api-uat-stage.puppyspot.com"
	S3_DOMAIN="uat-stage.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.uat/leadtracker/";
    CLOUDSEARCH_PLM_DOMAIN="https://search-stage-uat-plm-listings-fiawdwx43wj4exfgds5xrbkqn4.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "UAT-Stage"; then
	CORE_API_HOST="https://api-uat.puppyspot.com"
	S3_DOMAIN="plm-uat-stage.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-uat.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.uat/leadtracker/";
    CLOUDSEARCH_PLM_DOMAIN="https://search-uat-plm-listings-g3tvmwze6vncapha5n2vkovpcy.us-west-2.cloudsearch.amazonaws.com";
fi

export SEARCH_HOST="${CLOUDSEARCH_PLM_DOMAIN}"
export ASSETS_BUCKET="${S3_DOMAIN}"
export CONSUMER_DOMAIN="${CONSUMER_DOMAIN}"
export API_HOST="${CORE_API_HOST}"
export LEADTRACKER_HOST="${LEADTRACKER_DOMAIN}";

ember deploy stage --verbose