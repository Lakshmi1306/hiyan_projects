######
## DEPLOYMENT
######
cd ./jenkinsbuilddir

export API_HOST="https://api.puppyspot.com"
export ASSETS_AWS_KEY="AKIAIWZOKYJBDNKWNQIA"
export ASSETS_AWS_SECRET="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"
export ASSETS_BUCKET="plm.puppyspot.com"
export ASSETS_REGION="us-west-2"

ember deploy production --verbose