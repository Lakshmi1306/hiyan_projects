#!/bin/sh
### Merge PR for ${Branch} into master

PRS="$(php ~/jenkinsgit/jenkinsgit.php -rPAM --merge-pull-request --source="${Branch}" --dest="master" 2>&1)"
if echo "${PRS}" | grep -q "^success$"; then
    echo "Pull request merged successfully, continuing:: "
else
	echo "ERROR: The pull request failed to merge:: "
    echo "${PRS}"
    echo "failures = ERROR: The pull request failed to merge" > failures.properties
    exit 1
fi