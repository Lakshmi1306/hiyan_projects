#!/bin/sh


######
## DEPLOYMENT
######

Environment="sandbox"

BUILD_TIMESTAMP=`date +"%Y-%m-%d %T"`
LOWERCASE_ENV="$(echo ${Environment} | tr '[:upper:]' '[:lower:]' 2>&1)"

APP_ENVIRONMENT="CC-${Environment}"
SQS_PREFIX="${Environment}"
MEMCACHED_HOST="api-${LOWERCASE_ENV}"
CORE_API_HOST="api-${LOWERCASE_ENV}.puppyspot.com"
LEGACY_HOST="https://www.puppyspot.preprod"

if echo "${Environment}" | grep -q "Stage-01"; then
	CLOUDSEARCH_BREED_DOMAIN="doc-stage-01-breeds-gcnfcfavsorqaakmxavke6aorq.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="doc-stage-01-external-listings-fuogjcvfjbitpr2ivt2wqzmcg4.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="doc-stage-01-internal-listings-e67njuiw6amboix7azmpxzqr4m.us-west-2.cloudsearch.amazonaws.com"
   CLOUDSEARCH_PLM_LISTING_DOMAIN="doc-stage-01-plm-listings-bqw5yjpz24z5333cwq6mzsbcuu.us-west-2.cloudsearch.amazonaws.com"
	RDS_HOST="api-stage-01.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com"
fi

if echo "${Environment}" | grep -q "Stage-02"; then
	CLOUDSEARCH_BREED_DOMAIN="doc-stage-02-breeds-xm32sklifupefp3dlmal6ho7my.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="doc-stage-02-external-listings-ime4r67rr45yxu7cc6slejishq.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="doc-stage-02-internal-listings-xrenjw2iphhquc6jprakuthgny.us-west-2.cloudsearch.amazonaws.com"
   CLOUDSEARCH_PLM_LISTING_DOMAIN="doc-stage-02-plm-listings-y62silmnqa2hm6noqcegx46nti.us-west-2.cloudsearch.amazonaws.com"
	RDS_HOST="api-stage-02.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com"
fi

if echo "${Environment}" | grep -q "Stage-03"; then
	CLOUDSEARCH_BREED_DOMAIN="doc-stage-03-breeds-mfriu2eide3jb4vialcozgsdje.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="doc-stage-03-external-listings-skc6hcfdruiii5igjzd47ona6u.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="doc-stage-03-internal-listings-aqjfrblh42pbcfj2nhn6hjzi54.us-west-2.cloudsearch.amazonaws.com"
   CLOUDSEARCH_PLM_LISTING_DOMAIN="doc-stage-03-plm-listings-o56mbd5vglzj45na7mo4hs4sam.us-west-2.cloudsearch.amazonaws.com"
	RDS_HOST="api-stage-03.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com"
fi

if echo "${Environment}" | grep -q "Stage-04"; then
	CLOUDSEARCH_BREED_DOMAIN="doc-stage-04-breeds-3y2w2tmdiwpv2b34sbajdws2im.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="doc-stage-04-external-listings-tdzyorlwyhwiqyx4xh7uhgjjji.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="doc-stage-04-internal-listings-oq7kpifmo45xymlajdvwctu2c4.us-west-2.cloudsearch.amazonaws.com"
   CLOUDSEARCH_PLM_LISTING_DOMAIN="doc-stage-04-plm-listings-7ms7yuoadfm36rw4fhc7zvka4a.us-west-2.cloudsearch.amazonaws.com"
	RDS_HOST="api-stage-04.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com"
fi

if echo "${Environment}" | grep -q "sandbox"; then
	CLOUDSEARCH_BREED_DOMAIN="doc-sandbox-breeds-bgevdx3nv6wsadxral76epzs4y.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="doc-sandbox-external-listings-x72sgxnllt3u3j5bg3m5elgxnu.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="doc-sandbox-internal-listings-ruwg5nvy37xrmik7w7jyhoui2q.us-west-2.cloudsearch.amazonaws.com"
    CLOUDSEARCH_PLM_LISTING_DOMAIN="doc-prod-plm-listings-ocaszg37jivvujwpwaaypxkr2q.us-west-2.cloudsearch.amazonaws.com"
	RDS_HOST="api-sandbox.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com"
fi

if echo "${Environment}" | grep -q "UAT"; then
	CLOUDSEARCH_BREED_DOMAIN="doc-uat-breeds-m644j5gi2as3l3vppb267dpk4i.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="doc-uat-external-listings-6q5p6pssdrc5df46s65a3gdfei.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="doc-uat-internal-listings-z62lvb6gnvvzzabfkstvzzhrla.us-west-2.cloudsearch.amazonaws.com"
   CLOUDSEARCH_PLM_LISTING_DOMAIN="doc-uat-plm-listings-g3tvmwze6vncapha5n2vkovpcy.us-west-2.cloudsearch.amazonaws.com"
	RDS_HOST="api-uat.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com"
fi

if echo "${Environment}" | grep -q "Eng-01"; then
	CLOUDSEARCH_BREED_DOMAIN="doc-eng-01-breeds-hsxjoa3yqj5qj3gvodaiypozae.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="doc-eng-01-external-listings-xcdux6mnfxtpp57aosqfxq6tr4.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="doc-eng-01-internal-listings-wirqszbhcno4p3yuxy6cnouavq.us-west-2.cloudsearch.amazonaws.com"
   CLOUDSEARCH_PLM_LISTING_DOMAIN="doc-eng-01-plm-listings-twdyveueooo6vu25ijuk3fwfwy.us-west-2.cloudsearch.amazonaws.com"
	RDS_HOST="api-eng-01.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com"
fi

if echo "${Environment}" | grep -q "Eng-02"; then
	CLOUDSEARCH_BREED_DOMAIN="doc-eng-02-breeds-4lugrdaga7va7k2r36xsma5hiu.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="doc-eng-02-external-listings-aezr7dmbz5qu2imq6kkdm5dawi.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="doc-eng-02-internal-listings-g7n2cjj52b3cw6ag4xagx73bye.us-west-2.cloudsearch.amazonaws.com"
   CLOUDSEARCH_PLM_LISTING_DOMAIN="doc-eng-02-plm-listings-vn4xi6cno6fr3ag5ilcecimmcq.us-west-2.cloudsearch.amazonaws.com"
	RDS_HOST="api-eng-02.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com"
fi

if echo "${Environment}" | grep -q "green"; then
	CLOUDSEARCH_BREED_DOMAIN="doc-green-breeds-dtx3xbowqzoxf4vfdw2fclh3by.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="doc-green-external-listings-shlb3zr3o3aqhsey7pz37ym2ny.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="doc-green-internal-listings-gw2cl2o7fdkkr7yxtu3sw34ldm.us-west-2.cloudsearch.amazonaws.com"
   CLOUDSEARCH_PLM_LISTING_DOMAIN="doc-green-plm-listings-ravxksmeq5wc6gvsg2ziav6cna.us-west-2.cloudsearch.amazonaws.com"
	RDS_HOST="api-green.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com"
fi


if echo "${Environment}" | grep -q "Admin-stage"; then
	LOWERCASE_ENV="stage"
	APP_ENVIRONMENT="${Environment}"
    SQS_PREFIX="UAT"
    MEMCACHED_HOST="uat-stage"
    CORE_API_HOST="api-uat-stage.puppyspot.com"
	CLOUDSEARCH_BREED_DOMAIN="doc-stage-breeds-fgmuuzvp7uyijmv4yk5mvtfzxi.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="doc-search-uat-external-listings-f5mybnaai3epbkupov2yhl27ze.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="doc-search-uat-internal-listings-yukkzkayeddwnbvkvq4kwcnmba.us-west-2.cloudsearch.amazonaws.com"
    CLOUDSEARCH_PLM_LISTING_DOMAIN="doc-stage-plm-listings-b5lmnvahy26vskip63aosx7i3i.us-west-2.cloudsearch.amazonaws.com"
	RDS_HOST="uat-stage.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com"
fi

AWS_SUFFIX="${LOWERCASE_ENV}"
CONSUMER_HOST="consumer-${LOWERCASE_ENV}"


# Add the .env Params:
echo "\n\nAWS_LOW_PRIORITY_JOB_QUEUE=${SQS_PREFIX}-Low-Priority-Queue\nAWS_LOW_PRIORITY_JOB_DLQ=${SQS_PREFIX}-Low-Priority-DLQ\nAWS_JOB_QUEUE=${SQS_PREFIX}-Job-Queue\nAWS_JOB_DLQ=${SQS_PREFIX}-Job-DLQ\nAWS_MAIL_QUEUE=${SQS_PREFIX}-Mail-Queue\nAWS_MAIL_DLQ=${SQS_PREFIX}-Mail-DLQ\nAWS_SEARCH_UPDATE_JOB_QUEUE=${SQS_PREFIX}-Search-Update-Job-Queue\nAWS_SEARCH_UPDATE_JOB_DLQ=${SQS_PREFIX}-Search-Update-Job-DLQ\n" >> .env.staging
echo "\nMEMCACHED_HOST=${MEMCACHED_HOST}.bjszcv.0001.usw2.cache.amazonaws.com\nMEMCACHED_PORT=11211\n" >> .env.staging
echo "\nCORE_API_BASE_URI=https://${CORE_API_HOST}\n" >> .env.staging
echo "\nLEGACY_CONTACT_BASE_URL=${LEGACY_HOST}/api/core/contact/\n" >> .env.staging
echo "\nRDS_HOSTNAME=${RDS_HOST}\nRDS_DB_NAME=ebdb\nRDS_PASSWORD=pbbsecret\nRDS_PORT=3306\nRDS_USERNAME=pbbadmin\n" >> .env.staging
echo "\nRDS_READ_REPLICA_HOSTNAME=${RDS_HOST}\nRDS_READ_REPLICA_DB_NAME=ebdb\nRDS_READ_REPLICA_PASSWORD=pbbsecret\nRDS_READ_REPLICA_PORT=3306\nRDS_READ_REPLICA_USERNAME=pbbadmin\n" >> .env.staging
echo "\nAWS_MEDIA_BUCKET=puppyspot-photos-${AWS_SUFFIX}\nAWS_BREEDER_BUCKET=puppyspot-breeder-uploads-${AWS_SUFFIX}\n" >> .env.staging
echo "\nCONSUMER_SITE_BASE_URL=https://${CONSUMER_HOST}.39u6rtyj29.us-west-2.elasticbeanstalk.com\n" >> .env.staging
echo "\nCLOUDSEARCH_BREED_DOMAIN=${CLOUDSEARCH_BREED_DOMAIN}\n" >> .env.staging


git add .env.staging


# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Staging only configuration files in
cp -R .elasticbeanstalk/extensions/staging/* ./.ebextensions/

sed -i 's/<---StageNameREPLACE-->/'"${APP_ENVIRONMENT}"'/g' .ebextensions/* > /dev/null

git add .ebextensions/*
git commit -m "Pre-deploy commit"

#
# Check if environment exists. If not, create it..
#
if eb status CC-${Environment} | grep -q "ERROR: NotFoundError"; then
    echo "Environment \"${APP_ENVIRONMENT}\" does not exist. Creating... Expect 20 minute wait.\n";
    DEPLOYMENT="$(eb create ${APP_ENVIRONMENT} --cfg stage --timeout 30 2>&1)"
    if echo "${DEPLOYMENT}" | grep -q "Successfully launched environment"; then
        echo "Deployment+Creation SUCCEEDED!:: "
        echo "${DEPLOYMENT}"
    else
	    echo "Deployment+Creation FAILED!:: "
        echo "${DEPLOYMENT}"
        exit 1
    fi
    return;
fi

#
# Environment already exists. Just Deploy
#

eb use ${APP_ENVIRONMENT}
MYHOST=$(eb status ${APP_ENVIRONMENT} | grep "  CNAME: " | cut -f2 -d: | cut -f2 -d' ');

echo "host = http\://${MYHOST}" > host.properties

DEPLOYMENT="$(eb deploy 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "Deployment SUCCEEDED!:: "
    echo "${DEPLOYMENT}"
else
	echo "Deployment FAILED!:: "
    echo "${DEPLOYMENT}"
    exit 1
fi