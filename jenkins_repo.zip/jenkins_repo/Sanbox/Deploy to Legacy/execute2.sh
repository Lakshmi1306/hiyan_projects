#!/bin/bash

######
## DEPLOYMENT
######

Environment="Legacy-sandbox"

# Prepare build environment (dont change this, workaround to prevent stderr)
mkdir -p ../jenkinsbuilddir
cp -R . ../jenkinsbuilddir/
mv ../jenkinsbuilddir ./
cd ./jenkinsbuilddir
cp -R legacy-beanstalk/. ./

# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Etl-Staging configuration files in
cp -R .elasticbeanstalk/extensions/staging/* ./.ebextensions/

DOMAIN_SUFFIX="dev"

if echo "${Environment}" | grep -q "Legacy-Stage-01"; then
    DOMAIN_SUFFIX="stage01"
fi

if echo "${Environment}" | grep -q "Legacy-Stage-02"; then
    DOMAIN_SUFFIX="stage02"
fi

if echo "${Environment}" | grep -q "Legacy-Stage-03"; then
    DOMAIN_SUFFIX="stage03"
fi

if echo "${Environment}" | grep -q "Legacy-Stage-04"; then
    DOMAIN_SUFFIX="stage04"
fi

if echo "${Environment}" | grep -q "Legacy-sandbox"; then
    DOMAIN_SUFFIX="sandbox"
fi

if echo "${Environment}" | grep -q "Legacy-Eng-01"; then
    DOMAIN_SUFFIX="eng01"
fi

if echo "${Environment}" | grep -q "Legacy-Eng-02"; then
    DOMAIN_SUFFIX="eng02"
fi

if echo "${Environment}" | grep -q "Legacy-green"; then
    DOMAIN_SUFFIX="green"
fi

if echo "${Environment}" | grep -q "Legacy-UAT"; then
    DOMAIN_SUFFIX="uat"
fi

sed -i 's/DOMAIN_SUFFIX/'"${DOMAIN_SUFFIX}"'/g' .ebextensions/* > /dev/null
sed -i 's/DOMAIN_SUFFIX/'"${DOMAIN_SUFFIX}"'/g' .ebextensions/post-deploy/* > /dev/null
sed -i 's/DOMAIN_SUFFIX/'"${DOMAIN_SUFFIX}"'/g' .ebextensions/post-deploy/httpd/* > /dev/null
sed -i 's/DOMAIN_SUFFIX/'"${DOMAIN_SUFFIX}"'/g' .ebextensions/post-deploy/httpd.sh > /dev/null

rename 's/DOMAIN_SUFFIX/'"${DOMAIN_SUFFIX}"'/' .ebextensions/post-deploy/httpd/* > /dev/null


rm -R */.git
rm -R */*/.git
rm -R */*/*/.git

git init
git add -A
git add .ebextensions/*
HACKYFIXFORSTDERR="$(git commit -m "Pre-deploy Staging commit" 2>&1)"

#
# Check if environment exists. If not, create it..
#
if eb status ${Environment} | grep -q "ERROR: Environment \"${Environment}\" not Found."; then
    echo "Environment \"${Environment}\" does not exist. Creating... Expect 20 minute wait.\n";
    DEPLOYMENT="$(eb create ${Environment} --cfg stage --timeout 30 2>&1)"
    if echo "${DEPLOYMENT}" | grep -q "Successfully launched environment"; then
        echo "Deployment+Creation SUCCEEDED!:: "
        echo "${DEPLOYMENT}"
    else
	    echo "Deployment+Creation FAILED!:: "
        echo "${DEPLOYMENT}"
        exit 1
    fi
    return;
fi

#
# Environment already exists. Just Deploy
#

eb use ${Environment}
MYHOST=$(eb status ${Environment} | grep "  CNAME: " | cut -f2 -d: | cut -f2 -d' ');

echo "host = http\://${MYHOST}" > host.properties

DEPLOYMENT="$(eb deploy 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "Deployment SUCCEEDED!:: "
    echo "${DEPLOYMENT}"
else
	echo "Deployment FAILED!:: "
    echo "${DEPLOYMENT}"
    exit 1
fi