#!/bin/sh
#
# Check if environment is Ready. If not, abort.. (Only if environment exists. If it doesn't, it will be created later)
#

Environment="sandbox"

if eb status API-${Environment} | grep -q "Status: Ready"; then
    # Environment exists and is ready
    if ${Rebuild} == true; then
        MYHOST=$(eb status API-${Environment} | grep "  CNAME: " | cut -f2 -d: | cut -f2 -d' ');
        if [ -z "${MYHOST}" ]; then
            echo "ERROR: Cannot determine beanstalk host to rebuild database from: ${MYHOST}";
            exit 0;
        fi
    
        RESULTS=$(ssh -t -t -oStrictHostKeyChecking=no -oUserKnownHostsFile=/dev/null ec2-user@${MYHOST} 'mysql -h ${RDS_HOSTNAME} -u ${RDS_USERNAME} -p${RDS_PASSWORD} -v -e "drop database ${RDS_DB_NAME}; create database ${RDS_DB_NAME};"')

        if echo "${RESULTS}" | grep -q "ERROR"; then
            echo "Error clearing database: ${RESULTS}";
            exit 0
        else
            echo "----- Successfully cleared existing database for rebuild!";
        fi
    fi
    exit 1
else
    if eb status API-${Environment} | grep -q "ERROR: NotFoundError"; then
    	# Nothing to do. Environment doesn't exist, but will be created later during deployment.
        echo "This is the status:"
        echo "$(eb status API-${Environment})"
        exit 1
    else
	echo "Environment \"API-${Environment}\" NOT Ready. Aborting!\n";
    	exit 0
    fi
fi