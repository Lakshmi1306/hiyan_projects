#!/bin/sh

#############
## Production
#############

git rm --cached .elasticbeanstalk/config.yml

# Set env vars to be appropriate for load environment
cp .env.production-load .env.production
cp .env.production-load .env.staging
git add .env.production


# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Production only configuration files in
if [ -d ".elasticbeanstalk/extensions/load" ]; then
    cp -R .elasticbeanstalk/extensions/load/* ./.ebextensions/
fi

git add public/. --force
git add .ebextensions/*
HACKYFIXFORSTDERR="$(git commit -m "Pre-deploy PROD commit" 2>&1)"