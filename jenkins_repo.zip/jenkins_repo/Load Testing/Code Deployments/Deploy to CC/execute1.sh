#!/bin/sh

#############
## Production
#############

git rm --cached .elasticbeanstalk/config.yml

# Update required libs
composer update
composer dumpautoload

# Update required libs
npm cache clear
npm install

# Do frontend build
npm run production

# Copy Compiled assets
cp -R public/* ../public/


cp .env.production-load .env.production
cp .env.production-load .env.staging

git add .env.production

# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Production only configuration files in
if [ -d ".elasticbeanstalk/extensions/load" ]; then
    cp -R .elasticbeanstalk/extensions/load/* ./.ebextensions/
fi

git add public/. --force
git add .ebextensions/*
HACKYFIXFORSTDERR="$(git commit -m "Pre-deploy LOAD commit" 2>&1)"