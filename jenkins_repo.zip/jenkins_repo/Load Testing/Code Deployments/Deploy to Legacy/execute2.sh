#!/bin/bash

######
## DEPLOYMENT
######

# Prepare build environment (dont change this, workaround to prevent stderr)
mkdir -p ../jenkinsbuilddir
cp -R . ../jenkinsbuilddir/
mv ../jenkinsbuilddir ./
cd ./jenkinsbuilddir
cp -R legacy-beanstalk/. ./

# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Production only configuration files in
cp -R .elasticbeanstalk/extensions/load/* ./.ebextensions/

rm -R */.git
rm -R */*/.git
rm -R */*/*/.git

git init
git add -A
HACKYFIXFORSTDERR="$(git commit -m "Pre-deploy LOAD commit" 2>&1)"


eb use "legacy-load"
DEPLOYMENT="$(eb deploy --timeout 15 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "Pre-Production Deployment SUCCEEDED!:: "
else
	echo "Pre-Production Deployment FAILED!:: "
    echo "failures = Production Deployment FAILED" > failures.properties
    echo "eb deploy output: $DEPLOYMENT"
    exit 1
fi