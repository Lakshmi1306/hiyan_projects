#!/bin/sh

#############
## Worker
#############

# Empty ebextensions directory
rm -R .ebextensions
# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Worker only configuration files in
if [ -d ".elasticbeanstalk/extensions/worker_load" ]; then
    cp -R .elasticbeanstalk/extensions/worker_load/* ./.ebextensions/
fi
git add .ebextensions/*
git rm .ebextensions/newrelic.config
git commit -m "Pre-deploy Worker commit" --amend