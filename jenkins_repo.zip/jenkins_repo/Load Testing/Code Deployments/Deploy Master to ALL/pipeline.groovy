pipeline {
    agent any
    stages {
		stage ('Deploy Master to Worker') {
			steps {
				build job: 'Deploy Master To Worker'
			}
		}
		stage ('Deploy Master to API') {
			steps {
				build job: 'Deploy Master To API'
			}
		}
		stage ('Deploy Master to Consumer') {
			steps {
				build job: 'Deploy Master To Consumer'
			}
		}
		stage ('Deploy Master to CC') {
			steps {
				build job: 'Deploy Master To CC'
			}
		}
		stage ('Deploy Master to Legacy') {
			steps {
				build job: 'Deploy Master To Legacy'
			}
		}
    }
    post {
		cleanup {
			deleteDir()
		}
    }
}
