#!/bin/sh

#############
## Worker
#############

eb use "worker-load"
DEPLOYMENT="$(eb deploy --timeout 60 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "Worker Deployment SUCCEEDED!:: "
else
	echo "Worker Deployment FAILED!:: "
    echo "failures = Worker Deployment FAILED" > failures.properties
    exit 1
fi