#!/bin/sh

#############
## Production
#############

git rm --cached .elasticbeanstalk/config.yml

cp .env.production-load .env.production
cp .env.production-load .env.staging
cp .env.worker-load .env.worker

git add .env.production
git add .env.worker

# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Production only configuration files in
if [ -d ".elasticbeanstalk/extensions/production_load" ]; then
    cp -R .elasticbeanstalk/extensions/production_load/* ./.ebextensions/
fi
git add .ebextensions/*
HACKYFIXFORSTDERR="$(git commit -m "Pre-deploy API-LOAD commit" 2>&1)"