#!/bin/bash

STATUS_AVAILABLE="available"
STATUS_STOPPED="stopped"
HEALTH_GREY="Health: Grey"

CONSUMER_AS_GROUP_NAME="awseb-e-ximknypzyd-stack-AWSEBAutoScalingGroup-EB23K799UHEH"
ADMIN_AS_GROUP_NAME="awseb-e-3fmaqgdms7-stack-AWSEBAutoScalingGroup-1S24TBP3WLRRL"
CCENTER_AS_GROUP_NAME=""
API_AS_GROUP_NAME="awseb-e-a7ab35mipb-stack-AWSEBAutoScalingGroup-1R9QVHKWG13Y9"
WORKER_AS_GROUP_NAME="awseb-e-c7ya26ipcd-stack-AWSEBAutoScalingGroup-D0KO2JY23OST"
LEGACY_AS_GROUP_NAME="awseb-e-5ny3dpvgxv-stack-AWSEBAutoScalingGroup-YQ39LKVDD5CS"


function waitForEbStatus {
    instance=$1
    target_status=$2
    
    status="unknown"
    while [[ "'$status'" != "'$target_status'" ]]; do
	    status="$(eb status ${instance} | grep "$target_status" | xargs)"
        sleep 5
    done
}

function shutDownEnvironment {
    curr=$(date -u +%Y-%m-%d-%H:%M:%S)
    delay=$(date -d "($curr) +1minutes" -u +%Y-%m-%d-%H:%M:%S)
    environment=$1
    autoscaling_group_name=$2
    
    full_environment="${environment}-load"

	init_name=$environment
    if [ "${environment}" == "api" ]; then
        init_name="pbbapi"
    fi 
    
    if [ "${environment}" == "cc" ]; then
        init_name="pbbapi"
    fi
    
    if [ "${environment}" == "worker" ]; then
        init_name="pbbapi"
    fi 
    
    if [ "${environment}" == "ccenter" ]; then
        init_name="CCenter"
    fi
    
    echo "3" | eb init $init_name --region us-west-2
    eb use $full_environment
    if eb status $full_environment | grep -q "Health: Green"; then
      	echo "The Environment, ${full_environment}, is UP. It will now be brought down.  Please allow 10 minutes to shutdown..."
        if [ ! -z $autoscaling_group_name ]; then
            echo "We are now shutting down ${full_environment}"
            aws autoscaling put-scheduled-update-group-action --auto-scaling-group-name $autoscaling_group_name --scheduled-action-name one-time-shutdown --start-time $delay --min-size 0 --max-size 0 --desired-capacity 0
        
            echo "Waiting for ${full_environment} to shut down..."
            waitForEbStatus ${full_environment} "$HEALTH_GREY"
        else
            echo "${full_environment} is NOT Ready. Aborting~\n";
        fi
    fi
}

function shutDownDatabase {
    instance=$1
    
    status="$(aws rds describe-db-instances --db-instance-identifier ${instance} | jq -r '.DBInstances[].DBInstanceStatus')"
    if [ $status == $STATUS_AVAILABLE ]; then
       stdout_fix="$(aws rds stop-db-instance --db-instance-identifier ${instance})"
    fi
}


echo "Shutting down all Load Environments..."

echo "Consumer:"
echo "Shutting Down consumer-load..."
shutDownEnvironment consumer $CONSUMER_AS_GROUP_NAME
echo "Done"

echo "Admin (Control Center):"
echo "Shutting Down cc-load..."
shutDownEnvironment cc $ADMIN_AS_GROUP_NAME
echo "Done"

# Not yet Live
#echo "CCenter (New Control Center):"
#echo "Shutting Down ccenter-load..."
#shutDownEnvironment ccenter $CCENTER_AS_GROUP_NAME
#echo "Done"

echo "API:"
echo "Shutting Down api-load..."
shutDownEnvironment api $API_AS_GROUP_NAME
echo "Done"

echo "API:"
echo "Shutting Down worker-load..."
shutDownEnvironment worker $WORKER_AS_GROUP_NAME
echo "Done"

echo "Legacy:"
echo "Shutting Down legacy-load..."
shutDownEnvironment legacy $LEGACY_AS_GROUP_NAME
echo "Done"

echo "Shutting Down Load Databases..."

echo "consumer-load RDS..."
shutDownDatabase consumer-load
echo "Scheduled."

# Not yet Live
#echo "ccenter-load RDS..."
#shutDownDatabase ccenter-load
#echo "Scheduled."
    
echo "Shutting Down api-load RDS..."
shutDownDatabase api-load
echo "Scheduled."

echo "Shutting Down api-load RDS..."
shutDownDatabase legacy-load
echo "Scheduled."
