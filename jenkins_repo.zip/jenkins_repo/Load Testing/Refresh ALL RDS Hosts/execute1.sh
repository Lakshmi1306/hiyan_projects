#!/bin/bash

# Main Constants
SECURITY_GROUP="sg-06cebba4e57bbfcd4"
SUBNET_GROUP="default"
NEW_PASSWORD="PSLoadTestDB01!"
STATUS_AVAILABLE="available"
APPLICATIONS=(api consumer legacy)

for APPLICATION in "${APPLICATIONS[@]}"
do
	PRODUCTION_IDENTIFIER="${APPLICATION}-production"
	INSTANCE_IDENTIFIER="${APPLICATION}-load"

	if [ "${APPLICATION}" == 'legacy' ]; then
		PRODUCTION_IDENTIFIER="${APPLICATION}-database"
	fi

	INSTANCE_CLASS="db.t2.micro"
	if echo "${APPLICATION}" | grep -q "api"; then
		INSTANCE_CLASS="db.m4.xlarge"    
	fi

	if echo "${APPLICATION}" | grep -q "legacy"; then
		INSTANCE_CLASS="db.r3.xlarge"    
	fi

	# Function Declarations
	function waitUntilDeleted {
		instance=$1
		count=1
		while [[ "$count" != "0" &&  "$count" != "" ]]; do
			count="$(aws rds describe-db-instances --db-instance-identifier ${instance} 2>/dev/null | jq length)"
			sleep 5
		done
	}

	function waitForStatus {
		instance=$1
		target_status=$2
		status="unknown"
		while [[ "$status" != "$target_status" ]]; do
			status="$(aws rds describe-db-instances --db-instance-identifier ${instance} | jq -r '.DBInstances[].DBInstanceStatus')"
			sleep 5
		done
	}

	# NOTE:  Commented out the actions until all other logic has been tested thoroughly
	# Main Logic

	echo "Fetching latest Snapshot ID..."
	snapshot_id="$(aws rds describe-db-snapshots --db-instance-identifier ${PRODUCTION_IDENTIFIER} | jq -r '.DBSnapshots[-1].DBSnapshotIdentifier')"
	echo "Snapshot Id: ${snapshot_id}"

	echo "Deleting database (if exists): ${INSTANCE_IDENTIFIER}"
	STDOUT_FIX="$(aws rds delete-db-instance --db-instance-identifier ${INSTANCE_IDENTIFIER} --skip-final-snapshot > /dev/null 2>&1)"

	echo "Waiting for database instance to be deleted..."
	waitUntilDeleted $INSTANCE_IDENTIFIER
	echo "Done."

	echo "Creating new database: $INSTANCE_IDENTIFIER"
	STDOUT_FIX="$(aws rds restore-db-instance-from-db-snapshot --db-instance-identifier ${INSTANCE_IDENTIFIER} --db-snapshot-identifier ${snapshot_id} --db-instance-class ${INSTANCE_CLASS} --storage-type standard --publicly-accessible --no-multi-az --no-auto-minor-version-upgrade --vpc-security-group-ids ${SECURITY_GROUP} --db-subnet-group-name ${SUBNET_GROUP} > /dev/null)"

	echo "Waiting for new DB instance ${INSTANCE_IDENTIFIER} to be available"
	waitForStatus $INSTANCE_IDENTIFIER $STATUS_AVAILABLE
	echo "Done."

	echo "Changing user password..."
	STDOUT_FIX="$(aws rds modify-db-instance --db-instance-identifier ${INSTANCE_IDENTIFIER} --master-user-password ${NEW_PASSWORD} > /dev/null 2>&1)"
	echo "Done."

	echo "Clone process is complete"
done