#!/bin/bash


STATUS_AVAILABLE="available"
STATUS_STOPPED="stopped"
STATUS_READY="Health: Green"

# Environment Constants
CONSUMER_AS_GROUP_NAME="awseb-e-ximknypzyd-stack-AWSEBAutoScalingGroup-EB23K799UHEH"
CONSUMER_MIN_CAPACITY="4"
CONSUMER_MAX_CAPACITY="20"

CCENTER_AS_GROUP_NAME=""
CCENTER_MIN_CAPACITY="1"
CCENTER_MAX_CAPACITY="1"

LEGACY_AS_GROUP_NAME="awseb-e-5ny3dpvgxv-stack-AWSEBAutoScalingGroup-YQ39LKVDD5CS"
LEGACY_MIN_CAPACITY="1"
LEGACY_MAX_CAPACITY="1"

ADMIN_AS_GROUP_NAME="awseb-e-3fmaqgdms7-stack-AWSEBAutoScalingGroup-1S24TBP3WLRRL"
ADMIN_MIN_CAPACITY="1"
ADMIN_MAX_CAPACITY="1"

API_AS_GROUP_NAME="awseb-e-a7ab35mipb-stack-AWSEBAutoScalingGroup-1R9QVHKWG13Y9"
API_MIN_CAPACITY="4"
API_MAX_CAPACITY="20"

WORKER_AS_GROUP_NAME="awseb-e-c7ya26ipcd-stack-AWSEBAutoScalingGroup-D0KO2JY23OST"
WORKER_MIN_CAPACITY="1"
WORKER_MAX_CAPACITY="1"



function waitForRdsStatus {
    instance=$1
    target_status=$2
    status="unknown"
    while [[ "$status" != "$target_status" ]]; do
        status="$(aws rds describe-db-instances --db-instance-identifier ${instance} | jq -r '.DBInstances[].DBInstanceStatus')"
        sleep 5
    done
}

function waitForEbStatus {
    instance=$1
    target_status=$2
    
    status="unknown"
    while [[ "'$status'" != "'$target_status'" ]]; do
	    status="$(eb status ${instance} | grep "$target_status" | xargs)"
        sleep 5
    done
}

function startUpEnvironment {
    curr=$(date -u +%Y-%m-%d-%H:%M:%S)
    delay=$(date -d "($curr) +1minutes" -u +%Y-%m-%d-%H:%M:%S)
    environment=$1
    autoscaling_group_name=$2
    min_capacity=$3
    max_capacity=$4
    
    full_environment="${environment}-load"

	init_name=$environment
    if [ "${environment}" == "api" ]; then
        init_name="pbbapi"
    fi 
    
    if [ "${environment}" == "worker" ]; then
        init_name="pbbapi"
    fi 
    
    if [ "${environment}" == "cc" ]; then
        init_name="pbbapi"
    fi

    if [ "${environment}" == "ccenter" ]; then
        init_name="CCenter"
    fi
    
    echo "3" | eb init $init_name --region us-west-2
    eb use $full_environment
    if eb status $full_environment | grep -q "Health: Grey"; then
      	echo "The Environment, ${full_environment}, is DOWN. It will now be brought up.  Please allow 10 minutes to rebuild..."
        if [ ! -z $autoscaling_group_name ]; then
            echo "We are now starting up ${full_environment}"
            aws autoscaling put-scheduled-update-group-action --auto-scaling-group-name $autoscaling_group_name --scheduled-action-name one-time-startup --start-time $delay --min-size $min_capacity --max-size $max_capacity --desired-capacity $min_capacity
        else
            echo "${full_environment} is NOT Ready. Aborting~\n";
        fi
    fi

    #echo "Waiting for ${full_environment} to be ready..."
    #waitForEbStatus ${full_environment} "$STATUS_READY"
}

function startUpDatabase {
    instance=$1
    
    status="$(aws rds describe-db-instances --db-instance-identifier ${instance} | jq -r '.DBInstances[].DBInstanceStatus')"
    if [ $status == $STATUS_STOPPED ]; then
       stdout_fix="$(aws rds start-db-instance --db-instance-identifier ${instance})"
    fi
}


echo "Starting Up all Load Environments..."

echo "API:"

echo "Starting Up api-load RDS..."
startUpDatabase api-load
waitForRdsStatus api-load $STATUS_AVAILABLE
echo "RDS is Started"

# Need to tweak more before turning on
echo "Starting Up worker-load Beanstalk..."
startUpEnvironment worker $WORKER_AS_GROUP_NAME $WORKER_MIN_CAPACITY $WORKER_MAX_CAPACITY
echo "Done."

echo "Starting Up api-load Beanstalk..."
startUpEnvironment api $API_AS_GROUP_NAME $API_MIN_CAPACITY $API_MAX_CAPACITY
echo "Done."

echo "Consumer:"

echo "Starting Up consumer-load RDS..."
startUpDatabase consumer-load
waitForRdsStatus consumer-load $STATUS_AVAILABLE
echo "RDS is Started"

echo "Starting Up consumer-load Beanstalk..."
startUpEnvironment consumer $CONSUMER_AS_GROUP_NAME $CONSUMER_MIN_CAPACITY $CONSUMER_MAX_CAPACITY
echo "Done."

echo "Admin (Control Center):"

echo "Starting Up cc-load Beanstalk..."
startUpEnvironment cc $ADMIN_AS_GROUP_NAME $ADMIN_MIN_CAPACITY $ADMIN_MAX_CAPACITY
echo "Done."

# Not yet Live
#echo "CCenter (New Control Center):"
#
#echo "Starting Up ccenter-load RDS..."
#startUpDatabase ccenter-load
#waitForRdsStatus ccenter-load $STATUS_AVAILABLE
#echo "RDS is Started"
#
#echo "Starting Up ccenter-load Beanstalk..."
#startUpEnvironment cccenter $CCENTER_AS_GROUP_NAME $CCENTER_MIN_CAPACITY $CCENTER_MAX_CAPACITY
#echo "Done."

echo "Legacy:"

echo "Starting Up legacy-load RDS..."
startUpDatabase legacy-load
waitForRdsStatus legacy-load $STATUS_AVAILABLE
echo "RDS is Started"

echo "Starting Up legacy-load Beanstalk..."
startUpEnvironment legacy $LEGACY_AS_GROUP_NAME $LEGACY_MIN_CAPACITY $LEGACY_MAX_CAPACITY
echo "Done."


echo "ALL Load Test Environments are have been started"
