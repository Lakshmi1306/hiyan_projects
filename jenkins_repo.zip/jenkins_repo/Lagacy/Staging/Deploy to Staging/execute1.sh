#!/bin/bash

for repo in ci cron email etl hera leadtracker \
  legacy-beanstalk legacy-laravel pbl puppymanager zeus
do
  branchVariable=${repo/-/}
  Branch=${!branchVariable}

  if [ "$Branch" = "master" ]
  then
    continue
  fi

  cd $repo

  ## Rebase current branch
  COMMITS="$(git rev-list --left-only --count origin/master...${Branch} 2>&1)"
  if echo "${COMMITS}" | grep -q "^0$"; then
    echo "Merge not necessary, continuing:: "    
  else
	MERGE="$(git merge origin/master 2>&1)"
	if echo "${MERGE}" | grep -q "Automatic merge failed"; then
    	echo "${Branch} Merge FAILED!:: "
        cd ..
    	exit 1    
	else
		echo "${Branch} Merge SUCCEEDED!:: "
	fi

	PUSH="$(git push origin ${Branch} 2>&1)"
	if echo "${PUSH}" | grep -q "${Branch} -> ${Branch}"; then
    	echo "${Branch} Push SUCCEEDED!:: "
	elif echo "${PUSH}" | grep -q "Everything up-to-date"; then
    	echo "${Branch} Push not necessary, continuing:: "
	else
		echo "${Branch} Push FAILED!:: "
        cd ..
    	exit 1
	fi
  fi
  
  cd ..
done