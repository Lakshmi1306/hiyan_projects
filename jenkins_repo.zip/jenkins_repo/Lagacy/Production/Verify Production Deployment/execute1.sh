#!/bin/bash

for repo in ci cron email etl hera leadtracker \
    legacy-beanstalk legacy-laravel pbl puppymanager zeus
do
    branchVariable=${repo/-/}
    Branch=${!branchVariable}

    if [ "$Branch" = "master" ]
    then
        continue
    fi

    cd $repo
    
	# Create a tag
	TAG="LEGACY_BUILD_${BUILD_NUMBER}"
	CREATETAG="$(git tag ${TAG} 2>&1)"

	echo "Attempted to create tag: ${TAG}"

	GITTAG="$(git tag 2>&1)"
	if echo "${GITTAG}" | grep -q "${TAG}"; then
    	echo "Tag created successfully for $repo, continuing:: "
	else
		echo "ERROR: git failed to generate tag for $repo:: "
    	echo "${GITTAG}"
    	echo "failures = ERROR: git failed to generate tag for $repo" > failures.properties
    	cd ..
        exit 1
	fi

	# Push new tag
	GITPUSHTAG="$(git push origin ${TAG} 2>&1)"
	if echo "${GITPUSHTAG}" | grep -q "${TAG} -> ${TAG}"; then
    	echo "Tag pushed successfully for $repo, continuing:: "
	else
		echo "ERROR: git failed to push tag to $repo/origin:: "
    	echo "${GITPUSHTAG}"
    	echo "failures = ERROR: git failed to push tag to $repo/origin" > failures.properties
    	cd ..
        exit 1
	fi
    
    cd ..
done