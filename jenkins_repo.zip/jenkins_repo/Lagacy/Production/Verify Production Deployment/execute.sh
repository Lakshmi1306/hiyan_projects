#!/bin/bash

for repo in ci cron email etl hera leadtracker \
  legacy-beanstalk legacy-laravel pbl puppymanager zeus
do
  branchVariable=${repo/-/}
  Branch=${!branchVariable}

  if [ "$Branch" = "master" ]
  then
    continue
  fi

  cd $repo
  
  PRS="$(php ~/jenkinsgit/jenkinsgit.php -r$repo -jLEGACY --merge-pull-request --source="${Branch}" --dest="master" 2>&1)"
  if echo "${PRS}" | grep -q "success$"; then
    echo "Pull request merged successfully, ${Branch} -> $repo/master, continuing:: "
  else
	echo "ERROR: The pull request failed to merge (${Branch} -> $repo/master):: "
    echo "${PRS}"
    echo "failures = ERROR: The pull request failed to merge (${Branch} -> $repo/master)" > failures.properties
    cd ..
    exit 1
  fi
  
  cd ..
done