#!/bin/bash

FAILURE=""

for repo in ci cron email etl hera leadtracker \
    legacy-beanstalk legacy-laravel pbl puppymanager zeus
do
    branchVariable=${repo/-/}
    Branch=${!branchVariable}

    if [ "$Branch" = "master" ]
    then
        continue
    fi

    cd $repo
    
	# Get child branches of master
	# Loop through child branches of master and merge master into them (failed merges should be noted to be emailed out at the end, but continue)
	GITSYNC="$(php ~/jenkinsgit/jenkinsgit.php -r$repo -jLEGACY --sync-feature-branches --source="${Branch}" 2>&1)"
	if echo "${GITSYNC}" | grep -q "success$"; then
    	echo "All child branches synced successfully! Complete."
	else
		echo "WARNING: Some child branches failed to merge:: "
    	echo -e "${GITSYNC}"
    	FAILURE="${FAILURE}\n$(echo -e ${GITSYNC} | sed -e 's/$/<br>\\/')"
	fi
    
    cd ..
done

echo "failures = ${FAILURE}" > failures.properties