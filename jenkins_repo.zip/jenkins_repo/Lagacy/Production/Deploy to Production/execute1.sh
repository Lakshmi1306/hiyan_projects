#!/bin/bash

for repo in ci cron email etl hera leadtracker \
  legacy-beanstalk legacy-laravel pbl puppymanager zeus
do
  branchVariable=${repo/-/}
  Branch=${!branchVariable}

  if [ "$Branch" = "master" ]
  then
    continue
  fi

  cd $repo
  
  PRS="$(php ~/jenkinsgit/jenkinsgit.php -r$repo -jLEGACY --count-pull-requests --dest="master" 2>&1)"
  if echo "${PRS}" | grep -q "^0$"; then
    echo "No pending pull requests, for $repo, continuing:: output='${PRS}'"
  else
	echo "ERROR: There are existing Pull Request(s) into $repo/master. Ensure the QA Verify step was performed. Halting."
    echo " output='${PRS}'"
    echo "failures = ERROR: There are existing Pull Request(s) into $repo/master. Ensure the QA Verify step was performed. Halting." > failures.properties
    cd ..
    exit 1
  fi

  ## Check that the branch going out is ahead of master
  COMMITS="$(git rev-list --left-only --count origin/master...${Branch} 2>&1)"
  if echo "${COMMITS}" | grep -q "^0$"; then
    echo "$repo/${Branch} Branch cleared for delivery. SEND IT!:: "    
  else
   echo "ERROR: $repo/${Branch} Branch behind master. Branch must be QA Verified via stage deployment FIRST! Deployment Aborted.:: "
   echo "failures = ERROR: $repo/${Branch} Branch behind master. Branch must be QA Verified via stage deployment FIRST! Deployment Aborted." > failures.properties
   cd ..
   exit 1
  fi
  
  cd ..
done