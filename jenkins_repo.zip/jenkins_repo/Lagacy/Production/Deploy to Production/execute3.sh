#!/bin/bash

### Create Pull Request into master

for repo in ci cron email etl hera leadtracker \
    legacy-beanstalk legacy-laravel pbl puppymanager zeus
do
    branchVariable=${repo/-/}
    Branch=${!branchVariable}

    if [ "$Branch" = "master" ]
    then
        continue
    fi

    cd $repo

	PR="$(php ~/jenkinsgit/jenkinsgit.php -r$repo -jLEGACY --create-pull-request --source="${Branch}" --dest="master" 2>&1)"
	if echo "${PR}" | grep -q "success$"; then
    	echo "Pull request created!"
	else
		echo "ERROR: Failed to create Pull Request! (${Branch} -> $repo):: "
    	echo "${PR}"
    	echo "failures = ERROR: Failed to create Pull Request" > failures.properties
        cd ..
    	exit 1
	fi
    
    cd ..
done