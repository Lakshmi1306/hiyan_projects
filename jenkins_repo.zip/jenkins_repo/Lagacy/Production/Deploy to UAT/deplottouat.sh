#!/bin/bash

######
## DEPLOYMENT
######

# Prepare build environment (dont change this, workaround to prevent stderr)
mkdir -p ../jenkinsbuilddir
cp -R . ../jenkinsbuilddir/
mv ../jenkinsbuilddir ./
cd ./jenkinsbuilddir
cp -R legacy-beanstalk/. ./

# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy ETL Staging only configuration files in
cp -R .elasticbeanstalk/extensions/etl-staging/* ./.ebextensions/

rm -R */.git
rm -R */*/.git
rm -R */*/*/.git

git init
git add -A
HACKYFIXFORSTDERR="$(git commit -m "Pre-deploy ETL Staging commit" 2>&1)"


#
# Environment already exists. Just Deploy
#

eb use etl-legacy-stage
DEPLOYMENT="$(eb deploy --timeout 15 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "ETL Staging Deployment SUCCEEDED!:: "
else
	echo "ETL Staging Deployment FAILED!:: "
    echo "failures = ETL Staging Deployment FAILED" > failures.properties
    echo "eb deploy output: $DEPLOYMENT"
    exit 1
fi