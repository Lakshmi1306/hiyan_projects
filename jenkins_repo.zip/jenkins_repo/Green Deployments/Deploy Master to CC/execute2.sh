#!/bin/sh


######
## DEPLOYMENT
######

APP_ENVIRONMENT="CC-green"
SQS_PREFIX="green"

# Add the .env Params:
echo "\n\nAWS_LOW_PRIORITY_JOB_QUEUE=${SQS_PREFIX}-Low-Priority-Queue\nAWS_LOW_PRIORITY_JOB_DLQ=${SQS_PREFIX}-Low-Priority-DLQ\nAWS_JOB_QUEUE=${SQS_PREFIX}-Job-Queue\nAWS_JOB_DLQ=${SQS_PREFIX}-Job-DLQ\nAWS_MAIL_QUEUE=${SQS_PREFIX}-Mail-Queue\nAWS_MAIL_DLQ=${SQS_PREFIX}-Mail-DLQ\nAWS_SEARCH_UPDATE_JOB_QUEUE=${SQS_PREFIX}-Search-Update-Job-Queue\nAWS_SEARCH_UPDATE_JOB_DLQ=${SQS_PREFIX}-Search-Update-Job-DLQ\n" >> .env.staging

git add .env.staging


# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Staging only configuration files in
cp -R .elasticbeanstalk/extensions/staging/* ./.ebextensions/

sed -i 's/<---StageNameREPLACE-->/'"${APP_ENVIRONMENT}"'/g' .ebextensions/* > /dev/null

git add .ebextensions/*
git commit -m "Pre-deploy commit"

#
# Environment already exists. Just Deploy
#

eb use CC-green
MYHOST=$(eb status CC-green | grep "  CNAME: " | cut -f2 -d: | cut -f2 -d' ');

echo "host = http\://${MYHOST}" > host.properties

DEPLOYMENT="$(eb deploy 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "Deployment SUCCEEDED!:: "
    echo "${DEPLOYMENT}"
else
	echo "Deployment FAILED!:: "
    echo "${DEPLOYMENT}"
    exit 1
fi