#!/bin/sh


######
## DEPLOYMENT
######

Environment='green'
LOWERCASE_ENV="$(echo ${Environment} | tr '[:upper:]' '[:lower:]' 2>&1)"


APP_ENVIRONMENT="Consumer-${Environment}"

# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Staging only configuration files in
cp -R .elasticbeanstalk/extensions/staging/* ./.ebextensions/

sed -i 's/<---StageNameREPLACE-->/'"${APP_ENVIRONMENT}"'/g' .ebextensions/* > /dev/null
sed -i 's/<---StageLayerNameREPLACE-->/'"${Environment}"'/g' .ebextensions/* > /dev/null


git add .env.staging

git add public/. --force
git add .ebextensions/*
git commit -m "Pre-deploy commit"

#
# Environment already exists. Just Deploy
#

eb use Consumer-green
MYHOST=$(eb status Consumer-green | grep "  CNAME: " | cut -f2 -d: | cut -f2 -d' ');

echo "host = http\://${MYHOST}" > host.properties

DEPLOYMENT="$(eb deploy --timeout 45 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "Deployment SUCCEEDED!:: "
    echo "${DEPLOYMENT}"
else
	echo "Deployment FAILED!:: "
    echo "${DEPLOYMENT}"
    exit 1
fi