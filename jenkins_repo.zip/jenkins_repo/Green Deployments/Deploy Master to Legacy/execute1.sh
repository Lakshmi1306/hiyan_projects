#!/bin/bash

######
## DEPLOYMENT
######

# Prepare build environment (dont change this, workaround to prevent stderr)
mkdir -p ../jenkinsbuilddir
cp -R . ../jenkinsbuilddir/
mv ../jenkinsbuilddir ./
cd ./jenkinsbuilddir
cp -R legacy-beanstalk/. ./

# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Etl-Staging configuration files in
cp -R .elasticbeanstalk/extensions/green/* ./.ebextensions/

rm -R */.git
rm -R */*/.git
rm -R */*/*/.git

git init
git add -A
git add .ebextensions/*
HACKYFIXFORSTDERR="$(git commit -m "Pre-deploy Staging commit" 2>&1)"

#
# Environment already exists. Just Deploy
#

eb use Legacy-green
MYHOST=$(eb status Legacy-green | grep "  CNAME: " | cut -f2 -d: | cut -f2 -d' ');

echo "host = http\://${MYHOST}" > host.properties

DEPLOYMENT="$(eb deploy 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "Deployment SUCCEEDED!:: "
    echo "${DEPLOYMENT}"
else
	echo "Deployment FAILED!:: "
    echo "${DEPLOYMENT}"
    exit 1
fi