#!/bin/env python

quit()