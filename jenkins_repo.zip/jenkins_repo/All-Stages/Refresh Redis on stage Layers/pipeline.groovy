pipeline {
    agent any
    stages {
        stage ('Refresh Eng-01') {
            steps {
                build job: 'Ansible-Jobs/Refresh-Redis-Cache', parameters: [[$class: 'StringParameterValue', name: 'Environment', value: "Eng-01"]]
            }
        }
        stage ('Refresh Eng-02') {
            steps {
                build job: 'Ansible-Jobs/Refresh-Redis-Cache', parameters: [[$class: 'StringParameterValue', name: 'Environment', value: "Eng-02"]]
            }
        }
        stage ('Refresh Stage-01') {
            steps {
                build job: 'Ansible-Jobs/Refresh-Redis-Cache', parameters: [[$class: 'StringParameterValue', name: 'Environment', value: "Stage-01"]]
            }
        }
        stage ('Refresh Stage-02') {
            steps {
                build job: 'Ansible-Jobs/Refresh-Redis-Cache', parameters: [[$class: 'StringParameterValue', name: 'Environment', value: "Stage-02"]]
            }
        }
        stage ('Refresh Stage-03') {
            steps {
                build job: 'Ansible-Jobs/Refresh-Redis-Cache', parameters: [[$class: 'StringParameterValue', name: 'Environment', value: "Stage-03"]]
            }
        }
        stage ('Refresh Stage-04') {
            steps {
                build job: 'Ansible-Jobs/Refresh-Redis-Cache', parameters: [[$class: 'StringParameterValue', name: 'Environment', value: "Stage-04"]]
            }
        }
        stage ('Refresh Stage-05') {
            steps {
                build job: 'Ansible-Jobs/Refresh-Redis-Cache', parameters: [[$class: 'StringParameterValue', name: 'Environment', value: "Stage-05"]]
            }
        }
        stage ('Refresh sandbox') {
            steps {
                build job: 'Ansible-Jobs/Refresh-Redis-Cache', parameters: [[$class: 'StringParameterValue', name: 'Environment', value: "sandbox"]]
            }
        }
    }
}
