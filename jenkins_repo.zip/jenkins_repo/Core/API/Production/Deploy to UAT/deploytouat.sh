#!/bin/sh


######
## DEPLOYMENT
######
Environment="sandbox"

LOWERCASE_ENV="$(echo ${Environment} | tr '[:upper:]' '[:lower:]' 2>&1)"

APP_ENVIRONMENT="API-${Environment}"
SQS_PREFIX="${Environment}"
EBFOLDER="staging"
AWS_BUCKET_POSTFIX="${LOWERCASE_ENV}"
CONSUMER_SITE_BASE_URL="https://${LOWERCASE_ENV}.39u6rtyj29.us-west-2.elasticbeanstalk.com/"
LEGACY_DOMAIN="www.puppyspot.preprod"
RDS_SNAPSHOT_NAME="api-stage-01-20190919"

AWS_SUFFIX="${LOWERCASE_ENV}"
CONSUMER_HOST="consumer-${LOWERCASE_ENV}"


# Add the param for the location of the Consumer site for Yotpo:
echo "Setting Consumer Site URL to ${CONSUMER_SITE_BASE_URL}"
echo "\nCONSUMER_SITE_BASE_URL=${CONSUMER_SITE_BASE_URL}\n" >> .env.staging

echo "\nAWS_LOW_PRIORITY_JOB_QUEUE=${SQS_PREFIX}-Low-Priority-Queue\nAWS_LOW_PRIORITY_JOB_DLQ=${SQS_PREFIX}-Low-Priority-DLQ\nAWS_JOB_QUEUE=${SQS_PREFIX}-Job-Queue\nAWS_JOB_DLQ=${SQS_PREFIX}-Job-DLQ\nAWS_MAIL_QUEUE=${SQS_PREFIX}-Mail-Queue\nAWS_MAIL_DLQ=${SQS_PREFIX}-Mail-DLQ\nAWS_SEARCH_UPDATE_JOB_QUEUE=${SQS_PREFIX}-Search-Update-Job-Queue\nAWS_SEARCH_UPDATE_JOB_DLQ=${SQS_PREFIX}-Search-Update-DLQ\nAWS_LEAD_QUEUE=${SQS_PREFIX}-Lead-Queue\nAWS_LEAD_DLQ=${SQS_PREFIX}-Lead-DLQ\nAWS_IMAGE_PROCESSING_QUEUE=${SQS_PREFIX}-Image-Processing-Queue\nAWS_IMAGE_PROCESSING_DLQ=${SQS_PREFIX}-Image-Processing-DLQ\nAWS_TALLY_QUEUE=${SQS_PREFIX}-Tally-Queue\nAWS_TALLY_DLQ=${SQS_PREFIX}-Tally-DLQ\nAWS_MONITOR_JOB_QUEUE=${SQS_PREFIX}-Monitor-Job-Queue\nAWS_MONITOR_JOB_DLQ=${SQS_PREFIX}-Monitor-Job-DLQ\nAWS_ACCOUNTING_INTEGRATION_QUEUE=${SQS_PREFIX}-Accounting-Integration-Queue\nAWS_ACCOUNTING_INTEGRATION_DLQ=${SQS_PREFIX}-Accounting-Integration-DLQ\nAWS_CUSTOMER_CHAT_QUEUE=${SQS_PREFIX}-Customer-Chat-Queue\nAWS_CUSTOMER_CHAT_DLQ=${SQS_PREFIX}-Customer-Chat-DLQ\nAWS_ORDER_SYNC_QUEUE=${SQS_PREFIX}-Order-Sync-Queue\nAWS_ORDER_SYNC_DLQ=${SQS_PREFIX}-Order-Sync-DLQ\nAWS_CONSUMER_CACHE_QUEUE=${SQS_PREFIX}-Consumer-Cache-Queue\nAWS_CONSUMER_CACHE_DLQ=${SQS_PREFIX}-Consumer-Cache-DLQ\nAWS_LOGGING_QUEUE=${SQS_PREFIX}-Logging-Queue\nAWS_LOGGING_DLQ=${SQS_PREFIX}-Logging-DLQ\n" >> .env.staging
echo "\nAWS_MEDIA_BUCKET=puppyspot-photos-${AWS_BUCKET_POSTFIX}\nAWS_BREEDER_BUCKET=puppyspot-breeder-uploads-${AWS_BUCKET_POSTFIX}\nAWS_FILE_UPLOADS_BUCKET=puppyspot-files-${AWS_BUCKET_POSTFIX}\n\n" >> .env.staging

echo "CLOUDSEARCH_INTERNAL_LISTING_DOMAIN=${CLOUDSEARCH_INTERNAL_LISTING_DOMAIN}\n" >> .env.staging
echo "CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN=${CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN}\n" >> .env.staging
echo "CLOUDSEARCH_PLM_LISTING_DOMAIN=${CLOUDSEARCH_PLM_LISTING_DOMAIN}\n" >> .env.staging
echo "CLOUDSEARCH_BREED_DOMAIN=${CLOUDSEARCH_BREED_DOMAIN}\n" >> .env.staging

git add .env.staging

# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Staging only configuration files in
cp -R .elasticbeanstalk/extensions/staging/* ./.ebextensions/

sed -i 's/<---StageNameREPLACE-->/'"${APP_ENVIRONMENT}"'/g' .ebextensions/* > /dev/null
sed -i 's/<---StageLayerNameREPLACE-->/'"${Environment}"'/g' .ebextensions/* > /dev/null
sed -i 's/<---SqsPrefixREPLACE-->/'"${Environment}"'/g' .ebextensions/supervisor/queue_worker.conf > /dev/null
sed -i 's/<---SnapshotNameREPLACE-->/'"${RDS_SNAPSHOT_NAME}"'/g' .ebextensions/* > /dev/null

git add .ebextensions/*
git commit -m "Pre-deploy commit"


eb use ${APP_ENVIRONMENT}
MYHOST=$(eb status ${APP_ENVIRONMENT} | grep "  CNAME: " | cut -f2 -d: | cut -f2 -d' ');

echo "host = http\://${MYHOST}" > host.properties

DEPLOYMENT="$(eb deploy 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "Deployment SUCCEEDED!:: "
    echo "${DEPLOYMENT}"
else
	echo "Deployment FAILED!:: "
    echo "${DEPLOYMENT}"
    exit 1
fi