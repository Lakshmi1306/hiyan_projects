GITHUB_PROJECT = "git@bitbucket.org:pbb_api/pbb-api.git"
GITHUB_CREDENTIALS_ID = "1e66da07-96aa-481f-9425-f74e782bfce0" //maps to a Jenkins Credentials Vault ID
APPLICATION_NAME = "pbbapi"
GITHUB_BRANCH = '${env.BRANCH_NAME}'
HAS_STARTED_CLONE = false
HAS_STARTED_VERIFY = false
IS_POST_CLONE = false
IS_POST_SWAP = false
IS_POST_WORKER = false
pipeline {
    agent any
    stages {
        
        stage ('Add Deployment Note') {
			steps {
				build job: 'AddDeploymentNote', wait: false
			}
        }
        
        stage ("Checking Environment") {
			steps {
				sh '''#!/bin/bash
				set -e
				set -x

				envCount=`aws elasticbeanstalk describe-environments --environment-names | jq '.Environments[] | select(.Status=="Ready")' |  jq '.EnvironmentName' | grep API-prod | wc -l`

				echo "This is the current number of environments: $envCount"

				if [ $envCount -gt 1 ]
				then
					echo "There is more than one API-prod environment...please contact DevOps. Aborting..."
					exit 1
				fi
				
				### Check that there are no pending PRs into master -- if there is, someone deployed but hasn't yet verified
				PRS="\$(php ~/jenkinsgit/jenkinsgit.php -rAPI --count-pull-requests --dest="master" 2>&1)"
				if echo \$PRS | grep -q "^0\$"; then
                    echo "No pending pull requests, continuing:: "
                else
	                echo "ERROR: There are existing Pull Request(s) into master. Ensure the QA Verify step was performed. Halting."
                    echo "failures = ERROR: There are existing Pull Request(s) into master. Ensure the QA Verify step was performed. Halting." > failures.properties
                    echo \$PRS
                    exit 1
                fi
				'''
			}
        }        

        stage ("Listing Branches") {
			steps {
				echo "Initializing workflow"
				//checkout code
				echo GITHUB_PROJECT
				git url: GITHUB_PROJECT, credentialsId: GITHUB_CREDENTIALS_ID
				sh 'git branch -r | awk \'{print $1}\' ORS=\'\\n\' >branches.txt'
				sh '''cut -d '/' -f 2 branches.txt > branch.txt'''
			}
        }

        stage('Get Build Branch') {
			steps {
				script {
					liste = readFile 'branch.txt'
					echo "please click on the link here to chose the branch to build"
					env.BRANCH_SCOPE = input message: 'Please choose the branch to build ', ok: 'Proceed!',
					parameters: [choice(name: 'BRANCH_NAME', choices: "${liste}", description: 'Branch to build?')]
				}
			}
        }

        stage('Checkout') {
			steps {
				echo "${env.BRANCH_SCOPE}"
				git branch: "${env.BRANCH_SCOPE}",
				credentialsId: '1e66da07-96aa-481f-9425-f74e782bfce0',
				url: 'git@bitbucket.org:pbb_api/pbb-api.git'
			}
        }

        stage('Git') {
			steps {
				sh """#!/bin/sh
				set -x

				#############
				## Production
				#############

				### Check that the branch going out is ahead of master
				COMMITS="\$(git rev-list --left-only --count origin/master...${env.BRANCH_SCOPE} 2>&1)"
				if echo \$COMMITS | grep -q "^0\$"; then
                    echo "Branch cleared for delivery. SEND IT!:: "    
                else
                    echo "ERROR: Branch behind master. Branch must be QA Verified via stage deployment FIRST! Deployment Aborted.:: "
                    echo "failures = ERROR: Branch behind master. Branch must be QA Verified via stage deployment FIRST! Deployment Aborted." > failures.properties
                    exit 1
                fi

				git rm --cached .elasticbeanstalk/config.yml

				git add .env.production

				# Create ebextensions directory
				mkdir -p .ebextensions
				# Copy common configuration files in
				cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
				# Copy Production only configuration files in
				if [ -d ".elasticbeanstalk/extensions/production" ]; then
					cp -R .elasticbeanstalk/extensions/production/* ./.ebextensions/
				fi

				git add public/. --force
				git add .ebextensions/*
				HACKYFIXFORSTDERR="\$(git commit -m "Pre-deploy PROD commit" 2>&1)"
				"""
			}
        }

		stage ('Trigger Add SDT to LogicMonitor') {
			steps {
				build job: 'AddSDTLogicMonitor', wait: false
			}
		}

		stage ('Deploy to Worker') {
			steps {
				timeout(time: 6, unit: 'HOURS') {
					input 'Deploy to Worker?'
				}
				sh '''#!/bin/bash
				set -e
				set -x
				#############
				## Worker
				#############

				echo "Setting up ebextensions directory for worker..."

				# Empty ebextensions directory
				rm -R .ebextensions
				# Create ebextensions directory
				mkdir -p .ebextensions
				# Copy common configuration files in
				cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
				# Copy Worker only configuration files in
				if [ -d ".elasticbeanstalk/extensions/worker" ]; then
					cp -R .elasticbeanstalk/extensions/worker/* ./.ebextensions/
				fi
				git add .ebextensions/*
				git rm .ebextensions/newrelic.config
				git commit -m "Pre-deploy Worker commit" --amend

				sleep 1

				echo "Deploying to Worker..."

				eb use worker

				DEPLOYMENT="$(eb deploy --timeout 60 2>&1)"

				if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
					echo "Worker Deployment SUCCEEDED!:: "
				else
					echo "Worker Deployment FAILED!:: "
					echo "failures = Worker Deployment FAILED" > failures.properties
					exit 1
				fi
				'''
				script {
					IS_POST_WORKER = true    
				}
			}
		}
          
        stage('Clone & Deploy') {
            steps {
				timeout(time: 5, unit: 'HOURS') {
					input 'Clone & Deploy ?'
				}
				script {
					HAS_STARTED_CLONE = true
				}
				sh '''#!/bin/bash
				set -e
				set -x
				
				# Reset the the ebextensions directory
				git rm -r .ebextensions/*
				rm -rf .ebextensions/*
				mkdir -p .ebextensions
				# Copy common configuration files in
				cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
				# Copy Production only configuration files in
				if [ -d ".elasticbeanstalk/extensions/production" ]; then
					cp -R .elasticbeanstalk/extensions/production/* ./.ebextensions/
				fi

				git add .ebextensions/*
				HACKYFIXFORSTDERR="$(git commit -m "Pre-deploy PROD commit" 2>&1)"				

				#Get Date for Deployment, add
				LABEL_ID='-'$(date '+%Y-%m-%d')'-'$(uuidgen | cut -c1-4)

				# Current CNAME
				CNAME="psapi-prod.us-west-2.elasticbeanstalk.com"

				#  Prefix for environment name
				ENV_PREFIX="API-prod"

				# Label for Application Version you will delpoy uses environment prefix, date & unique 8 char id
				VERSION_LABEL="$ENV_PREFIX$LABEL_ID"

				# RDS Security Group ID
				RDS_SECURITY_GROUP_ID="sg-8ac47af3"

				# Define Blue & Green Target Groups - BLUE IS CURRENT LIVE ENVIRONMENT
				BLUE_TARGET_GROUP_ARN="arn:aws:elasticloadbalancing:us-west-2:172136542978:targetgroup/puppyspot-targets-api-prod/2cea95c1a62ed79c"
				GREEN_TARGET_GROUP_ARN="arn:aws:elasticloadbalancing:us-west-2:172136542978:targetgroup/green-api-prod/2645930fdd538413"

				#Set AWS Region For AWSCLI API calls
				aws configure set default.region us-west-2

				# Get Current Elastic Beanstalk Environment Name by CNAME
				ENVIRONMENT_NAME=$(aws elasticbeanstalk describe-environments | jq '.Environments' | jq -r '.[] | select(.CNAME=="'$CNAME'") | .EnvironmentName')
				echo '[*] AWS Elastic Beanstalk Current Environment Name: ' $ENVIRONMENT_NAME

				eb use $ENVIRONMENT_NAME

				# UUID for new environment
				UUID=$(uuidgen | cut -c1-8)
				NEW_ENVIRONMENT_NAME="$ENV_PREFIX-$UUID"
				echo '[*] New Environment Name: ' $NEW_ENVIRONMENT_NAME

				# Clone New Environment from Current
				CLONE_STATUS=$(eb clone $ENVIRONMENT_NAME -v -n $NEW_ENVIRONMENT_NAME --exact --timeout 20)

				# Get Cloudformation Stack name for new cloned beanstalk environment
				STACK_NAME=$(aws elasticbeanstalk describe-environment-resources --environment-name $NEW_ENVIRONMENT_NAME | jq '.EnvironmentResources.AutoScalingGroups[].Name' | tr -d '"' | cut -d '-' -f 1-4)
				STACK_NAME="$STACK_NAME-AWSEBSecurityGroup"

				#Use stack name to get new security group id
				SECURITY_GROUP_ID=$(aws ec2 describe-security-groups --filters Name=group-name,Values="$STACK_NAME*" | jq '.SecurityGroups' | jq -r '.[].GroupId')

				# Create Ingress Rule
				aws ec2 authorize-security-group-ingress --group-id $RDS_SECURITY_GROUP_ID --protocol tcp --port 3306 --source-group $SECURITY_GROUP_ID

				# Get New Environment Status
				STATUS=$(aws elasticbeanstalk describe-environments | jq '.Environments' | jq -r '.[] | select(.EnvironmentName=="'$NEW_ENVIRONMENT_NAME'") | .Status')
				echo '[*] New Environment Status: ' $STATUS

				# Error handling: New Environment Status
				if [ $STATUS != "Ready" ]
				then
				echo '[*] Something is wrong with the new environment exiting now...'
				exit 1
				fi

				echo '[*] Environment is ready. Starting Deployment Now.'
				sleep 1

				# Deployment of new application version
				DEPLOY_STATUS=$(eb deploy $NEW_ENVIRONMENT_NAME -v -l $VERSION_LABEL --timeout 90)
				sleep 1

				# Error handling: Deploy
				if echo "${DEPLOY_STATUS}" | grep -q "Environment update completed successfully."; then
				echo "[*] Deployment Succeeded!:: "
				else
				echo "[*] Deployment Failed!:: "
				  echo $DEPLOY_STATUS
				echo "failures = Production Deployment FAILED" > failures.properties
				exit 1
				fi

				# Write Vars for later stages
				echo 'export ENVIRONMENT_NAME='$ENVIRONMENT_NAME > blueGreenVars
				echo 'export NEW_ENVIRONMENT_NAME='$NEW_ENVIRONMENT_NAME >> blueGreenVars
				echo 'export RDS_SECURITY_GROUP_ID='$RDS_SECURITY_GROUP_ID >> blueGreenVars
				echo 'export BLUE_TARGET_GROUP_ARN='$BLUE_TARGET_GROUP_ARN >> blueGreenVars
				echo 'export GREEN_TARGET_GROUP_ARN='$GREEN_TARGET_GROUP_ARN >> blueGreenVars
				chmod +x blueGreenVars

				# Print Url for Green Site
				GREENSITE_CNAME=$(aws elasticbeanstalk describe-environments --environment-name $NEW_ENVIRONMENT_NAME | jq '.Environments' | jq -r '.[] | .CNAME')
				echo 'New Environment CNAME:' $GREENSITE_CNAME
				sleep 1

				# Get amount of green (new) instances
				INSTANCE_COUNT=$(aws elasticbeanstalk describe-environment-resources --environment-name $NEW_ENVIRONMENT_NAME | jq '.EnvironmentResources.Instances' | jq length)
				# Get list of green instance id's
				declare -a GREEN_INSTANCE_LIST
				for ((i=1;i<INSTANCE_COUNT+1;i++))
				do
				echo "Instance: $i"
				j=$i-1
				GREEN_INSTANCE_LIST[$i]=$(aws elasticbeanstalk describe-environment-resources --environment-name $NEW_ENVIRONMENT_NAME| jq '.EnvironmentResources.Instances['$j'].Id' | tr -d '"')
				echo ${GREEN_INSTANCE_LIST[$i]}
				done

				# Add targets to green target group
				for i in "${GREEN_INSTANCE_LIST[@]}"
				do
					echo "Instance: $i"
					aws elbv2 register-targets --target-group-arn $GREEN_TARGET_GROUP_ARN --targets Id="$i"
				done
				
				# Update CNAME record in Cloudflare
				echo 'Updating Cloudflare CNAME  - green-api.puppyspot.com'
				
				curl -X PUT "https://api.cloudflare.com/client/v4/zones/94d91f69b54b8059420ac770941d034d/dns_records/4910336020d953e0f5960303f356407f" \
                     -H "X-Auth-Email: domains@puppyspot.com" \
                     -H "X-Auth-Key: b414649936974152a2f3f19b98843882bab1a" \
                     -H "Content-Type: application/json" \
                	 --data '{"type":"CNAME","name":"green-api.puppyspot.com","content":"'"$GREENSITE_CNAME"'","ttl":1,"proxied":false}'

				'''
			    script {
                    IS_POST_CLONE = true    
                }
			}
		}

        stage('Swap URLs') {
			steps {
				timeout(time: 6, unit: 'HOURS') {
					input 'Swap URLs?'
				}
                sh '''#!/bin/bash
                set -e
                set -x

                #Get Blue/green environment names
                source ./blueGreenVars

                #Swap URLS Blue to Green
                echo '[*] Swapping CNAME Urls from ' $ENVIRONMENT_NAME ' to ' $NEW_ENVIRONMENT_NAME
                SWAP_STATUS=$(eb swap $NEW_ENVIRONMENT_NAME -v -n $ENVIRONMENT_NAME)
                sleep 3

                # Error handling: Swap
                if echo "${SWAP_STATUS}" | grep -q "Completed swapping CNAMEs for environments"; then
					echo "[*] URL Swap Succeeded!:: "
                else
					echo "[*] URL Swap Failed!:: "
					echo "failures = URL Swap FAILED" > failures.properties
					exit 1
                fi

                # Get amount of green (new) instances
                INSTANCE_COUNT=$(aws elasticbeanstalk describe-environment-resources --environment-name $NEW_ENVIRONMENT_NAME | jq '.EnvironmentResources.Instances' | jq length)
                # Get list of green instance id's
                declare -a GREEN_INSTANCE_LIST
                for ((i=1;i<INSTANCE_COUNT+1;i++))
                do
					echo "Instance: $i"
					j=$i-1
					GREEN_INSTANCE_LIST[$i]=$(aws elasticbeanstalk describe-environment-resources --environment-name $NEW_ENVIRONMENT_NAME| jq '.EnvironmentResources.Instances['$j'].Id' | tr -d '"')
					echo ${GREEN_INSTANCE_LIST[$i]}
                done

                # Remove targets from green target group and put in blue target group
                for i in "${GREEN_INSTANCE_LIST[@]}"
                do
					echo "Instance: $i"
					aws elbv2 deregister-targets --target-group-arn $GREEN_TARGET_GROUP_ARN --targets Id="$i"
					sleep 1
					aws elbv2 register-targets --target-group-arn $BLUE_TARGET_GROUP_ARN --targets Id="$i"
                done

                sleep 5

                # Get instance count for blue old environment
                INSTANCE_COUNT=$(aws elasticbeanstalk describe-environment-resources --environment-name $ENVIRONMENT_NAME | jq '.EnvironmentResources.Instances' | jq length)
                declare -a BLUE_INSTANCE_LIST
                # Get instance ids of blue environment
                for ((i=1;i<INSTANCE_COUNT+1;i++))
                do
					echo "Instance: $i"
					j=$i-1
					BLUE_INSTANCE_LIST[$i]=$(aws elasticbeanstalk describe-environment-resources --environment-name $ENVIRONMENT_NAME | jq '.EnvironmentResources.Instances['$j'].Id' | tr -d '"')
					echo ${BLUE_INSTANCE_LIST[$i]}
                done

                # Deregister targets
                for i in "${BLUE_INSTANCE_LIST[@]}"
                do
                   echo "Instance: $i"
                   aws elbv2 deregister-targets --target-group-arn $BLUE_TARGET_GROUP_ARN --targets Id="$i"
                done

                '''
				script {
                    IS_POST_SWAP = true    
                }
			}
		}

        stage('Pull Request') {
			steps {
				timeout(time: 6, unit: 'HOURS') {
					input 'Terminate Original Environment?  NOTE: THERE IS NO ROLLBACK AFTER PROCEEDING HERE.'
				}			
				sh """#!/bin/sh
				set -x
				### Create Pull Request into master

				PR="\$(php ~/jenkinsgit/jenkinsgit.php -rAPI --create-pull-request --source=${env.BRANCH_SCOPE} --dest="master" 2>&1)"
				if echo \$PR | grep -q "^success\$"; then
					echo "Pull request created!"
				else
					echo "ERROR: Failed to create Pull Request!:: "
					echo \$PR
					echo "failures = ERROR: Failed to create Pull Request" > failures.properties
					exit 1
				fi
				"""
			}
		}
            
        stage('Terminate Original Env') {
			options {
				retry(3)
			}
			steps {
				sh '''#!/bin/bash
				set -e
				set -x

				#Get Blue/green environment names
				source ./blueGreenVars
				
				sleep 61

				# Get Cloudformation Stack name for old  beanstalk environment
				STACK_NAME=$(aws elasticbeanstalk describe-environment-resources --environment-name $ENVIRONMENT_NAME | jq '.EnvironmentResources.AutoScalingGroups[].Name' | tr -d '"' | cut -d '-' -f 1-4)
				STACK_NAME="$STACK_NAME-AWSEBSecurityGroup"

				#Use stack name to get new security group id
				SECURITY_GROUP_ID=$(aws ec2 describe-security-groups --filters Name=group-name,Values="$STACK_NAME*" | jq '.SecurityGroups' | jq -r '.[].GroupId')

				# Delete RDS SG Ingress Rule for old environment
				aws ec2 revoke-security-group-ingress --group-id $RDS_SECURITY_GROUP_ID --protocol tcp --port 3306 --source-group $SECURITY_GROUP_ID

				#Terminate Old Environment
				echo '[*] Terminating Original Environment: ' $ENVIRONMENT_NAME
				TERMINATE_STATUS=$(eb terminate $ENVIRONMENT_NAME -v  --force --timeout 60)

				# Error handling Terminate
				if echo "${TERMINATE_STATUS}" | grep -q "terminateEnvironment completed successfully"; then
					echo "[*] Old Environment Terminated Successfully!:: "
				else
					echo "[*] Termination Failed!:: Environment: " $ENVIRONMENT_NAME
					echo "failures = Termination FAILED" > failures.properties
					exit 1
				fi

				echo '[*] PIPELINE SUCCESS'
				exit
				'''
			}
		}

        stage ('Running Ansible Jobs') {
			steps {
				build job: 'RunAnsibleJobs', wait: false
			}
		}

        stage ('Trigger Update LogicMonitor') {
			steps {
				build job: 'UpdateLogicMonitor', wait: false
			}
		}

        stage ('Trigger Verification Job') {
			steps {
			    script {
			        HAS_STARTED_VERIFY = true
			    }
				build job: 'Verify Production Deployment', parameters: [[$class: 'GitParameterValue', name: 'Branch', value: "${env.BRANCH_SCOPE}"]]
			}
		}

		
    }

    post {
        aborted {
            script {
                echo "Build was ABORTED.  Reverting..."

                if (IS_POST_SWAP == true) {
                    echo "Swapping URLs back to original setting..."

					sh '''#!/bin/bash
					set -e
					set -x
					
					sleep 61

					#Get Blue/green environment names
					source ./blueGreenVars

					# Swap URLS BLUE to GREEN --> Roll back. Everything needs to go backwards.
					#
					echo '[*] Swapping CNAME Urls from ' $NEW_ENVIRONMENT_NAME ' to ' $NEW_ENVIRONMENT_NAME
					SWAP_STATUS=$(eb swap $ENVIRONMENT_NAME -v -n $NEW_ENVIRONMENT_NAME)
					sleep 3

					# Error handling: Swap
					if echo "${SWAP_STATUS}" | grep -q "Completed swapping CNAMEs for environments"; then
						echo "[*] URL Swap Succeeded!:: "
					else
						echo "[*] URL Swap Failed!:: "
						echo "failures = URL Swap FAILED" > failures.properties
						echo "Contact DevOps to inspect the system"
						exit 1
					fi

					# Get instance count for blue old environment
					INSTANCE_COUNT=$(aws elasticbeanstalk describe-environment-resources --environment-name $ENVIRONMENT_NAME | jq '.EnvironmentResources.Instances' | jq length)
					declare -a BLUE_INSTANCE_LIST
					# Get instance ids of blue environment
					for ((i=1;i<INSTANCE_COUNT+1;i++))
					do
						echo $i
						j=$i-1
						BLUE_INSTANCE_LIST[$i]=$(aws elasticbeanstalk describe-environment-resources --environment-name $ENVIRONMENT_NAME | jq '.EnvironmentResources.Instances['$j'].Id' | tr -d '"')
						echo ${BLUE_INSTANCE_LIST[$i]}
					done

					# Register targets
					for i in "${BLUE_INSTANCE_LIST[@]}"
					do
						echo "$i"
						aws elbv2 register-targets --target-group-arn $BLUE_TARGET_GROUP_ARN --targets Id="$i"
					done

					# Get amount of green (new) instances
					INSTANCE_COUNT=$(aws elasticbeanstalk describe-environment-resources --environment-name $NEW_ENVIRONMENT_NAME | jq '.EnvironmentResources.Instances' | jq length)
					# Get list of green instance id's
					declare -a GREEN_INSTANCE_LIST
					for ((i=1;i<INSTANCE_COUNT+1;i++))
					do
						echo $i
						j=$i-1
						GREEN_INSTANCE_LIST[$i]=$(aws elasticbeanstalk describe-environment-resources --environment-name $NEW_ENVIRONMENT_NAME| jq '.EnvironmentResources.Instances['$j'].Id' | tr -d '"')
						echo ${GREEN_INSTANCE_LIST[$i]}
					done

					# Remove targets from green target group and put in blue target group
					for i in "${GREEN_INSTANCE_LIST[@]}"
					do
						echo "$i"
						aws elbv2 deregister-targets --target-group-arn $BLUE_TARGET_GROUP_ARN --targets Id="$i"
					done

					sleep 5

					'''
                }
                
                if (IS_POST_WORKER == true) {
                    echo "Dispatching 'Deploy Master to Worker' ... "
                    build job: 'Deploy Master to Worker'
                }
                
                if (IS_POST_CLONE == true) {
                    echo "Destroy Non-Live Beanstalk"
					sh '''#!/bin/bash
					set -e
					set -x

					#Get Blue/green environment names
					source ./blueGreenVars

					# Get Cloudformation Stack name for new  beanstalk environment
					STACK_NAME=$(aws elasticbeanstalk describe-environment-resources --environment-name $NEW_ENVIRONMENT_NAME | jq '.EnvironmentResources.AutoScalingGroups[].Name' | tr -d '"' | cut -d '-' -f 1-4)
					STACK_NAME="$STACK_NAME-AWSEBSecurityGroup"

					#Use stack name to get new security group id
					SECURITY_GROUP_ID=$(aws ec2 describe-security-groups --filters Name=group-name,Values="$STACK_NAME*" | jq '.SecurityGroups' | jq -r '.[].GroupId')

					# Delete RDS SG Ingress Rule for new environment
					aws ec2 revoke-security-group-ingress --group-id $RDS_SECURITY_GROUP_ID --protocol tcp --port 3306 --source-group $SECURITY_GROUP_ID

					#Terminate New Environment
					echo '[*] Terminating Original Environment: ' $NEW_ENVIRONMENT_NAME
					TERMINATE_STATUS=$(eb terminate $NEW_ENVIRONMENT_NAME -v  --force)

					# Error handling Terminate
					if echo "${TERMINATE_STATUS}" | grep -q "terminateEnvironment completed successfully"; then
						echo "[*] New Environment Terminated Successfully!:: "
					else
						echo "[*] Termination Failed!:: Environment: " $NEW_ENVIRONMENT_NAME
						echo "failures = Termination FAILED" > failures.properties
						echo "Contact DevOps to inspect the system"
					exit 1
					fi

					echo '[*] PIPELINE SUCCESS'
					exit
					'''                
				}
            }
        }
		failure {
            script {
                echo "Build was a FAILURE.  Reverting..."

                if (IS_POST_WORKER == true && HAS_STARTED_VERIFY == false) {
                    echo "Dispatching 'Deploy Master to Worker' ... "
                    build job: 'Deploy Master to Worker'
                }
				
                if (HAS_STARTED_CLONE == true && IS_POST_SWAP == false) {
                    echo "Destroy Non-Live Beanstalk"
					sh '''#!/bin/bash
					set -e
					set -x

					#Get Blue/green environment names
					source ./blueGreenVars

					# Get Cloudformation Stack name for new  beanstalk environment
					STACK_NAME=$(aws elasticbeanstalk describe-environment-resources --environment-name $NEW_ENVIRONMENT_NAME | jq '.EnvironmentResources.AutoScalingGroups[].Name' | tr -d '"' | cut -d '-' -f 1-4)
					STACK_NAME="$STACK_NAME-AWSEBSecurityGroup"

					#Use stack name to get new security group id
					SECURITY_GROUP_ID=$(aws ec2 describe-security-groups --filters Name=group-name,Values="$STACK_NAME*" | jq '.SecurityGroups' | jq -r '.[].GroupId')

					# Delete RDS SG Ingress Rule for new environment
					aws ec2 revoke-security-group-ingress --group-id $RDS_SECURITY_GROUP_ID --protocol tcp --port 3306 --source-group $SECURITY_GROUP_ID

					#Terminate New Environment
					echo '[*] Terminating Original Environment: ' $NEW_ENVIRONMENT_NAME
					TERMINATE_STATUS=$(eb terminate $NEW_ENVIRONMENT_NAME -v  --force)

					# Error handling Terminate
					if echo "${TERMINATE_STATUS}" | grep -q "terminateEnvironment completed successfully"; then
						echo "[*] New Environment Terminated Successfully!:: "
					else
						echo "[*] Termination Failed!:: Environment: " $NEW_ENVIRONMENT_NAME
						echo "failures = Termination FAILED" > failures.properties
						echo "Contact DevOps to inspect the system"
					fi

					echo '[*] PIPELINE SUCCESS'
					exit
					'''                
				}
			}
		}
		cleanup {
			deleteDir()
		}
    }
}
