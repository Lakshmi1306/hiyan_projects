#!/bin/sh

echo "This is ONLY to be used to deploy to a green environment!"
echo "If doing that, you need to edit this config and comment out the exit"
exit 1