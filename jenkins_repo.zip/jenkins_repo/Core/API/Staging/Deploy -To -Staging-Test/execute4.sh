#!/bin/sh


######
## DEPLOYMENT
######
LOWERCASE_ENV="$(echo ${Environment} | tr '[:upper:]' '[:lower:]' 2>&1)"

APP_ENVIRONMENT="API-${Environment}"
SQS_PREFIX="${Environment}"
EBFOLDER="staging"
AWS_BUCKET_POSTFIX="${LOWERCASE_ENV}"
CONSUMER_SITE_BASE_URL="https://${LOWERCASE_ENV}.39u6rtyj29.us-west-2.elasticbeanstalk.com/"
LEGACY_DOMAIN="www.puppyspot.preprod"
RDS_SNAPSHOT_NAME="uat-stage-20180814"


if echo "${Environment}" | grep -q "Stage-02"; then
    RDS_SNAPSHOT_NAME="api-stage-01-20190215"
fi

if echo "${Environment}" | grep -q "Stage-03"; then
    RDS_SNAPSHOT_NAME="api-stage-01-20190215"
fi

if echo "${Environment}" | grep -q "Stage-04"; then
    RDS_SNAPSHOT_NAME="api-stage-01-20190215"
fi

if echo "${Environment}" | grep -q "Eng-01"; then
    RDS_SNAPSHOT_NAME="api-stage-01-20190919"
fi

if echo "${Environment}" | grep -q "Eng-02"; then
    RDS_SNAPSHOT_NAME="api-stage-01-20190919"
    #REDIS_CLUSTER_NAME="eng-02-cluster"
fi

if echo "${Environment}" | grep -q "green"; then
	CLOUDSEARCH_BREED_DOMAIN="doc-green-breeds-dtx3xbowqzoxf4vfdw2fclh3by.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="doc-green-external-listings-shlb3zr3o3aqhsey7pz37ym2ny.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="doc-green-internal-listings-gw2cl2o7fdkkr7yxtu3sw34ldm.us-west-2.cloudsearch.amazonaws.com"
    CLOUDSEARCH_PLM_LISTING_DOMAIN="doc-green-plm-listings-ravxksmeq5wc6gvsg2ziav6cna.us-west-2.cloudsearch.amazonaws.com"
    RDS_SNAPSHOT_NAME="api-stage-01-20190919"
fi

if echo "${Environment}" | grep -q "sandbox"; then
    RDS_SNAPSHOT_NAME="api-stage-01-20190919"
fi

if echo "${Environment}" | grep -q "load"; then
    RDS_SNAPSHOT_NAME="api-stage-01-20190919"
fi



if echo "${Environment}" | grep -q "UAT-stage"; then
	LOWERCASE_ENV="stage"
	APP_ENVIRONMENT="${Environment}"
    SQS_PREFIX="UAT"
	EBFOLDER="uat"
	AWS_BUCKET_POSTFIX="stage"
    CONSUMER_SITE_BASE_URL="https://consumer-stage.39u6rtyj29.us-west-2.elasticbeanstalk.com"
	CLOUDSEARCH_BREED_DOMAIN="doc-stage-breeds-fgmuuzvp7uyijmv4yk5mvtfzxi.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="doc-search-uat-external-listings-f5mybnaai3epbkupov2yhl27ze.us-west-2.cloudsearch.amazonaws.com"
	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="doc-search-uat-internal-listings-yukkzkayeddwnbvkvq4kwcnmba.us-west-2.cloudsearch.amazonaws.com"
    CLOUDSEARCH_PLM_LISTING_DOMAIN="doc-stage-plm-listings-b5lmnvahy26vskip63aosx7i3i.us-west-2.cloudsearch.amazonaws.com"
fi

AWS_SUFFIX="${LOWERCASE_ENV}"
CONSUMER_HOST="consumer-${LOWERCASE_ENV}"


# Add the param for the location of the Consumer site for Yotpo:
echo "Setting Consumer Site URL to ${CONSUMER_SITE_BASE_URL}"
echo "\nCONSUMER_SITE_BASE_URL=${CONSUMER_SITE_BASE_URL}\n" >> .env.staging
echo "\nCONSUMER_SITE_BASE_URL=${CONSUMER_SITE_BASE_URL}\n" >> .env.uat

echo "\nAWS_LOW_PRIORITY_JOB_QUEUE=${SQS_PREFIX}-Low-Priority-Queue\nAWS_LOW_PRIORITY_JOB_DLQ=${SQS_PREFIX}-Low-Priority-DLQ\nAWS_JOB_QUEUE=${SQS_PREFIX}-Job-Queue\nAWS_JOB_DLQ=${SQS_PREFIX}-Job-DLQ\nAWS_MAIL_QUEUE=${SQS_PREFIX}-Mail-Queue\nAWS_MAIL_DLQ=${SQS_PREFIX}-Mail-DLQ\nAWS_SEARCH_UPDATE_JOB_QUEUE=${SQS_PREFIX}-Search-Update-Job-Queue\nAWS_SEARCH_UPDATE_JOB_DLQ=${SQS_PREFIX}-Search-Update-DLQ\nAWS_LEAD_QUEUE=${SQS_PREFIX}-Lead-Queue\nAWS_LEAD_DLQ=${SQS_PREFIX}-Lead-DLQ\nAWS_IMAGE_PROCESSING_QUEUE=${SQS_PREFIX}-Image-Processing-Queue\nAWS_IMAGE_PROCESSING_DLQ=${SQS_PREFIX}-Image-Processing-DLQ\nAWS_TALLY_QUEUE=${SQS_PREFIX}-Tally-Queue\nAWS_TALLY_DLQ=${SQS_PREFIX}-Tally-DLQ\nAWS_MONITOR_JOB_QUEUE=${SQS_PREFIX}-Monitor-Job-Queue\nAWS_MONITOR_JOB_DLQ=${SQS_PREFIX}-Monitor-Job-DLQ\nAWS_ACCOUNTING_INTEGRATION_QUEUE=${SQS_PREFIX}-Accounting-Integration-Queue\nAWS_ACCOUNTING_INTEGRATION_DLQ=${SQS_PREFIX}-Accounting-Integration-DLQ\nAWS_CUSTOMER_CHAT_QUEUE=${SQS_PREFIX}-Customer-Chat-Queue\nAWS_CUSTOMER_CHAT_DLQ=${SQS_PREFIX}-Customer-Chat-DLQ\nAWS_ORDER_SYNC_QUEUE=${SQS_PREFIX}-Order-Sync-Queue\nAWS_ORDER_SYNC_DLQ=${SQS_PREFIX}-Order-Sync-DLQ\nAWS_CONSUMER_CACHE_QUEUE=${SQS_PREFIX}-Consumer-Cache-Queue\nAWS_CONSUMER_CACHE_DLQ=${SQS_PREFIX}-Consumer-Cache-DLQ\nAWS_LOGGING_QUEUE=${SQS_PREFIX}-Logging-Queue\nAWS_LOGGING_DLQ=${SQS_PREFIX}-Logging-DLQ\n" >> .env.staging
echo "\nAWS_MEDIA_BUCKET=puppyspot-photos-${AWS_BUCKET_POSTFIX}\nAWS_BREEDER_BUCKET=puppyspot-breeder-uploads-${AWS_BUCKET_POSTFIX}\nAWS_FILE_UPLOADS_BUCKET=puppyspot-files-${AWS_BUCKET_POSTFIX}\n\n" >> .env.staging

echo "CLOUDSEARCH_INTERNAL_LISTING_DOMAIN=${CLOUDSEARCH_INTERNAL_LISTING_DOMAIN}\n" >> .env.staging
echo "CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN=${CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN}\n" >> .env.staging
echo "CLOUDSEARCH_PLM_LISTING_DOMAIN=${CLOUDSEARCH_PLM_LISTING_DOMAIN}\n" >> .env.staging
echo "CLOUDSEARCH_BREED_DOMAIN=${CLOUDSEARCH_BREED_DOMAIN}\n" >> .env.staging



git add .env.staging
git add .env.uat


# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Staging only configuration files in
cp -R .elasticbeanstalk/extensions/${EBFOLDER}/* ./.ebextensions/

sed -i 's/<---StageNameREPLACE-->/'"${APP_ENVIRONMENT}"'/g' .ebextensions/* > /dev/null
sed -i 's/<---StageLayerNameREPLACE-->/'"${Environment}"'/g' .ebextensions/* > /dev/null
sed -i 's/<---SqsPrefixREPLACE-->/'"${Environment}"'/g' .ebextensions/supervisor/queue_worker.conf > /dev/null
sed -i 's/<---SnapshotNameREPLACE-->/'"${RDS_SNAPSHOT_NAME}"'/g' .ebextensions/* > /dev/null

#sed -i 's/<---RedisClusterNameREPLACE-->/'"${REDIS_CLUSTER_NAME}"'/g' .ebextensions/* > /dev/null

git add .ebextensions/*

git commit -m "Pre-deploy commit"



#
# Check if environment exists. If not, create it..
#
if eb status ${APP_ENVIRONMENT} | grep -q "ERROR: NotFoundError"; then
    echo "Environment \"${APP_ENVIRONMENT}\" does not exist. Creating... Expect 20 minute wait.\n";
    DEPLOYMENT="$(eb create ${APP_ENVIRONMENT} --cfg stage --timeout 30 2>&1)"
    if echo "${DEPLOYMENT}" | grep -q "Successfully launched environment"; then
        echo "Deployment+Creation SUCCEEDED!:: "
        echo "${DEPLOYMENT}"
    else
	    echo "Deployment+Creation FAILED!:: "
        echo "${DEPLOYMENT}"
        exit 1
    fi
    return;
fi

#
# Environment already exists. Just Deploy
#


eb use ${APP_ENVIRONMENT}
MYHOST=$(eb status ${APP_ENVIRONMENT} | grep "  CNAME: " | cut -f2 -d: | cut -f2 -d' ');

echo "host = http\://${MYHOST}" > host.properties

echo "Deploying new code now."
DEPLOYMENT="$(eb deploy --timeout 45 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "Deployment SUCCEEDED!:: "
    echo "${DEPLOYMENT}"
else
	echo "Deployment FAILED!:: "
    echo "${DEPLOYMENT}"
    exit 1
fi