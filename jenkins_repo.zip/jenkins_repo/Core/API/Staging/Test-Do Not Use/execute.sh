#!/bin/bash

Environment="prod"

echo "Running playbook..."

cd /etc/ansible/playbooks

ansible-playbook  -b -i /etc/ansible/inventories/Blue-Green/instances/API-hosts modifyBashPrompt.yml --extra-vars "target=$Environment"