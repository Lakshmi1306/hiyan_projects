#!/bin/sh
### No longer used
echo "This build job is disabled! "
echo "Please use the blue-green pipeline instead."
echo "If you are deploying to the green instance, then you need to modify this config."
#exit 1;