#!/bin/sh
#Need to update environment name
echo "You need to get the environment name of the current consumer-prod-XXXXX server. "
echo "Then you will need to update this job before you can run it. "
echo "This will require DevOps assistance! "
#exit 1