# Update required libs
# npm cache clear
npm install

# Do frontend build
npm run production

