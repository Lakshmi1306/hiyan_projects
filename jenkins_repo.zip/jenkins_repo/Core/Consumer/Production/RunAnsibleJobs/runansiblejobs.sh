#!/bin/bash


# Update Hostfile
echo "Updating hostfile..."
sudo /bin/bash /scripts/update-hosts-file.sh
sudo /bin/bash /scripts/update-blue-green-inventory.sh

Environment="prod"

echo "Running playbook..."

cd /etc/ansible/playbooks

# Modifies bash prompt to show the Environment Name @Consumer-prod-XXXX
ansible-playbook  -b -i /etc/ansible/inventories/Blue-Green/instances/consumer-hosts modifyBashPrompt.yml --extra-vars "target=$Environment"

# Adds Stackify log rotation
ansible-playbook -i /etc/ansible/inventories/Blue-Green/instances/consumer-hosts stackifyLogrotate.yml