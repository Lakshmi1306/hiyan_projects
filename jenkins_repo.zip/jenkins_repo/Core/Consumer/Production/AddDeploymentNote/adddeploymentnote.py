#!/bin/env python
import boto3
import requests
import json
import hashlib
import base64
import time
import hmac

# Variable list
TARGET_GROUP_ARN = 'arn:aws:elasticloadbalancing:us-west-2:172136542978:targetgroup/puppyspot-targets-core-prod/cc8f9632739f7370'

# Function List

# Retrieves a list of Target Group IDs
def GetTargetGroupIds(TARGET_GROUP_ARN):
    target_group_ids = []
    client = boto3.client('elbv2')
    target_group_config = client.describe_target_health(TargetGroupArn = TARGET_GROUP_ARN)
    target_group_config = target_group_config['TargetHealthDescriptions']

    for config in target_group_config:
        target_group_ids.append(config['Target']['Id'])

    return target_group_ids

def GetLMDeviceData(target_group_ids,device_property):
    # Account Info
    AccessId = "Cw7kpg5fm6vxyfLnsfME"
    AccessKey = "-~A5]zxrg2s2b3%2eT]9k7=4%52^I362~58HC9tj"
    Company = "puppyspot"

    # Array of Ids:
    instance_ids = []
    incrementor = 1

    for instance in target_group_ids:
        #Request Info
        httpVerb ='GET'
        resourcePath = '/device/devices/'
        queryParams ='?filter=displayName~Consumer-Prod-' +str(incrementor) +'&fields=' + device_property
        data = ''

        #Construct URL
        url = 'https://'+ Company +'.logicmonitor.com/santaba/rest' + resourcePath + queryParams

        #Get current time in milliseconds
        epoch = str(int(time.time() * 1000))

        #Concatenate Request details
        requestVars = httpVerb + epoch + data + resourcePath

        #Construct signature
        signature = base64.b64encode(hmac.new(AccessKey,msg=requestVars,digestmod=hashlib.sha256).hexdigest())

        #Construct headers
        auth = 'LMv1 ' + AccessId + ':' + signature + ':' + epoch
        headers = {'Content-Type':'application/json','Authorization':auth}

        #Make request
        response = requests.get(url, data=data, headers=headers)
        response = response.content
        response = json.loads(response)
        ids = response['data']['items']
        for id in ids:
           id = id[device_property]
           instance_ids.append(id)

        incrementor = incrementor + 1

    return instance_ids

def AddOpsNote(id):
    #Account Info
    AccessId = "Cw7kpg5fm6vxyfLnsfME"
    AccessKey = "-~A5]zxrg2s2b3%2eT]9k7=4%52^I362~58HC9tj"
    Company = "puppyspot"

    for id in device_ids:
        #Request Info
        httpVerb ='POST'
        resourcePath = '/setting/opsnotes'
        queryParams =''
        data = '{"note":"Deployment Occurred Here","tags":[{"name":"reporting"}],"scopes":[{"type":"device","deviceId":' + str(id) + '}]}'

        #Construct URL
        url = 'https://'+ Company +'.logicmonitor.com/santaba/rest' + resourcePath +queryParams

        #Get current time in milliseconds
        epoch = str(int(time.time() * 1000))

        #Concatenate Request details
        requestVars = httpVerb + epoch + data + resourcePath

        #Construct signature
        signature = base64.b64encode(hmac.new(AccessKey,msg=requestVars,digestmod=hashlib.sha256).hexdigest())

        #Construct headers
        auth = 'LMv1 ' + AccessId + ':' + signature + ':' + epoch
        headers = {'Content-Type':'application/json','Authorization':auth}

        #Make request
        response = requests.post(url, data=data, headers=headers)

        #Print status and body of response
        print 'Response Status:',response.status_code
        print 'Response Body:',response.content

# Program Start

target_group_ids = GetTargetGroupIds(TARGET_GROUP_ARN)
device_ids = GetLMDeviceData(target_group_ids, 'id')
AddOpsNote(device_ids)
