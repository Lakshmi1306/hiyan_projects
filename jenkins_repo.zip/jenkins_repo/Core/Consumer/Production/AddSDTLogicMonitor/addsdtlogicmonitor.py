import json
import boto3
import datetime
import requests
import os
import time
import hashlib
import base64
import hmac

# Global Vars
NAME = 'consumer-prod-'
TARGET_GROUP_ARN = 'arn:aws:elasticloadbalancing:us-west-2:172136542978:targetgroup/puppyspot-targets-core-prod/cc8f9632739f7370'

# LogicMonitor jenkinsapi API account information (AccessID, AccessKey,Company)
AccessId = "yB7MX749iFf5pvZq3V96"
AccessKey = "z_VvU+h2j35m645kPzFN(]cuE9-S5}C-4(SJYp)3"
Company = "puppyspot"

# Function Definitions - Start

# Retrieves the name of the current Prod Environment
def GetEnvName(NAME):
    client = boto3.client('elasticbeanstalk',region_name='us-west-2')
    response = client.describe_environments()

    # Get Environments
    envs = response['Environments']

    for env in envs:
      
      env_name = env['EnvironmentName']
      
      if env_name == 'Worker' or 'CNAME' not in env or env['Status'] != "Ready":
          continue
          
      print(env_name)
      env_dns = env['CNAME']
      
      if NAME in env_name:
        env_health_response = client.describe_environment_health(EnvironmentName = env_name, AttributeNames=['All'])  
        print("This is the CNAME:")
        print(env_dns)
        
        if (env_dns == "psconsumerprod.us-west-2.elasticbeanstalk.com") and env_health_response['Status'] == "Ready":
            return env_name

    return "FAIL"


# Retrieves the name of the Autoscaling Group attached to the Environment
def GetAutoScalingGroupName(env_name):
    client = boto3.client('elasticbeanstalk',region_name='us-west-2')
    env_resources = client.describe_environment_resources(EnvironmentName=env_name)
    env_resources = env_resources['EnvironmentResources']

    for autoscaling_name in env_resources['AutoScalingGroups']:
        autoscaling_group_name = autoscaling_name['Name']

    return autoscaling_group_name

# Retrieves a list of AutoScaling Group IDs (from Elastic Beanstalk)
def GetAutoScalingInstanceIDs(autoscaling_group_name):
    autoscaling_instance_ids = []
    client = boto3.client('autoscaling')
    autoscaling_instance_config = client.describe_auto_scaling_groups(AutoScalingGroupNames=[autoscaling_group_name])
    autoscaling_instance_config  = autoscaling_instance_config ['AutoScalingGroups']
    for config in autoscaling_instance_config:
        autoscaling_instances = config['Instances']

    for instance in autoscaling_instances:
        autoscaling_instance_ids.append(instance['InstanceId'])

    return autoscaling_instance_ids

# Retrieves a list of Target Group IDs
def GetTargetGroupIds(TARGET_GROUP_ARN):
    target_group_ids = []
    client = boto3.client('elbv2')
    target_group_config = client.describe_target_health(TargetGroupArn = TARGET_GROUP_ARN)
    target_group_config = target_group_config['TargetHealthDescriptions']

    for config in target_group_config:
        target_group_ids.append(config['Target']['Id'])

    return target_group_ids

def GetLMDeviceData(target_group_ids,device_property):
    # Array of Ids:
    instance_ids = []
    incrementor = 1

    for instance in target_group_ids:
        #Request Info
        httpVerb ='GET'
        resourcePath = '/device/devices/'
        queryParams ='?filter=displayName~Consumer-Prod-' +str(incrementor) +'&fields=' + device_property
        data = ''

        #Construct URL
        url = 'https://'+ Company +'.logicmonitor.com/santaba/rest' + resourcePath + queryParams

        #Get current time in milliseconds
        epoch = str(int(time.time() * 1000))

        #Concatenate Request details
        requestVars = httpVerb + epoch + data + resourcePath

        #Construct signature
        signature = base64.b64encode(hmac.new(AccessKey,msg=requestVars,digestmod=hashlib.sha256).hexdigest())

        #Construct headers
        auth = 'LMv1 ' + AccessId + ':' + signature + ':' + epoch
        headers = {'Content-Type':'application/json','Authorization':auth}

        #Make request
        response = requests.get(url, data=data, headers=headers)
        response = response.content
        response = json.loads(response)
        ids = response['data']['items']
        for id in ids:
           id = id[device_property]
           instance_ids.append(id)

        incrementor = incrementor + 1

    return instance_ids


def AddSDT(device_ids):
    # Setting up SDT Start and End time = 1 hour.

    start_time = int(round(time.time() * 1000))
    end_time = start_time + 3600000
    start_time = str(start_time)
    end_time = str(end_time)

    print("Adding SDTs...")
    for id in device_ids:
        #Request Info
        httpVerb ='POST'
        resourcePath = '/sdt/sdts'
        data = '{"sdtType":1,"type":"DeviceSDT","deviceId":' + str(id) + ',"startDateTime":' + start_time +',"endDateTime":' + end_time + '}'

        #Construct URL
        url = 'https://'+ Company +'.logicmonitor.com/santaba/rest' + resourcePath

        #Get current time in milliseconds
        epoch = str(int(time.time() * 1000))

        #Concatenate Request details
        requestVars = httpVerb + epoch + data + resourcePath

        #Construct signature
        signature = base64.b64encode(hmac.new(AccessKey,msg=requestVars,digestmod=hashlib.sha256).hexdigest())

        #Construct headers
        auth = 'LMv1 ' + AccessId + ':' + signature + ':' + epoch
        headers = {'Content-Type':'application/json','Authorization':auth}

        #Make request
        response = requests.post(url, data=data, headers=headers)

        #Print status and body of response
        print 'Response Status:',response.status_code
        print 'Response Body:',response.content


# Program - Start

env_name = GetEnvName(NAME)

if env_name == "FAIL":
  print("Failed to get valid environment name..Exiting.")
  quit()

autoscaling_group_name = GetAutoScalingGroupName(env_name)
autoscaling_instance_ids = GetAutoScalingInstanceIDs(autoscaling_group_name)
target_group_ids = GetTargetGroupIds(TARGET_GROUP_ARN)
device_ids = GetLMDeviceData(target_group_ids, 'id')
AddSDT(device_ids)




