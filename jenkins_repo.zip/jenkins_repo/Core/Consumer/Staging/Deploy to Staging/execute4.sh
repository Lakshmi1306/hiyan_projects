#!/bin/sh


######
## DEPLOYMENT
######

LOWERCASE_ENV="$(echo ${Environment} | tr '[:upper:]' '[:lower:]' 2>&1)"

SQS_PREFIX="${Environment}"
APP_ENVIRONMENT="Consumer-${Environment}"
MEMCACHED_HOST="api-${LOWERCASE_ENV}"
CORE_API_HOST="https://api-${LOWERCASE_ENV}.puppyspot.com"
LEGACY_HOST="https://www.puppyspot.preprod"
AWS_BUCKET_POSTFIX="${LOWERCASE_ENV}"
CDN_URL="https://core-${LOWERCASE_ENV}.pupcdn.com/"

# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Staging only configuration files in
cp -R .elasticbeanstalk/extensions/staging/* ./.ebextensions/

sed -i 's/<---StageNameREPLACE-->/'"${APP_ENVIRONMENT}"'/g' .ebextensions/* > /dev/null
sed -i 's/<---StageLayerNameREPLACE-->/'"${Environment}"'/g' .ebextensions/* > /dev/null

# Add the param for the location of the Core API Base URI:
echo "Setting Core API Base URI to ${CORE_API_HOST}"
echo "\n\nCORE_API_BASE_URI=${CORE_API_HOST}\n" >> .env.staging

echo "\nAWS_LOW_PRIORITY_JOB_QUEUE=${SQS_PREFIX}-Low-Priority-Queue\nAWS_LOW_PRIORITY_JOB_DLQ=${SQS_PREFIX}-Low-Priority-DLQ\nAWS_JOB_QUEUE=${SQS_PREFIX}-Job-Queue\nAWS_JOB_DLQ=${SQS_PREFIX}-Job-DLQ\nAWS_MAIL_QUEUE=${SQS_PREFIX}-Mail-Queue\nAWS_MAIL_DLQ=${SQS_PREFIX}-Mail-DLQ\nAWS_SEARCH_UPDATE_JOB_QUEUE=${SQS_PREFIX}-Search-Update-Job-Queue\nAWS_SEARCH_UPDATE_JOB_DLQ=${SQS_PREFIX}-Search-Update-DLQ\nAWS_LEAD_QUEUE=${SQS_PREFIX}-Lead-Queue\nAWS_LEAD_DLQ=${SQS_PREFIX}-Lead-DLQ\nAWS_IMAGE_PROCESSING_QUEUE=${SQS_PREFIX}-Image-Processing-Queue\nAWS_IMAGE_PROCESSING_DLQ=${SQS_PREFIX}-Image-Processing-DLQ\nAWS_TALLY_QUEUE=${SQS_PREFIX}-Tally-Queue\nAWS_TALLY_DLQ=${SQS_PREFIX}-Tally-DLQ\nAWS_MONITOR_JOB_QUEUE=${SQS_PREFIX}-Monitor-Job-Queue\nAWS_MONITOR_JOB_DLQ=${SQS_PREFIX}-Monitor-Job-DLQ\nAWS_ACCOUNTING_INTEGRATION_QUEUE=${SQS_PREFIX}-Accounting-Integration-Queue\nAWS_ACCOUNTING_INTEGRATION_DLQ=${SQS_PREFIX}-Accounting-Integration-DLQ\nAWS_CUSTOMER_CHAT_QUEUE=${SQS_PREFIX}-Customer-Chat-Queue\nAWS_CUSTOMER_CHAT_DLQ=${SQS_PREFIX}-Customer-Chat-DLQ\nAWS_ORDER_SYNC_QUEUE=${SQS_PREFIX}-Order-Sync-Queue\nAWS_ORDER_SYNC_DLQ=${SQS_PREFIX}-Order-Sync-DLQ\n" >> .env.staging

# Add the params for the CloudSearch domain:
echo "\nCLOUDSEARCH_INTERNAL_LISTING_DOMAIN=https://${CLOUDSEARCH_INTERNAL_LISTING_DOMAIN}\n" >> .env.staging
echo "CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN=https://${CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN}" >> .env.staging
echo "CLOUDSEARCH_BREED_DOMAIN=https://${CLOUDSEARCH_BREED_DOMAIN}\n" >> .env.staging

echo "\nAWS_MEDIA_BUCKET=puppyspot-photos-${AWS_BUCKET_POSTFIX}\nAWS_BREEDER_BUCKET=puppyspot-breeder-uploads-${AWS_BUCKET_POSTFIX}\n\n" >> .env.staging

# Add the params for other hosts and domains:
echo "\nLEGACY_HOST=${LEGACY_HOST}\n" >> .env.staging
echo "\nCOOKIE_DOMAIN=${COOKIE_DOMAIN}\n" >> .env.staging

# Add the param for the CDN URL:
echo "\nCDN_URL=${CDN_URL}\n" >> .env.staging

# Add the param for the location of the Core API Base URI:
echo "\nMEMCACHED_HOST=${MEMCACHED_HOST}.bjszcv.0001.usw2.cache.amazonaws.com\nMEMCACHED_PORT=11211\n\n" >> .env.staging

git add .env.staging

git add public/. --force
git add .ebextensions/*
git commit -m "Pre-deploy commit"

#
# Check if environment exists. If not, create it..
#
if eb status ${APP_ENVIRONMENT} | grep -q "ERROR: NotFoundError"; then
    echo "Environment \"${APP_ENVIRONMENT}\" does not exist. Creating... Expect 20 minute wait.\n";
    DEPLOYMENT="$(eb create ${APP_ENVIRONMENT} --cfg stage --timeout 30 2>&1)"
    if echo "${DEPLOYMENT}" | grep -q "Successfully launched environment"; then
        echo "Deployment+Creation SUCCEEDED!:: "
        echo "${DEPLOYMENT}"
    else
	    echo "Deployment+Creation FAILED!:: "
        echo "${DEPLOYMENT}"
        exit 1
    fi
    return;
fi

#
# Environment already exists. Just Deploy
#

eb use ${APP_ENVIRONMENT}
MYHOST=$(eb status ${APP_ENVIRONMENT} | grep "  CNAME: " | cut -f2 -d: | cut -f2 -d' ');

echo "host = http\://${MYHOST}" > host.properties

DEPLOYMENT="$(eb deploy --timeout 45 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "Deployment SUCCEEDED!:: "
    echo "${DEPLOYMENT}"
else
	echo "Deployment FAILED!:: "
    echo "${DEPLOYMENT}"
    exit 1
fi