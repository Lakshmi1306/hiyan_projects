#!/bin/sh
#
# Check if environment is Ready. If not, abort.. (Only if environment exists. If it doesn't, it will be created later)
#
# echo user to see who is executing these builds
echo $USER

if eb status Consumer-${Environment} | grep -q "Status: Ready"; then
    exit 1
else
    if eb status Consumer-${Environment} | grep -q "ERROR: NotFoundError"; then
    	# Nothing to do. Environment doesn't exist, but will be created later during deployment.
        exit 1
    else
	echo "Environment \"Consumer-${Environment}\" NOT Ready. Aborting!\n";
    	exit 0
    fi
fi