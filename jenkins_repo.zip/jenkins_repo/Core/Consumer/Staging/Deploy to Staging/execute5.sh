#!/bin/bash

# Update Hostfile
echo "Updating hostfile..."
sudo /bin/bash /scripts/update-hosts-file.sh

Environment="Consumer-${Environment}"

echo "This is the Environment: ${Environment}"

echo "Running playbook..."

cd /etc/ansible/playbooks

ansible-playbook  -b -i /etc/ansible/inventories/Consumer/instances/hosts modifyBashPrompt.yml --extra-vars "target=$Environment"