#!/bin/sh

######
## BUILD/TEST
######

# Prepare build environment (dont change this, workaround to prevent stderr)
mkdir -p ../jenkinsbuilddir
cp -R . ../jenkinsbuilddir/
mv ../jenkinsbuilddir ./
cd ./jenkinsbuilddir

# Update required libs
composer install
composer dumpautoload

# Update required libs
npm cache clear
npm install

# Do frontend build
npm run production
# gulp


# Run Unit Tests
UNITTESTS="$(./vendor/bin/phpunit --testsuite Unit --log-junit ../results/phpunit/phpunit.xml 2>&1)"
#  --testsuite Unit

# Copy Compiled assets
cp -R public/* ../public/
# Clean Build dir
cd ..
rm -R ./jenkinsbuilddir/

# Check Unit Test Status AFTER we've injected the environment variables
if echo "${UNITTESTS}" | grep -q "OK ("; then
    echo "Unit Tests PASSED!:: "
    echo "${UNITTESTS}"
else
	echo "Unit Tests FAILED!:: "
    echo "${UNITTESTS}"
    exit 1
fi