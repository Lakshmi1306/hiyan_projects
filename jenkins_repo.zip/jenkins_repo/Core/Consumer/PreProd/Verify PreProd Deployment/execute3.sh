#!/bin/sh

# Create a tag
TAG="CON_PREPROD_BUILD_${BUILD_NUMBER}"
CREATETAG="$(git tag ${TAG} 2>&1)"

echo "Attempted to create tag: ${TAG}"

GITTAG="$(git tag 2>&1)"
if echo "${GITTAG}" | grep -q "${TAG}"; then
    echo "Tag created successfully, continuing:: "
else
	echo "ERROR: git failed to generate tag:: "
    echo "${GITTAG}"
    echo "failures = ERROR: git failed to generate tag" > failures.properties
    exit 1
fi

# Push new tag
GITPUSHTAG="$(git push origin ${TAG} 2>&1)"
if echo "${GITPUSHTAG}" | grep -q "${TAG} -> ${TAG}"; then
    echo "Tag pushed successfully, continuing:: "
else
	echo "ERROR: git failed to push tag to origin:: "
    echo "${GITPUSHTAG}"
    echo "failures = ERROR: git failed to push tag to origin" > failures.properties
    exit 1
fi