#!/bin/sh

### Create Pull Request into master

PR="$(php ~/jenkinsgit/jenkinsgit.php -rCONSUMER --create-pull-request --source="${Branch}" --dest="master" 2>&1)"
if echo "${PR}" | grep -q "^success$"; then
    echo "Pull request created!"
else
	echo "ERROR: Failed to create Pull Request!:: "
    echo "${PR}"
    echo "failures = ERROR: Failed to create Pull Request" > failures.properties
    exit 1
fi