# Update required libs
npm cache clear
npm install

# Do frontend build
gulp --production

