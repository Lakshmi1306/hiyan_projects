#!/bin/sh

#############
## Pre-Production
#############

git rm --cached .elasticbeanstalk/config.yml

# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Production only configuration files in
if [ -d ".elasticbeanstalk/extensions/staging" ]; then
    cp -R .elasticbeanstalk/extensions/staging/* ./.ebextensions/
fi

git add public/. --force
git add .ebextensions/*
HACKYFIXFORSTDERR="$(git commit -m "Pre-deploy PREPROD commit" 2>&1)"