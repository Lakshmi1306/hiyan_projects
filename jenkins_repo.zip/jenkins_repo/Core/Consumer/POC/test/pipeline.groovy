pipeline {
    agent any
    parameters {
        string(defaultValue: "master", description: 'Branch to Deploy', name: 'BRANCH')
    }
    stages {
        
        stage('Checkout') {
          steps {
            echo "${params.BRANCH}"
            git branch: "${params.BRANCH}",
            credentialsId: '1e66da07-96aa-481f-9425-f74e782bfce0',
            url: 'git@bitbucket.org:pbb_api/consumer.git'

          }
        }
        stage('List') {
              steps {
              sh """#!/bin/sh
              set -x
              ls -lat
              """
              }
        }
    }
}