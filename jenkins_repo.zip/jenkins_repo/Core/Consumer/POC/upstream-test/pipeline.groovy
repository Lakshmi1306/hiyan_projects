GITHUB_PROJECT = "git@bitbucket.org:pbb_api/consumer.git"
GITHUB_CREDENTIALS_ID = "1e66da07-96aa-481f-9425-f74e782bfce0" //maps to a Jenkins Credentials Vault ID
APPLICATION_NAME = "Consumer"
GITHUB_BRANCH = '${env.BRANCH_NAME}'
pipeline {
    agent any
    stages {
        stage ("Listing Branches") {
          steps {
            echo "Initializing workflow"
            //checkout code
            echo GITHUB_PROJECT
            git url: GITHUB_PROJECT, credentialsId: GITHUB_CREDENTIALS_ID
            sh 'git branch -r | awk \'{print $1}\' ORS=\'\\n\' >branches.txt'
            sh '''cut -d '/' -f 2 branches.txt > branch.txt'''
          }
        }
        stage('Get Build Branch') {
          steps {
              script {
                liste = readFile 'branch.txt'
                echo "please click on the link here to chose the branch to build"
                env.BRANCH_SCOPE = input message: 'Please choose the branch to build ', ok: 'Validate!',
                parameters: [choice(name: 'BRANCH_NAME', choices: "${liste}", description: 'Branch to build?')]

              }
          }
        }
        stage('Checkout') {
          steps {
            echo "${env.BRANCH_SCOPE}"
            git branch: "${env.BRANCH_SCOPE}",
            credentialsId: '1e66da07-96aa-481f-9425-f74e782bfce0',
            url: 'git@bitbucket.org:pbb_api/consumer.git'

          }
        }
        stage ('TriggerVerificationJob') {
            steps {
                build job: 'downstream-test', parameters: [[$class: 'GitParameterValue', name: 'Branch', value: "${env.BRANCH_SCOPE}"]]
            }
        }
    }
}