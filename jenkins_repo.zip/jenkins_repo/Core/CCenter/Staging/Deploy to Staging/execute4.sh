#!/bin/sh


######
## DEPLOYMENT
######

LOWERCASE_ENV="$(echo ${Environment} | tr '[:upper:]' '[:lower:]' 2>&1)"

echo "Now we are in the deployment"

APP_ENVIRONMENT="CCenter-${Environment}"
MEMCACHED_HOST="api-${LOWERCASE_ENV}"
CORE_API_HOST="https://api-${LOWERCASE_ENV}.puppyspot.com"
LEGACY_HOST="https://www.puppyspot.preprod"
AWS_BUCKET_POSTFIX="${LOWERCASE_ENV}"
CDN_URL="https://core-${LOWERCASE_ENV}.pupcdn.com/"

#if echo "${Environment}" | grep -q "Stage-01"; then
#	CLOUDSEARCH_BREED_DOMAIN="search-stage-01-breeds-gcnfcfavsorqaakmxavke6aorq.us-west-2.cloudsearch.amazonaws.com"
#	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="search-stage-01-external-listings-fuogjcvfjbitpr2ivt2wqzmcg4.us-west-2.cloudsearch.amazonaws.com"
#	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="search-stage-01-internal-listings-e67njuiw6amboix7azmpxzqr4m.us-west-2.cloudsearch.amazonaws.com"
#	LEGACY_HOST="https://www.puppyspot.stage01"
#fi

#if echo "${Environment}" | grep -q "Stage-02"; then
#	CLOUDSEARCH_BREED_DOMAIN="search-stage-02-breeds-xm32sklifupefp3dlmal6ho7my.us-west-2.cloudsearch.amazonaws.com"
#	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="search-stage-02-external-listings-ime4r67rr45yxu7cc6slejishq.us-west-2.cloudsearch.amazonaws.com"
#	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="search-stage-02-internal-listings-xrenjw2iphhquc6jprakuthgny.us-west-2.cloudsearch.amazonaws.com"
#	LEGACY_HOST="https://www.puppyspot.stage02"
#fi

#if echo "${Environment}" | grep -q "Stage-03"; then
#	CLOUDSEARCH_BREED_DOMAIN="search-stage-03-breeds-mfriu2eide3jb4vialcozgsdje.us-west-2.cloudsearch.amazonaws.com"
#	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="search-stage-03-external-listings-skc6hcfdruiii5igjzd47ona6u.us-west-2.cloudsearch.amazonaws.com"
#	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="search-stage-03-internal-listings-aqjfrblh42pbcfj2nhn6hjzi54.us-west-2.cloudsearch.amazonaws.com"
#	LEGACY_HOST="https://www.puppyspot.stage03"
#fi

#if echo "${Environment}" | grep -q "Stage-04"; then
#	CLOUDSEARCH_BREED_DOMAIN="search-stage-04-breeds-3y2w2tmdiwpv2b34sbajdws2im.us-west-2.cloudsearch.amazonaws.com"
#	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="search-stage-04-external-listings-tdzyorlwyhwiqyx4xh7uhgjjji.us-west-2.cloudsearch.amazonaws.com"
#	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="search-stage-04-internal-listings-oq7kpifmo45xymlajdvwctu2c4.us-west-2.cloudsearch.amazonaws.com"
#	LEGACY_HOST="https://www.puppyspot.stage04"
#fi

#if echo "${Environment}" | grep -q "UAT"; then
#	CLOUDSEARCH_BREED_DOMAIN="search-uat-breeds-m644j5gi2as3l3vppb267dpk4i.us-west-2.cloudsearch.amazonaws.com"
#	CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN="search-uat-external-listings-6q5p6pssdrc5df46s65a3gdfei.us-west-2.cloudsearch.amazonaws.com"
#	CLOUDSEARCH_INTERNAL_LISTING_DOMAIN="search-uat-internal-listings-z62lvb6gnvvzzabfkstvzzhrla.us-west-2.cloudsearch.amazonaws.com"
#	LEGACY_HOST="https://www.puppyspot.uat"
#fi


# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Staging only configuration files in
cp -R .elasticbeanstalk/extensions/staging/* ./.ebextensions/

sed -i 's/<---StageNameREPLACE-->/'"${APP_ENVIRONMENT}"'/g' .ebextensions/* > /dev/null

# Add the param for the location of the Core API Base URI:
echo "Setting Core API Base URI to ${CORE_API_HOST}"
echo "\n\nCORE_API_BASE_URI=${CORE_API_HOST}\n" >> .env.staging

# Add the params for the CloudSearch domain:
echo "\nCLOUDSEARCH_INTERNAL_LISTING_DOMAIN=https://${CLOUDSEARCH_INTERNAL_LISTING_DOMAIN}\n" >> .env.staging
echo "CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN=https://${CLOUDSEARCH_EXTERNAL_LISTING_DOMAIN}" >> .env.staging
echo "CLOUDSEARCH_BREED_DOMAIN=https://${CLOUDSEARCH_BREED_DOMAIN}\n" >> .env.staging

echo "\nAWS_MEDIA_BUCKET=puppyspot-photos-${AWS_BUCKET_POSTFIX}\nAWS_BREEDER_BUCKET=puppyspot-breeder-uploads-${AWS_BUCKET_POSTFIX}\n\n" >> .env.staging

# Add the params for other hosts and domains:
echo "\nLEGACY_HOST=${LEGACY_HOST}\n" >> .env.staging
echo "\nCOOKIE_DOMAIN=${COOKIE_DOMAIN}\n" >> .env.staging

# Add the param for the CDN URL:
echo "\nCDN_URL=${CDN_URL}\n" >> .env.staging

# Add the param for the location of the Core API Base URI:
echo "\nMEMCACHED_HOST=${MEMCACHED_HOST}.bjszcv.0001.usw2.cache.amazonaws.com\nMEMCACHED_PORT=11211\n\n" >> .env.staging

git add .env.staging

git add public/. --force
git add .ebextensions/*
git commit -m "Pre-deploy commit"

#
# Check if environment exists. If not, create it..
#
if eb status ${APP_ENVIRONMENT} | grep -q "ERROR: NotFoundError"; then
    echo "Environment \"${APP_ENVIRONMENT}\" does not exist. Creating... Expect 20 minute wait.\n";
    DEPLOYMENT="$(eb create ${APP_ENVIRONMENT} --cfg stage --timeout 30 2>&1)"
    if echo "${DEPLOYMENT}" | grep -q "Successfully launched environment"; then
        echo "Deployment+Creation SUCCEEDED!:: "
        echo "${DEPLOYMENT}"
    else
	    echo "Deployment+Creation FAILED!:: "
        echo "${DEPLOYMENT}"
        exit 1
    fi
    return;
fi

#
# Environment already exists. Just Deploy
#

eb use ${APP_ENVIRONMENT}
MYHOST=$(eb status ${APP_ENVIRONMENT} | grep "  CNAME: " | cut -f2 -d: | cut -f2 -d' ');

echo "host = http\://${MYHOST}" > host.properties

DEPLOYMENT="$(eb deploy --timeout 45 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "Deployment SUCCEEDED!:: "
    echo "${DEPLOYMENT}"
else
	echo "Deployment FAILED!:: "
    echo "${DEPLOYMENT}"
    exit 1
fi