#!/bin/sh

#############
## Production
#############

git rm --cached .elasticbeanstalk/config.yml

DEPLOYED_AT=`date '+%Y-%m-%d %H:%M:%S'`

# Add the param for the current branch and deploy time:
echo "Setting Variables for use with NewRelic Throttle"
echo "\nCURRENT_BRANCH=${Branch}\n" >> .env.production
echo "\nDEPLOYED_AT=\"${DEPLOYED_AT}\"\n" >> .env.production

git add .env.production

# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Production only configuration files in
if [ -d ".elasticbeanstalk/extensions/production" ]; then
    cp -R .elasticbeanstalk/extensions/production/* ./.ebextensions/
fi

git add public/. --force
git add .ebextensions/*
HACKYFIXFORSTDERR="$(git commit -m "Pre-deploy PROD commit" 2>&1)"