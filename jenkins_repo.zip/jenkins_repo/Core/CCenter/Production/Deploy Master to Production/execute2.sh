#!/bin/sh


#############
## Production
#############

eb use CCenter-prod
DEPLOYMENT="$(eb deploy --timeout 15 2>&1)"

if echo "${DEPLOYMENT}" | grep -q "Environment update completed successfully."; then
    echo "Production Deployment SUCCEEDED!:: "
else
	echo "Production Deployment FAILED!:: "
    echo "failures = Production Deployment FAILED" > failures.properties
    exit 1
fi