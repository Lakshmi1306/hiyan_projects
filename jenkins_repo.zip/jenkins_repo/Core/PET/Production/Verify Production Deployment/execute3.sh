#!/bin/sh

# Get child branches of master
# Loop through child branches of master and merge master into them (failed merges should be noted to be emailed out at the end, but continue)
GITSYNC="$(php ~/jenkinsgit/jenkinsgit.php -rPET -jFE --sync-feature-branches --source="${Branch}" 2>&1)"
if echo "${GITSYNC}" | grep -q "^success$"; then
    echo "All child branches synced successfully! Complete."
else
	echo "WARNING: Some child branches failed to merge:: "
    echo -e "${GITSYNC}"
    #FAILURE="$(echo -e \"${GITSYNC}\" | sed -e 's/$/\\/')"
    FAILURE="$(echo -e ${GITSYNC} | sed -e 's/$/<br>\\/')"
    echo "failures = ${FAILURE}" > failures.properties
fi