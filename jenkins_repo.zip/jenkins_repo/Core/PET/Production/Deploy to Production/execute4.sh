######
## DEPLOYMENT
######
cd ./jenkinsbuilddir

S3_DOMAIN="pet.puppyspot.com"
CORE_API_HOST="api"
MEDIA_HOST="photos.puppyspot.com"
CLOUDSEARCH_DOMAIN="search-prod-plm-listings-ocaszg37jivvujwpwaaypxkr2q.us-west-2.cloudsearch.amazonaws.com"


sed -i 's/<---S3_DOMAIN_REPLACE-->/'"${S3_DOMAIN}"'/g' ./package.json > /dev/null
sed -i 's/<---API_HOST_REPLACE-->/'"${CORE_API_HOST}"'/g' ./.env > /dev/null
sed -i 's/<---MEDIA_HOST_REPLACE-->/'"${MEDIA_HOST}"'/g' ./.env > /dev/null
sed -i 's/<---CLOUDSEARCH_DOMAIN_REPLACE-->/'"${CLOUDSEARCH_DOMAIN}"'/g' ./.env > /dev/null


export API_HOST="https://api.puppyspot.com"
export ASSETS_AWS_KEY="AKIAIWZOKYJBDNKWNQIA"
export ASSETS_AWS_SECRET="SLNo9XlfYsw5LvMNXPaEUna9yc3kzPVqy5GvxeTQ"
export ASSETS_BUCKET="pet.puppyspot.com"
export ASSETS_REGION="us-west-2"


# Build
npm install
npm run build

# Deploy
npm run deploy