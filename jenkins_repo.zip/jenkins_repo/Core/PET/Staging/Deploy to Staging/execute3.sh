######
## DEPLOYMENT
######
cd ./jenkinsbuilddir


LOWERCASE_ENV="$(echo ${Environment} | tr '[:upper:]' '[:lower:]' 2>&1)"
#echo "host = http\://${LOWERCASE_ENV}" > host.properties


export ASSETS_AWS_KEY="AKIAIWZOKYJBDNKWNQIA"
export ASSETS_AWS_SECRET="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"
export ASSETS_REGION="us-west-2"

if echo "${Environment}" | grep -q "Stage-01"; then
	S3_DOMAIN="pet-stage-01.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage01/leadtracker/";
    CONSUMER_DOMAIN="https://consumer-stage-01.puppyspot.com";
    CLOUDSEARCH_DOMAIN="search-stage-01-plm-listings-bqw5yjpz24z5333cwq6mzsbcuu.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "Stage-02"; then
	S3_DOMAIN="pet-stage-02.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage-02.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage02/leadtracker/";
    CLOUDSEARCH_DOMAIN="search-stage-02-plm-listings-y62silmnqa2hm6noqcegx46nti.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "Stage-03"; then
	S3_DOMAIN="pet-stage-03.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage-03.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage03/leadtracker/";
    CLOUDSEARCH_DOMAIN="search-stage-03-plm-listings-o56mbd5vglzj45na7mo4hs4sam.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "Stage-04"; then
	S3_DOMAIN="pet-stage-04.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage-04.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage04/leadtracker/";
    CLOUDSEARCH_DOMAIN="search-stage-04-plm-listings-7ms7yuoadfm36rw4fhc7zvka4a.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "Stage-05"; then
	S3_DOMAIN="pet-stage-05.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage-05.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage05/leadtracker/";
    CLOUDSEARCH_DOMAIN="search-stage-05-plm-listings-zjyqfzomcbrmbggltd567b52am.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "sandbox"; then
	S3_DOMAIN="pet-sandbox.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-sandbox.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.sandbox/leadtracker/";
    CLOUDSEARCH_DOMAIN="search-sandbox-plm-listings-kgm4cwkwhvia2niou2f6l5wgfe.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "Eng-01"; then
	S3_DOMAIN="pet-eng-01.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-eng-01.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage01/leadtracker/";
    CLOUDSEARCH_DOMAIN="search-eng-01-plm-listings-twdyveueooo6vu25ijuk3fwfwy.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "Eng-02"; then
	S3_DOMAIN="pet-eng-02.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-eng-02.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage02/leadtracker/";
    CLOUDSEARCH_DOMAIN="search-eng-02-plm-listings-vn4xi6cno6fr3ag5ilcecimmcq.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "green"; then
	S3_DOMAIN="pet-green.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-green.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.green/leadtracker/";
    CLOUDSEARCH_DOMAIN="search-green-plm-listings-ravxksmeq5wc6gvsg2ziav6cna.us-west-2.cloudsearch.amazonaws.com";
fi

if echo "${Environment}" | grep -q "load"; then
	S3_DOMAIN="pet-load.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-load.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.load/leadtracker/";
    CLOUDSEARCH_DOMAIN="search-load-plm-listings-byzeva5bckdd33to5jp5y2h7oq.us-west-2.cloudsearch.amazonaws.com";
fi
CORE_API_HOST="api-${LOWERCASE_ENV}"
MEDIA_HOST="puppyspot-photos-${LOWERCASE_ENV}.s3.us-west-2.amazonaws.com"

sed -i 's/<---S3_DOMAIN_REPLACE-->/'"${S3_DOMAIN}"'/g' ./package.json > /dev/null
sed -i 's/<---API_HOST_REPLACE-->/'"${CORE_API_HOST}"'/g' ./.env > /dev/null
sed -i 's/<---MEDIA_HOST_REPLACE-->/'"${MEDIA_HOST}"'/g' ./.env > /dev/null
sed -i 's/<---CLOUDSEARCH_DOMAIN_REPLACE-->/'"${CLOUDSEARCH_DOMAIN}"'/g' ./.env > /dev/null

export SEARCH_HOST="${CLOUDSEARCH_PLM_DOMAIN}"
export ASSETS_BUCKET="${S3_DOMAIN}"
export CONSUMER_DOMAIN="${CONSUMER_DOMAIN}"
export API_HOST="${CORE_API_HOST}"
export LEADTRACKER_HOST="${LEADTRACKER_DOMAIN}";

# Build
npm install
npm run build


# ToDo Unit test or other testing



# Deploy
npm run deploy