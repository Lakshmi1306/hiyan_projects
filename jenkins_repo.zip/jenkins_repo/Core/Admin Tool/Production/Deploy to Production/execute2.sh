#!/bin/sh
### Check that the branch going out is ahead of master

COMMITS="$(git rev-list --left-only --count origin/master...${Branch} 2>&1)"
if echo "${COMMITS}" | grep -q "^0$"; then
    echo "Branch cleared for delivery. SEND IT!:: "    
else
   echo "ERROR: Branch behind master. Branch must be QA Verified via stage deployment FIRST! Deployment Aborted.:: "
   echo "failures = ERROR: Branch behind master. Branch must be QA Verified via stage deployment FIRST! Deployment Aborted." > failures.properties
   exit 1
fi