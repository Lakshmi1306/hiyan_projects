#!/bin/sh

#############
## Production
#############

git rm --cached .elasticbeanstalk/config.yml

# FE STUFF
# Update required libs
npm cache clear
npm install

# Do frontend build
npm run production

# Copy Compiled assets
cp -R public/* ../public/

# Create ebextensions directory
mkdir -p .ebextensions
# Copy common configuration files in
cp -R .elasticbeanstalk/extensions/common/* ./.ebextensions/
# Copy Production only configuration files in
if [ -d ".elasticbeanstalk/extensions/production" ]; then
    cp -R .elasticbeanstalk/extensions/production/* ./.ebextensions/
fi

git add public/. --force
git add .ebextensions/*
HACKYFIXFORSTDERR="$(git commit -m "Pre-deploy PROD commit" 2>&1)"