#!/bin/sh

# Checkout master

CHECKOUT="$(git checkout master 2>&1)"
if echo "${CHECKOUT}" | grep -q "^Switched to [a new ]*branch 'master'"; then
    echo "Checked out master successfully, continuing:: "
else
	echo "ERROR: Failed to checkout master from origin:: "
    echo "${CHECKOUT}"
    echo "failures = ERROR: Failed to checkout master from origin" > failures.properties
    exit 1
fi

# Fetch origin headers
FETCH="$(git fetch 2>&1)"

# Pull master
PULL="$(git pull 2>&1)"