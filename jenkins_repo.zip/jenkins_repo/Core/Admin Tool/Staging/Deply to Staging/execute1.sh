#!/bin/sh

## Rebase current branch
COMMITS="$(git rev-list --left-only --count origin/master...${Branch} 2>&1)"
if echo "${COMMITS}" | grep -q "^0$"; then
    echo "Merge not neccessary, continuing:: "    
else
	MERGE="$(git merge origin/master 2>&1)"
	if echo "${MERGE}" | grep -q "Automatic merge failed"; then
    	echo "Merge FAILED!:: "
    	exit 1    
	else
		echo "Merge SUCCEEDED!:: "
	fi

	PUSH="$(git push origin ${Branch} 2>&1)"
	if echo "${PUSH}" | grep -q "${Branch} -> ${Branch}"; then
    	echo "Push SUCCEEDED!:: "
	elif echo "${PUSH}" | grep -q "Everything up-to-date"; then
    	echo "Push not necessary, continuing:: "
	else
		echo "Push FAILED!:: "
    	exit 1
	fi
fi