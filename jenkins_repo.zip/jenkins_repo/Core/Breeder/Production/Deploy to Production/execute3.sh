######
## DEPLOYMENT
######
cd ./jenkinsbuilddir

S3_DOMAIN="breeder.puppyspot.com"

sed -i 's/<---S3_DOMAIN_REPLACE-->/'"${S3_DOMAIN}"'/g' ./package.json > /dev/null

export API_HOST="https://api.puppyspot.com"
export ASSETS_AWS_KEY="AKIAIWZOKYJBDNKWNQIA"
export ASSETS_AWS_SECRET="SLNo9XlfYsw5LvMNXPaEUna9yc3kzPVqy5GvxeTQ"
export ASSETS_BUCKET="pet.puppyspot.com"
export ASSETS_REGION="us-west-2"

# Deploy
npm run deploy