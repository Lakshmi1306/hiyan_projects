#!/bin/sh
### Check that there are no pending PRs into master -- if there is, someone deployed but hasn't yet verified

PRS="$(php ~/jenkinsgit/jenkinsgit.php -rBREEDER --count-pull-requests --dest="master" 2>&1)"
echo "${PRS}"
if echo "${PRS}" | grep -q "^0$"; then
    echo "No pending pull requests, continuing:: "
else
	echo "ERROR: There are existing Pull Request(s) into master. Ensure the QA Verify step was performed. Halting."
    echo "failures = ERROR: There are existing Pull Request(s) into master. Ensure the QA Verify step was performed. Halting." > failures.properties
    exit 1
fi