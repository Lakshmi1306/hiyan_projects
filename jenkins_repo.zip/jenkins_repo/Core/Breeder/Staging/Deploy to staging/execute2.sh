#!/bin/sh

######
## BUILD/TEST
######
rm -R ./jenkinsbuilddir/ > /dev/null 2>&1

# Prepare build environment (dont change this, workaround to prevent stderr)
mkdir -p ../jenkinsbuilddir
cp -R . ../jenkinsbuilddir/
mv ../jenkinsbuilddir ./
cd ./jenkinsbuilddir


# Build
npm install
npm run build

