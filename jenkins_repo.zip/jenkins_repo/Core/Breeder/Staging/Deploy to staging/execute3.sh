######
## DEPLOYMENT
######
cd ./jenkinsbuilddir


LOWERCASE_ENV="$(echo ${Environment} | tr '[:upper:]' '[:lower:]' 2>&1)"
#echo "host = http\://${LOWERCASE_ENV}" > host.properties


export ASSETS_AWS_KEY="AKIAIWZOKYJBDNKWNQIA"
export ASSETS_AWS_SECRET="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"
export ASSETS_REGION="us-west-2"

if echo "${Environment}" | grep -q "Stage-01"; then
	CORE_API_HOST="https://api-stage-01.puppyspot.com"
	S3_DOMAIN="breeder-stage-01.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage01/leadtracker/";
    CONSUMER_DOMAIN="https://consumer-stage-01.puppyspot.com";
fi

if echo "${Environment}" | grep -q "Stage-02"; then
    CORE_API_HOST="https://api-stage-02.puppyspot.com"
	S3_DOMAIN="breeder-stage-02.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage-02.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage02/leadtracker/";
fi

if echo "${Environment}" | grep -q "Stage-03"; then
    CORE_API_HOST="https://api-stage-03.puppyspot.com"
	S3_DOMAIN="breeder-stage-03.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage-03.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage03/leadtracker/";
fi

if echo "${Environment}" | grep -q "Stage-04"; then
    CORE_API_HOST="https://api-stage-04.puppyspot.com"
	S3_DOMAIN="breeder-stage-04.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage-04.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage04/leadtracker/";
fi

if echo "${Environment}" | grep -q "Stage-05"; then
    CORE_API_HOST="https://api-stage-05.puppyspot.com"
	S3_DOMAIN="breeder-stage-05.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-stage-05.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage05/leadtracker/";
fi

if echo "${Environment}" | grep -q "sandbox"; then
    CORE_API_HOST="https://api-sandbox.puppyspot.com"
	S3_DOMAIN="breeder-sandbox.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-sandbox.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.sandbox/leadtracker/";
fi

if echo "${Environment}" | grep -q "Eng-01"; then
    CORE_API_HOST="https://api-eng-01.puppyspot.com"
	S3_DOMAIN="breeder-eng-01.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-eng-01.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage01/leadtracker/";
fi

if echo "${Environment}" | grep -q "Eng-02"; then
    CORE_API_HOST="https://api-eng-02.puppyspot.com"
	S3_DOMAIN="breeder-eng-02.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-eng-02.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.stage02/leadtracker/";
fi

if echo "${Environment}" | grep -q "green"; then
    CORE_API_HOST="https://api-green.puppyspot.com"
	S3_DOMAIN="breeder-green.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-green.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.green/leadtracker/";
fi

if echo "${Environment}" | grep -q "load"; then
    CORE_API_HOST="https://api-load.puppyspot.com"
	S3_DOMAIN="breeder-load.puppyspot.com";
    CONSUMER_DOMAIN="https://consumer-load.puppyspot.com";
    LEADTRACKER_DOMAIN="https://www.buypuppiesdirect.load/leadtracker/";
fi

sed -i 's/<---S3_DOMAIN_REPLACE-->/'"${S3_DOMAIN}"'/g' ./package.json > /dev/null

export ASSETS_BUCKET="${S3_DOMAIN}"
export CONSUMER_DOMAIN="${CONSUMER_DOMAIN}"
export API_HOST="${CORE_API_HOST}"
export LEADTRACKER_HOST="${LEADTRACKER_DOMAIN}";

# Deploy
npm run deploy