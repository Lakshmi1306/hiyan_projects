#!/bin/bash

# Update Hostfile
echo "Updating hostfile..."
sudo /bin/bash /scripts/update-hosts-file.sh
sudo /bin/bash /scripts/update-blue-green-inventory.sh

echo "Running playbook..."

cd /etc/ansible/playbooks

echo "Checking consumer..."
ansible-playbook -b -i /etc/ansible/inventories/Blue-Green/instances/consumer-hosts restartAWSlogs.yml

echo "Checking API..."
ansible-playbook -b -i /etc/ansible/inventories/Blue-Green/instances/API-hosts restartAWSlogs.yml


