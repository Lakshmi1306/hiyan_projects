#!/bin/bash


# Update Hostfile
echo "Updating hostfile..."
sudo /bin/bash /scripts/update-hosts-file.sh
sudo /bin/bash /scripts/update-blue-green-inventory.sh

Environment="API-${Environment}"

Substring='"stdout": "OK"'

echo "This is the Environment: ${Environment}"

echo "Running playbook..."

cd /etc/ansible/playbooks


success=false

while [ $success != true ]
do
        output=$(ansible-playbook -i /etc/ansible/inventories/API/instances/hosts refreshRedis.yml --extra-vars "target=$Environment")

        echo $output

        if echo "$output" | grep -q "$Substring"; then
                success=true
                exit 0
        else
                success=false
        fi

        echo $success

done