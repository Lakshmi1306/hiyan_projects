pipeline {
    agent any
    stages {
        
        
        stage('Environment Selection') {
            input {
                message "What Environment From Above do you want to update??"
                ok "UPDATE IT!"
                submitter "alice,bob"
                parameters {
                   // extendedChoice(name: 'ENVIRONMENT',multiSelectDelimiter:',', type:'PT_CHECKBOX', defaultValue: 'CCenter-Eng-01,CCenter-Eng-02', description: 'What ENV?')
                    string(name: 'KEY', defaultValue: 'DEFAULT_KEY', description: 'What Key do you want to update?')
                    string(name: 'VALUE', defaultValue: 'DEFAULT_VALUE', description: 'What Value do you want to update?')
                }
            }
            steps {
                sh '''#!/bin/bash
				set -e
				set -x
                IFS=',' read -ra environments <<< "$ENVIRONMENT"
                
                for env in "${environments[@]}"
                do
				echo "Updating Environment..."
				echo "3" | eb init --platform php
				eb use $env
				eb setenv $KEY=$VALUE
				
				echo "These are the new variables..."
				eb printenv
                done
				'''
            }
        }
    }
}