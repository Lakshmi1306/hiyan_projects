#!/bin/bash

LOWER_LAYER_NAME="$(echo ${LAYER_NAME} | tr '[:upper:]' '[:lower:]' 2>&1)"
LOWER_APPLICATION="$(echo ${APPLICATION} | tr '[:upper:]' '[:lower:]' 2>&1)"
LOWER_HOST_NAME="${LOWER_APPLICATION}-${LOWER_LAYER_NAME}"

LAYER_NUMBER="${LOWER_LAYER_NAME}"
if echo "${LOWER_LAYER_NAME}" | grep -q "stage-"; then
	LAYER_NUMBER="${LOWER_LAYER_NAME//[!0-9]/}"
fi

LEGACY_DOMAIN_SUFFIX="${LOWER_LAYER_NAME//-}"
sourceBeanstalk="${APPLICATION}-Stage-01"
destinationBeanstalk="${APPLICATION}-${LAYER_NAME}"
Environment="${LAYER_NAME}"
SQS_PREFIX="${Environment}"
AWS_BUCKET_POSTFIX="${LOWER_LAYER_NAME}"
AWS_SUFFIX="${LOWER_LAYER_NAME}"
CONSUMER_HOST="consumer-${LOWER_LAYER_NAME}"
REDIS_HOST="redis-cluster-${LAYER_NUMBER}.bjszcv.clustercfg.usw2.cache.amazonaws.com"
LEGACY_HOST="https://www.puppyspot.${LEGACY_DOMAIN_SUFFIX}"
CDN_URL="https://core-${LOWER_LAYER_NAME}.pupcdn.com/"
COOKIE_DOMAIN="${LOWER_HOST_NAME}.puppyspot.com"
CORE_API_RDS_HOST="api-${LOWER_LAYER_NAME}.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com"
API_HOST="api-${LOWER_LAYER_NAME}"
CONSUMER_HOST="consumer-${LOWER_LAYER_NAME}"
CORE_API_DOMAIN="https://${API_HOST}.puppyspot.com"
BEANSTALK_APPLICATION_NAME="pbbapi"
INSTANCE_TYPE="t2.small"
SOURCE_RDS_IDENTIFIER="${LOWER_HOST_NAME}"
RDS_INSTANCE_CLASS="db.t2.micro"
RDS_USER="pbbadmin"
RDS_PASSWORD="pbbsecret"
RDS_SIZE="5"
RDS_VERSION="5.6.35"


declare -a environmentVariables
environmentVariables+=("RDS_DB_NAME=ebdb")
environmentVariables+=("RDS_PASSWORD=${RDS_PASSWORD}")
environmentVariables+=("RDS_PORT=3306")
environmentVariables+=("RDS_USERNAME=${RDS_USER}")
environmentVariables+=("AWS_LOW_PRIORITY_JOB_QUEUE=${SQS_PREFIX}-Low-Priority-Queue")
environmentVariables+=("AWS_LOW_PRIORITY_JOB_DLQ=${SQS_PREFIX}-Low-Priority-DLQ")
environmentVariables+=("AWS_JOB_QUEUE=${SQS_PREFIX}-Job-Queue")
environmentVariables+=("AWS_JOB_DLQ=${SQS_PREFIX}-Job-DLQ")
environmentVariables+=("AWS_MAIL_QUEUE=${SQS_PREFIX}-Mail-Queue")
environmentVariables+=("AWS_MAIL_DLQ=${SQS_PREFIX}-Mail-DLQ")
environmentVariables+=("AWS_SEARCH_UPDATE_JOB_QUEUE=${SQS_PREFIX}-Search-Update-Job-Queue")
environmentVariables+=("AWS_SEARCH_UPDATE_JOB_DLQ=${SQS_PREFIX}-Search-Update-DLQ")
environmentVariables+=("AWS_LEAD_QUEUE=${SQS_PREFIX}-Lead-Queue")
environmentVariables+=("AWS_LEAD_DLQ=${SQS_PREFIX}-Lead-DLQ")
environmentVariables+=("AWS_IMAGE_PROCESSING_QUEUE=${SQS_PREFIX}-Image-Processing-Queue")
environmentVariables+=("AWS_IMAGE_PROCESSING_DLQ=${SQS_PREFIX}-Image-Processing-DLQ")
environmentVariables+=("AWS_TALLY_QUEUE=${SQS_PREFIX}-Tally-Queue")
environmentVariables+=("AWS_TALLY_DLQ=${SQS_PREFIX}-Tally-DLQ")
environmentVariables+=("AWS_MONITOR_JOB_QUEUE=${SQS_PREFIX}-Monitor-Job-Queue")
environmentVariables+=("AWS_MONITOR_JOB_DLQ=${SQS_PREFIX}-Monitor-Job-DLQ")
environmentVariables+=("AWS_ACCOUNTING_INTEGRATION_QUEUE=${SQS_PREFIX}-Accounting-Integration-Queue")
environmentVariables+=("AWS_ACCOUNTING_INTEGRATION_DLQ=${SQS_PREFIX}-Accounting-Integration-DLQ")
environmentVariables+=("AWS_CUSTOMER_CHAT_QUEUE=${SQS_PREFIX}-Customer-Chat-Queue")
environmentVariables+=("AWS_CUSTOMER_CHAT_DLQ=${SQS_PREFIX}-Customer-Chat-DLQ")
environmentVariables+=("AWS_ORDER_SYNC_QUEUE=${SQS_PREFIX}-Order-Sync-Queue")
environmentVariables+=("AWS_ORDER_SYNC_DLQ=${SQS_PREFIX}-Order-Sync-DLQ")
environmentVariables+=("AWS_CONSUMER_CACHE_QUEUE=${SQS_PREFIX}-Consumer-Cache-Queue")
environmentVariables+=("AWS_CONSUMER_CACHE_DLQ=${SQS_PREFIX}-Consumer-Cache-DLQ")
environmentVariables+=("AWS_LOGGING_QUEUE=${SQS_PREFIX}-Logging-Queue")
environmentVariables+=("AWS_LOGGING_DLQ=${SQS_PREFIX}-Logging-DLQ")


if echo "${LOWER_APPLICATION}" | grep -q "api"; then
    environmentVariables+=("AWS_MEDIA_BUCKET=puppyspot-photos-${AWS_BUCKET_POSTFIX}")
    environmentVariables+=("AWS_BREEDER_BUCKET=puppyspot-breeder-uploads-${AWS_BUCKET_POSTFIX}")
    environmentVariables+=("AWS_FILE_UPLOADS_BUCKET=puppyspot-files-${AWS_BUCKET_POSTFIX}")
    environmentVariables+=("CONSUMER_SITE_BASE_URL=https://consumer-${LOWER_LAYER_NAME}.puppyspot.com")
    environmentVariables+=("LEGACY_CONTACT_BASE_URL=https://www.puppyspot.${LEGACY_DOMAIN_SUFFIX}/api/core/contact/")
    environmentVariables+=("LEGACY_DOMAIN=www.puppyspot.${LEGACY_DOMAIN_SUFFIX}")
    environmentVariables+=("LEGACY_FORM_SUBMISSIONS_URL=https://www.puppyspot.${LEGACY_DOMAIN_SUFFIX}/api/core/lead/")
    environmentVariables+=("LEGACY_LEADTRACKER_BASE_URL=https://www.buypuppiesdirect.${LEGACY_DOMAIN_SUFFIX}/leadtracker")
    environmentVariables+=("LEGACY_PAYMENT_SYNCHRONIZATION_URL=https://www.puppyspot.${LEGACY_DOMAIN_SUFFIX}/api/core/payment/")
    environmentVariables+=("RDS_LEGACY_HOSTNAME=legacy-${LOWER_LAYER_NAME}.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com")
    environmentVariables+=("REDIS_HOST=${REDIS_HOST}")
    environmentVariables+=("RDS_HOSTNAME=${CORE_API_RDS_HOST}")
    environmentVariables+=("ACCESS_KEY=AKIASQFBDGMBOJDEX3EF")
    environmentVariables+=("APP_KEY=base64:YyDy1PYVkE2iX5wzK1OuVdVGcUK22NryYauoK8kRAXs")
    environmentVariables+=("APP_ENV=staging")
    environmentVariables+=("CLOUDWATCH_STREAM=${LOWER_LAYER_NAME}")
    environmentVariables+=("COMPOSER_HOME=/root")
    environmentVariables+=("LOGGING_AWS_ACCESS_KEY_ID=AKIAJCG432GF52O4C2PA")
    environmentVariables+=("LOGGING_AWS_SECRET_ACCESS_KEY=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")
    environmentVariables+=("MAIL_DRIVER=sendmail")
    environmentVariables+=("RDS_LEGACY_DB_NAME_BUYPUPPY_MANAGER=buypuppy_manager")
    environmentVariables+=("RDS_LEGACY_DB_NAME_BUYPUPPY_PUPPIES=buypuppy_puppies")
    environmentVariables+=("RDS_LEGACY_PASSWORD=LegacyPrePr0dAdmin01!")
    environmentVariables+=("RDS_LEGACY_PORT=3306")
    environmentVariables+=("RDS_LEGACY_USERNAME=psadmin")
    environmentVariables+=("REDIS_PORT=6379")
    environmentVariables+=("SECRET_KEY=0NrT1uonKwz2edzMWAo6cNn/xOBC40yA7Ad/8MSJ")
    
    INSTANCE_TYPE="t2.medium"
    RDS_INSTANCE_CLASS="db.t2.large"
    RDS_SIZE="200"
fi

if echo "${LOWER_APPLICATION}" | grep -q "consumer"; then
    environmentVariables+=("AWS_MEDIA_BUCKET=puppyspot-photos-${AWS_BUCKET_POSTFIX}")
    environmentVariables+=("AWS_BREEDER_BUCKET=puppyspot-breeder-uploads-${AWS_BUCKET_POSTFIX}")
    environmentVariables+=("CORE_API_BASE_URI=${CORE_API_DOMAIN}")
    environmentVariables+=("LEGACY_HOST=${LEGACY_HOST}")
    environmentVariables+=("COOKIE_DOMAIN=${COOKIE_DOMAIN}")
    environmentVariables+=("CDN_URL=${CDN_URL}")
    environmentVariables+=("REDIS_HOST=${REDIS_HOST}")
    environmentVariables+=("RDS_HOST=consumer-${LOWER_LAYER_NAME}.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com")
    environmentVariables+=("CLOUDWATCH_STREAM=${LOWER_LAYER_NAME}")
    environmentVariables+=("COMPOSER_HOME=/root")
    environmentVariables+=("LOGGING_AWS_ACCESS_KEY_ID=AKIAJCG432GF52O4C2PA")
    environmentVariables+=("LOGGING_AWS_SECRET_ACCESS_KEY=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")
    environmentVariables+=("REDIS_PORT=6379")
    environmentVariables+=("APP_ENV=staging")
    environmentVariables+=("APP_KEY=base64:YyDy1PYVkE2iX5wzK1OuVdVGcUK22NryYauoK8kRAXs")

	BEANSTALK_APPLICATION_NAME="consumer"
    INSTANCE_TYPE="t2.small"
    RDS_VERSION="5.5.61"
fi

if echo "${LOWER_APPLICATION}" | grep -q "cc"; then
    environmentVariables+=("AWS_MEDIA_BUCKET=puppyspot-photos-${AWS_BUCKET_POSTFIX}")
    environmentVariables+=("AWS_BREEDER_BUCKET=puppyspot-breeder-uploads-${AWS_BUCKET_POSTFIX}")
    environmentVariables+=("CORE_API_BASE_URI=${CORE_API_DOMAIN}")
    environmentVariables+=("LEGACY_CONTACT_BASE_URL=${LEGACY_HOST}/api/core/contact/")
    environmentVariables+=("RDS_HOST=${CORE_API_RDS_HOST}")
    environmentVariables+=("RDS_READ_REPLICA_HOSTNAME=${CORE_API_RDS_HOST}")
    environmentVariables+=("CONSUMER_SITE_BASE_URL=https://${CONSUMER_HOST}.39u6rtyj29.us-west-2.elasticbeanstalk.com")
    environmentVariables+=("APP_ENV=staging")
    environmentVariables+=("APP_KEY=base64:YyDy1PYVkE2iX5wzK1OuVdVGcUK22NryYauoK8kRAXs")
    environmentVariables+=("CLOUDWATCH_STREAM=${LOWER_LAYER_NAME}")
    environmentVariables+=("COMPOSER_HOME=/root")
    environmentVariables+=("LOGGING_AWS_ACCESS_KEY_ID=AKIAJCG432GF52O4C2PA")
    environmentVariables+=("LOGGING_AWS_SECRET_ACCESS_KEY=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")
    environmentVariables+=("REDIS_PORT=6379")
    environmentVariables+=("MAIL_DRIVER=smtp")
    environmentVariables+=("MAIL_FROM_ADDR=support@puppyspot.com")
    environmentVariables+=("MAIL_FROM_NAME=PuppySpot Support")
    environmentVariables+=("MAIL_HOST=puppyspot-com.mail.protection.outlook.com")
    environmentVariables+=("MAIL_PORT=25")

	INSTANCE_TYPE="t2.small"
fi

function joinBy { local IFS="$1"; shift; echo "$*"; }


##############  MAIN  #########################

# Not Needed right now, but might come back into play later.
#echo "Fetching latest RDS Snapshot ID..."
#rdsSnapshotId="$(aws rds describe-db-snapshots --db-instance-identifier ${SOURCE_RDS_IDENTIFIER} | jq -r '.DBSnapshots[-1].DBSnapshotIdentifier')"
#echo "Snapshot Id: ${snapshot_id}"


eb init $BEANSTALK_APPLICATION_NAME \
  --region us-west-2 \
  --profile eb-cli \
  --keyname ps_stage \
  --platform "64bit Amazon Linux 2016.03 v2.1.6 running PHP 7.0"

#if echo "${LOWER_APPLICATION}" | grep -q "cc"; then
  eb create ${destinationBeanstalk} \
    --cname ${LOWER_HOST_NAME} \
    --envvars "$(joinBy , "${environmentVariables[@]}")" \
    --instance_profile aws-elasticbeanstalk-ec2-stage \
    --keyname ps_stage \
    --platform "64bit Amazon Linux 2018.03 v2.8.6 running PHP 7.2" \
    --region us-west-2 \
    --single \
    --service-role aws-elasticbeanstalk-service-role
#else
#  eb create ${destinationBeanstalk} \
#    --cname ${LOWER_HOST_NAME} \
#    --envvars "$(joinBy , "${environmentVariables[@]}")" \
#    --instance_profile aws-elasticbeanstalk-ec2-stage \
#    --instance-types "${INSTANCE_TYPE}"
#    --keyname ps_stage \
#    --platform "64bit Amazon Linux 2018.03 v2.8.6 running PHP 7.2" \
#    --region us-west-2 \
#    --scale 1 \
#    --service-role aws-elasticbeanstalk-service-role \
#    --database \
#    --database.engine mysql \
#    --database.instance $RDS_INSTANCE_CLASS \
#    --database.password $RDS_PASSWORD \
#    --database.size $RDS_SIZE \
#    --database.version "${RDS_VERSION}"
#    --database.username $RDS_USER
#
#fi

echo "Beanstalk Creation process is copmlete"
