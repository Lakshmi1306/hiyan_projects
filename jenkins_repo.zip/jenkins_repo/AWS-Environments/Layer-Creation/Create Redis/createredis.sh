#!/bin/bash

LOWER_LAYER_NAME="$(echo ${LAYER_NAME} | tr '[:upper:]' '[:lower:]' 2>&1)"

LAYER_NUMBER="${LOWER_LAYER_NAME}"
if echo "${LOWER_LAYER_NAME}" | grep -q "stage-"; then
	LAYER_NUMBER="${LOWER_LAYER_NAME//[!0-9]/}"
fi
redisClusterName="redis-cluster-${LAYER_NUMBER}"
legacyRedisName="legacy-${LOWER_LAYER_NAME}"

aws elasticache create-replication-group \
  --replication-group-id $redisClusterName \
  --replication-group-description "Redis Cluster for the ${LAYER_NAME} Layer" \
  --num-node-groups 1 \
  --replicas-per-node-group 0 \
  --cache-node-type cache.t2.micro \
  --engine redis \
  --cache-parameter-group default.redis5.0.cluster.on \
  --engine-version 5.0.6 \
  --security-group-ids sg-008ea7f9ca204e8b7

echo "Redis Cluster ${redisClusterName} Created"


aws elasticache create-cache-cluster \
  --cache-cluster-id ${legacyRedisName} \
  --cache-node-type cache.t2.micro \
  --engine redis \
  --engine-version 3.2.4 \
  --num-cache-nodes 1 \
  --cache-parameter-group default.redis3.2 

echo "Legacy Redis ${legacyRedisName} Created"
