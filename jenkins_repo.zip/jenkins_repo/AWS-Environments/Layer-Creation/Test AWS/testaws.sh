#!/bin/bash
LAYER_NAME="$(echo ${LAYER_NAME} | tr '[:upper:]' '[:lower:]' 2>&1)"


#SECURITY_GROUP="$(aws ec2 describe-security-groups --group-names ${LAYER_NAME}-RDS | jq -r '.SecurityGroups[-1].GroupId')"

#if [ ! "${SECURITY_GROUP}"]; then
#	sleep 3
#    SECURITY_GROUP="no security group found"
#    SECURITY_GROUP="$(aws ec2 create-security-group --description 'Main RDS security group for the ${LAYER_NAME} layer' --group-name ${LAYER_NAME}-RDS --vpc-id vpc-611ee305 --no-dry-run | jq -r '.GroupId')"
#fi

# Main Constants
SUBNET_GROUP="default"
NEW_PASSWORD="secret!"
STATUS_AVAILABLE="available"

MASTER_IDENTIFIER="${APPLICATION}-stage-01"
INSTANCE_IDENTIFIER="${APPLICATION}-${LAYER_NAME}"

INSTANCE_CLASS="db.t2.micro"
if echo "${APPLICATION}" | grep -q "api"; then
    INSTANCE_CLASS="db.t2.large"    
fi

if echo "${APPLICATION}" | grep -q "legacy"; then
    INSTANCE_CLASS="db.t2.medium"    
fi

#echo "SG: ${SECURITY_GROUP}"
echo "LAYER: ${LAYER_NAME}"

#breedsIndex="atest-layer-breeds"

#Breeds Index
#breedDomain=`aws cloudsearch create-domain --domain-name ${breedsIndex} | jq -r ".DomainStatus.DomainName"`
#echo "================ This is the domain: ${breedDomain} ================ "

echo "something:  ${somethingEnabled}"