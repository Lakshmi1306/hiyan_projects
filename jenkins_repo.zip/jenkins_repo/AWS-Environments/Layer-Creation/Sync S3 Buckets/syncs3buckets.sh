#!/bin/bash

BUCKET_NAMES=("puppyspot-files" "puppyspot-breeder-uploads" "puppyspot-photos")
SOURCE_LAYER="stage-01"
LOWER_LAYER_NAME="$(echo ${LAYER_NAME} | tr '[:upper:]' '[:lower:]' 2>&1)"

for i in ${BUCKET_NAMES[@]}
do
	bucketName="${i}-${LOWER_LAYER_NAME}"
    sourceBucket="${i}-${SOURCE_LAYER}"
    
    echo "Syncing ${bucketName} ..."
    COPIED_FILES="$(aws configure set default.s3.max_concurrent_requests 200; aws s3 sync s3://${sourceBucket} s3://${bucketName})"
    echo "Finished Syncing ${bucketName}."
    
    sleep 3
done 

