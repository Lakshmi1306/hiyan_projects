pipeline {
    agent any
    stages {
		stage ('S3') {
			steps {
				build job: 'Create S3 Buckets', parameters: [[$class: 'StringParameterValue', name: 'LAYER_NAME', value: "${params.LAYER_NAME}"]], wait: false
				echo "Create S3 Buckets"
			}
		}
		stage ('SQS') {
			steps {
				build job: 'Create SQS Queues', parameters: [[$class: 'StringParameterValue', name: 'LAYER_NAME', value: "${params.LAYER_NAME}"]]
				echo "Create SQS Queues"
			}
		}
		stage ('Cloud Search') {
			steps {
				build job: 'Create CloudSearch Indexes', parameters: [[$class: 'StringParameterValue', name: 'LAYER_NAME', value: "${params.LAYER_NAME}"]]
				echo "Create CloudSearch Indexes"
			}
		}
		stage ('RDS') {
			steps {
				build job: 'Clone RDS', parameters: [[$class: 'StringParameterValue', name: 'APPLICATION', value: "api"], [$class: 'StringParameterValue', name: 'LAYER_NAME', value: "${params.LAYER_NAME}"]], wait: false
				build job: 'Clone RDS', parameters: [[$class: 'StringParameterValue', name: 'APPLICATION', value: "consumer"], [$class: 'StringParameterValue', name: 'LAYER_NAME', value: "${params.LAYER_NAME}"]], wait: false
				//build job: 'Clone RDS', parameters: [[$class: 'StringParameterValue', name: 'APPLICATION', value: "ccenter"], [$class: 'StringParameterValue', name: 'LAYER_NAME', value: "${params.LAYER_NAME}"]], wait: false
				build job: 'Clone RDS', parameters: [[$class: 'StringParameterValue', name: 'APPLICATION', value: "legacy"], [$class: 'StringParameterValue', name: 'LAYER_NAME', value: "${params.LAYER_NAME}"]]
				echo "Clone RDS x4"
			}
		}
		stage ('Redis') {
			steps {
				build job: 'Create Redis', parameters: [[$class: 'StringParameterValue', name: 'LAYER_NAME', value: "${params.LAYER_NAME}"]]
				echo "Create Redis Cluster"
			}
		}
		stage ('EB') {
			steps {
				//build job: 'Create Beanstalk', parameters: [[$class: 'StringParameterValue', name: 'APPLICATION', value: "API"], [$class: 'StringParameterValue', name: 'LAYER_NAME', value: "${params.LAYER_NAME}"]]
				//build job: 'Create Beanstalk', parameters: [[$class: 'StringParameterValue', name: 'APPLICATION', value: "CC"], [$class: 'StringParameterValue', name: 'LAYER_NAME', value: "${params.LAYER_NAME}"]], wait: false
				//build job: 'Create Beanstalk', parameters: [[$class: 'StringParameterValue', name: 'APPLICATION', value: "Legacy"], [$class: 'StringParameterValue', name: 'LAYER_NAME', value: "${params.LAYER_NAME}"]], wait: false
				build job: 'Clone Beanstalk', parameters: [[$class: 'StringParameterValue', name: 'APPLICATION', value: "Consumer"], [$class: 'StringParameterValue', name: 'LAYER_NAME', value: "${params.LAYER_NAME}"]]
				echo "Clone Beanstalk x4"
			}
		}
		// ToDo Add other tasks related to security groups or other misc things as they are discovered.
    }
    post {
		cleanup {
			deleteDir()
		}
    }
}
