#!/bin/bash

LAYER_NAME="$(echo ${LAYER_NAME} | tr '[:upper:]' '[:lower:]' 2>&1)"

SECURITY_GROUP="$(aws ec2 describe-security-groups --group-names ${LAYER_NAME}-RDS | jq -r '.SecurityGroups[-1].GroupId')"
SECURITY_GROUP_NAME="${LAYER_NAME}-RDS"
SECURITY_GROUP_DESCRIPTION="Main RDS security group for the ${LAYER_NAME} layer"

if [ ! "${SECURITY_GROUP}"]; then
	sleep 3
    SECURITY_GROUP="$(aws ec2 create-security-group \
      --group-name ${SECURITY_GROUP_NAME} \
      --description '${SECURITY_GROUP_DESCRIPTION}' \
      --vpc-id vpc-611ee305 \
      --no-dry-run \
      | jq -r '.GroupId')"
fi

# Main Constants
SUBNET_GROUP="default"
STATUS_AVAILABLE="available"

SOURCE_IDENTIFIER="${APPLICATION}-stage-01"
INSTANCE_IDENTIFIER="${APPLICATION}-${LAYER_NAME}"
PARAMETER_GROUP="uat-stage"

INSTANCE_CLASS="db.t2.micro"
if echo "${APPLICATION}" | grep -q "api"; then
    INSTANCE_CLASS="db.t2.large"    
fi


if echo "${APPLICATION}" | grep -q "consumer"; then
	PARAMETER_GROUP="default.mysql5.5"
fi

if echo "${APPLICATION}" | grep -q "legacy"; then
    INSTANCE_CLASS="db.t2.medium"
    PARAMETER_GROUP="legacy-database"
fi

function waitForStatus {
    instance=$1
    target_status=$2
    status="unknown"
    while [[ "$status" != "$target_status" ]]; do
        status="$(aws rds describe-db-instances --db-instance-identifier ${instance} | jq -r '.DBInstances[].DBInstanceStatus')"
        sleep 5
    done
}


# Main Logic
echo "Fetching latest Snapshot ID..."
snapshot_id="$(aws rds describe-db-snapshots --db-instance-identifier ${SOURCE_IDENTIFIER} | jq -r '.DBSnapshots[-1].DBSnapshotIdentifier')"
echo "Snapshot Id: ${snapshot_id}"

echo "Creating new database: $INSTANCE_IDENTIFIER"
STDOUT_FIX="$(aws rds restore-db-instance-from-db-snapshot \
  --db-instance-identifier ${INSTANCE_IDENTIFIER} \
  --db-snapshot-identifier ${snapshot_id} \
  --db-instance-class ${INSTANCE_CLASS} \
  --storage-type gp2 \
  --publicly-accessible \
  --no-multi-az \
  --no-auto-minor-version-upgrade \
  --vpc-security-group-ids ${SECURITY_GROUP} \
  --db-subnet-group-name ${SUBNET_GROUP} \
  --db-parameter-group-name "${PARAMETER_GROUP}" \
> /dev/null)"

# This should be added back in once the entire process can be automated.
#echo "Waiting for new DB instance ${INSTANCE_IDENTIFIER} to be available"
#waitForStatus $INSTANCE_IDENTIFIER $STATUS_AVAILABLE
#echo "Done."


echo "Clone process is copmlete"
