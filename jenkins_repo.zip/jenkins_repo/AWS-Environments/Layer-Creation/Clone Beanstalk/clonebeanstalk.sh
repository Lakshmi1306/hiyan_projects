#!/bin/bash

LOWER_LAYER_NAME="$(echo ${LAYER_NAME} | tr '[:upper:]' '[:lower:]' 2>&1)"
LOWER_APPLICATION="$(echo ${APPLICATION} | tr '[:upper:]' '[:lower:]' 2>&1)"
LOWER_HOST_NAME="${LOWER_APPLICATION}-${LOWER_LAYER_NAME}"

LEGACY_DOMAIN_SUFFIX="${LOWER_LAYER_NAME//-}"
sourceBeanstalk="${APPLICATION}-Stage-01"
destinationBeanstalk="${APPLICATION}-${LAYER_NAME}"
Environment="${LAYER_NAME}"
CORE_API_RDS_HOST="api-${LOWER_LAYER_NAME}.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com"
CORE_API_DOMAIN="https://${API_HOST}.puppyspot.com"
BEANSTALK_APPLICATION_NAME="legacy"
INSTANCE_TYPE="t2.medium"

declare -a environmentVariables
if echo "${LOWER_APPLICATION}" | grep -q "legacy"; then
    environmentVariables+=("API_URL=${CORE_API_DOMAIN}/api/")
    environmentVariables+=("CLOUDWATCH_STREAM=${LOWER_LAYER_NAME}")
    environmentVariables+=("RDS_HOSTNAME=legacy-${LOWER_LAYER_NAME}.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com")
    environmentVariables+=("REDIS_HOST=legacy-${LOWER_LAYER_NAME}.bjszcv.0001.usw2.cache.amazonaws.com")
fi

function joinByMulti { local d=$1; shift; echo -n "$1"; shift; printf "%s" "${@/#/$d}"; }


# =============== Main ===========================

eb init $BEANSTALK_APPLICATION_NAME \
  --region us-west-2 \
  --profile eb-cli \
  --keyname ps_stage \
  --platform "64bit Amazon Linux 2016.03 v2.1.6 running PHP 7.0"

eb use $sourceBeanstalk
eb clone $sourceBeanstalk -v -n $destinationBeanstalk --exact --timeout 20

eb use $destinationBeanstalk
eb setenv "$(joinByMulti ' ' "${environmentVariables[@]}")"


echo "Clone process is copmlete"
