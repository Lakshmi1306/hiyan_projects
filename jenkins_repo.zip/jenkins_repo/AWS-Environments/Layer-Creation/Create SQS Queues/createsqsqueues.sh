#!/bin/bash

QUEUE_NAMES=("Accounting-Integration" "Consumer-Cache" "Customer-Chat" "Image-Processing" "Job" "Lead" "Logging" "Low-Priority" "Mail" "Manual-Lead" "Monitor-Job" "Order-Sync" "Search-Update-Job" "Tally")

for i in ${QUEUE_NAMES[@]}
do
	queueName="${LAYER_NAME}-${i}-Queue"
    dlqName="${LAYER_NAME}-${i}-DLQ"
    
    echo "Creating ${queueName} and ${dlqName}"
    QUEUE_CREATED="$(aws sqs create-queue --queue-name ${queueName})"
    DLQ_CREATED="$(aws sqs create-queue --queue-name ${dlqName})"
    
    sleep 3
done 