#!/bin/bash

BUCKET_NAMES=("puppyspot-files" "puppyspot-breeder-uploads" "puppyspot-photos")
SPA_BUCKETS=("pet" "breeder")
SOURCE_LAYER="stage-01"
LOWER_LAYER_NAME="$(echo ${LAYER_NAME} | tr '[:upper:]' '[:lower:]' 2>&1)"

for i in ${SPA_BUCKETS[@]}
do
	bucketName="${i}-${LOWER_LAYER_NAME}.puppyspot.com"
    
    echo "Creating ${bucketName}"
    QUEUE_CREATED="$(aws s3api create-bucket --bucket ${bucketName} --acl public-read --create-bucket-configuration LocationConstraint=us-west-2)"
    HOSTING_ADDED="$(aws s3 website s3://${bucketName}/ --index-document index.html --error-document index.html)"
    
    sleep 3
done 

for i in ${BUCKET_NAMES[@]}
do
	bucketName="${i}-${LOWER_LAYER_NAME}"
    sourceBucket="${i}-${SOURCE_LAYER}"
    
    echo "Creating ${bucketName}"
    QUEUE_CREATED="$(aws s3api create-bucket --bucket ${bucketName} --acl public-read --create-bucket-configuration LocationConstraint=us-west-2)"
    COPIED_FILES="$(aws configure set default.s3.max_concurrent_requests 200; aws s3 sync s3://${sourceBucket} s3://${bucketName})"
    
    sleep 3
done 

