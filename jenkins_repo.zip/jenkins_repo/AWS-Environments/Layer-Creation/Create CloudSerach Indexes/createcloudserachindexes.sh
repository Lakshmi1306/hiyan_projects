#!/bin/bash
LAYER_NAME="$(echo ${LAYER_NAME} | tr '[:upper:]' '[:lower:]' 2>&1)"
echo "LAYER: ${LAYER_NAME}"

#index names
breedsIndex="${LAYER_NAME}-breeds"	
externalIndex="${LAYER_NAME}-external-listings"
internalIndex="${LAYER_NAME}-internal-listings"
plmIndex="${LAYER_NAME}-plm-listings"

  
declare -a breedFields
breedFields+=("about,text,null,null,true,true")
breedFields+=("breed_collection_ids,int-array,true,true,true,null")
breedFields+=("breed_collections,text-array,null,null,true,null")
breedFields+=("breed_energy,text,null,null,true,true")
breedFields+=("breed_energy_id,int,true,true,true,true")
breedFields+=("breed_id,int,true,true,true,true")
breedFields+=("breed_size,text,null,null,true,true")
breedFields+=("breed_size_id,int,true,true,true,true")
breedFields+=("breed_type,text,null,null,true,true")
breedFields+=("breed_type_id,int,true,true,true,true")
breedFields+=("card_image_url,text,null,null,true,true")
breedFields+=("coat,text,null,null,true,true")
breedFields+=("hero_image_url,text,null,null,true,true")
breedFields+=("media,text,null,null,true,true")
breedFields+=("name,text,null,null,true,true")
breedFields+=("origin,text,null,null,true,true")
breedFields+=("short_name,text,null,null,true,true")
breedFields+=("slug,text,null,null,true,true")
breedFields+=("stock_image_url,text,null,null,true,true")
breedFields+=("tags,text-array,null,null,true,null")
breedFields+=("trivia,text,null,null,true,true")
breedFields+=("weight_range_high,int,true,true,true,true")
breedFields+=("weight_range_low,int,true,true,true,true")

declare -a externalFields
externalFields+=("avg_parent_weight,double,true,true,true,true")
externalFields+=("breed_ad_label,text,null,null,true,true")
externalFields+=("breed_collection_ids,int-array,true,true,true,null")
externalFields+=("breed_collections,text-array,null,null,true,null")
externalFields+=("breed_id,int,true,true,true,true")
externalFields+=("breed_size,text,null,null,true,true")
externalFields+=("breed_size_id,int,true,true,true,true")
externalFields+=("breed_slug,text,null,null,true,true")
externalFields+=("breeder_puppy_name,text,null,null,false,true")
externalFields+=("can_travel,int,true,true,true,true")
externalFields+=("created_at,date,true,true,false,true")
externalFields+=("display_puppy_name,text,null,null,true,true")
externalFields+=("has_champion_lineage,int,true,true,true,true")
externalFields+=("has_traveled,int,true,true,true,true")
externalFields+=("has_video,int,true,true,true,true")
externalFields+=("inventory_status,text,null,null,true,true")
externalFields+=("inventory_status_id,int,true,true,true,true")
externalFields+=("is_featured,int,true,true,true,true")
externalFields+=("listed_at,date,true,true,false,true")
externalFields+=("listing_id,int,true,true,true,true")
externalFields+=("litter_birth_date,date,true,true,true,true")
externalFields+=("location,latlon,true,true,true,true")
externalFields+=("marketing_status,text,null,null,true,true")
externalFields+=("marketing_status_id,int,true,true,true,true")
externalFields+=("original_puppy_name,text,null,null,false,true")
externalFields+=("photo_url,text,null,null,true,true")
externalFields+=("price,double,true,true,true,true")
externalFields+=("puppy_color,text,null,null,true,true")
externalFields+=("puppy_color_family,text,null,null,true,true")
externalFields+=("puppy_color_family_id,int,true,true,true,true")
externalFields+=("puppy_color_id,int,true,true,true,true")
externalFields+=("puppy_description,text,null,null,true,true")
externalFields+=("puppy_gender,text,null,null,true,true")
externalFields+=("puppy_gender_id,int,true,true,true,true")
externalFields+=("puppy_id,int,true,true,true,true")
externalFields+=("puppy_name,text,null,null,true,true")
externalFields+=("puppy_reg_number,text,null,null,false,true")
externalFields+=("puppy_reg_numbers,text-array,null,null,true,null")
externalFields+=("puppy_registries,text-array,null,null,true,null")
externalFields+=("puppy_registry,text,null,null,true,true")
externalFields+=("puppy_registry_id,int,true,true,true,true")
externalFields+=("puppy_registry_ids,int-array,true,true,true,null")
externalFields+=("puppy_variety,text,null,null,true,true")
externalFields+=("puppy_variety_id,int,true,true,true,true")
externalFields+=("ribbon_hex_color,text,null,null,true,true")
externalFields+=("ribbon_tagline,text,null,null,true,true")
externalFields+=("search_sort_order,int,true,true,true,true")
externalFields+=("sort_group,int,true,true,true,true")
externalFields+=("variety_size_id,int,true,true,true,true")
externalFields+=("variety_size_name,text,null,null,true,true")
externalFields+=("video_url,text,null,null,true,true")
externalFields+=("videos,text,null,null,true,true")
externalFields+=("weight_range,text,null,null,true,true")
externalFields+=("weight_range_id,int,true,true,true,true")
externalFields+=("weight_range_max_oz,int,true,true,true,true")
externalFields+=("weight_range_min_oz,int,true,true,true,true")

declare -a internalFields
internalFields+=("account_rep,text,null,null,true,true")
internalFields+=("avg_parent_weight,double,true,true,true,true")
internalFields+=("breed_ad_label,text,null,null,true,true")
internalFields+=("breed_collection_ids,int-array,true,true,true,null")
internalFields+=("breed_collections,text-array,null,null,true,null")
internalFields+=("breed_id,int,true,true,true,true")
internalFields+=("breed_size,text,null,null,true,true")
internalFields+=("breed_size_id,int,true,true,true,true")
internalFields+=("breed_slug,text,null,null,true,true")
internalFields+=("breeder,text,null,null,true,true")
internalFields+=("breeder_company_name,text,null,null,true,true")
internalFields+=("breeder_id,int,true,true,true,true")
internalFields+=("breeder_puppy_name,text,null,null,true,true")
internalFields+=("breeder_state,text,null,null,true,true")
internalFields+=("breeder_state_id,int,true,true,true,true")
internalFields+=("can_travel,int,true,true,true,true")
internalFields+=("created_at,date,true,true,true,true")
internalFields+=("dam_breed,text,null,null,true,true")
internalFields+=("dam_breed_id,int,true,true,true,true")
internalFields+=("dam_id,int,true,true,true,true")
internalFields+=("dam_name,text,null,null,true,true")
internalFields+=("dam_ofa_certified,int,true,true,true,true")
internalFields+=("dam_personality,text,null,null,true,true")
internalFields+=("dam_registry,text,null,null,true,true")
internalFields+=("dam_weight_range,text,null,null,true,true")
internalFields+=("dam_weight_range_id,int,true,true,true,true")
internalFields+=("date_available,date,true,true,true,true")
internalFields+=("display_puppy_name,text,null,null,true,true")
internalFields+=("has_approved_photo,int,true,true,true,true")
internalFields+=("has_approved_video,int,true,true,true,true")
internalFields+=("has_champion_lineage,int,true,true,true,true")
internalFields+=("has_traveled,int,true,true,true,true")
internalFields+=("has_video,int,true,true,true,true")
internalFields+=("inventory_status,text,null,null,true,true")
internalFields+=("inventory_status_id,int,true,true,true,true")
internalFields+=("is_featured,int,true,true,true,true")
internalFields+=("known_health_issues,text,null,null,true,true")
internalFields+=("listed_at,date,true,true,true,true")
internalFields+=("listing_id,int,true,true,true,true")
internalFields+=("litter_birth_date,date,true,true,true,true")
internalFields+=("litter_food_brand,text,null,null,true,true")
internalFields+=("litter_id,int,true,true,true,true")
internalFields+=("location,latlon,true,true,true,true")
internalFields+=("marketing_status,text,null,null,true,true")
internalFields+=("marketing_status_id,int,true,true,true,true")
internalFields+=("medical_detail_ids,int-array,true,true,true,null")
internalFields+=("medical_details,text-array,null,null,true,null")
internalFields+=("needs_review,int,true,true,true,true")
internalFields+=("notes_internal,text,null,null,true,true")
internalFields+=("notes_to_breeder,text,null,null,true,true")
internalFields+=("notes_to_ps,text,null,null,true,true")
internalFields+=("original_puppy_name,text,null,null,true,true")
internalFields+=("photo_url,text,null,null,true,true")
internalFields+=("photos_posted,date,true,true,true,true")
internalFields+=("price,double,true,true,true,true")
internalFields+=("puppy_color,text,null,null,true,true")
internalFields+=("puppy_color_family,text,null,null,true,true")
internalFields+=("puppy_color_family_id,int,true,true,true,true")
internalFields+=("puppy_color_id,int,true,true,true,true")
internalFields+=("puppy_description,text,null,null,true,true")
internalFields+=("puppy_gender,text,null,null,true,true")
internalFields+=("puppy_gender_id,int,true,true,true,true")
internalFields+=("puppy_id,int,true,true,true,true")
internalFields+=("puppy_name,text,null,null,true,true")
internalFields+=("puppy_reg_number,text,null,null,true,true")
internalFields+=("puppy_reg_numbers,text-array,null,null,true,null")
internalFields+=("puppy_registries,text-array,null,null,true,null")
internalFields+=("puppy_registry,text,null,null,true,true")
internalFields+=("puppy_registry_id,int,true,true,true,true")
internalFields+=("puppy_registry_ids,int-array,true,true,true,null")
internalFields+=("puppy_variety,text,null,null,true,true")
internalFields+=("puppy_variety_id,int,true,true,true,true")
internalFields+=("ribbon_hex_color,text,null,null,true,true")
internalFields+=("ribbon_tagline,text,null,null,true,true")
internalFields+=("search_sort_order,int,true,true,true,true")
internalFields+=("sire_breed,text,null,null,true,true")
internalFields+=("sire_breed_id,int,true,true,true,true")
internalFields+=("sire_id,int,true,true,true,true")
internalFields+=("sire_name,text,null,null,true,true")
internalFields+=("sire_ofa_certified,int,true,true,true,true")
internalFields+=("sire_personality,text,null,null,true,true")
internalFields+=("sire_registry,text,null,null,true,true")
internalFields+=("sire_weight_range,text,null,null,true,true")
internalFields+=("sire_weight_range_id,int,true,true,true,true")
internalFields+=("sort_group,int,true,true,true,true")
internalFields+=("variety_size_id,int,true,true,true,true")
internalFields+=("variety_size_name,text,null,null,true,true")
internalFields+=("video_url,text,null,null,true,true")
internalFields+=("videos,text,null,null,true,true")
internalFields+=("weight_range,text,null,null,true,true")
internalFields+=("weight_range_id,int,true,true,true,true")
internalFields+=("weight_range_max_oz,int,true,true,true,true")
internalFields+=("weight_range_min_oz,int,true,true,true,true")

declare -a plmFields
plmFields+=("account_rep,text,null,null,true,true")
plmFields+=("assigned_user,text,null,null,true,true")
plmFields+=("breed_ad_label,text,null,null,true,true")
plmFields+=("breed_collection_ids,int-array,true,true,true,null")
plmFields+=("breed_collections,text-array,null,null,true,true")
plmFields+=("breeder,text,null,null,true,true")
plmFields+=("breeder_puppy_name,text,null,null,true,true")
plmFields+=("can_travel,int,true,true,true,true")
plmFields+=("dam_breed,text,null,null,true,true")
plmFields+=("dam_id,int,true,true,true,true")
plmFields+=("dam_name,text,null,null,true,true")
plmFields+=("display_puppy_name,text,null,null,true,true")
plmFields+=("has_approved_photo,int,true,true,true,true")
plmFields+=("has_approved_video,int,true,true,true,true")
plmFields+=("inventory_status,text,null,null,true,true")
plmFields+=("inventory_status_id,int,true,true,true,true")
plmFields+=("listing_id,int,true,true,true,true")
plmFields+=("listing_status,text,null,null,true,true")
plmFields+=("listing_status_id,int,true,true,true,true")
plmFields+=("litter_birth_date,date,true,true,true,true")
plmFields+=("litter_id,int,true,true,true,true")
plmFields+=("locked_by_user_id,int,true,true,true,true")
plmFields+=("marketing_status,text,null,null,true,true")
plmFields+=("marketing_status_id,int,true,true,true,true")
plmFields+=("needs_review,int,true,true,true,true")
plmFields+=("original_puppy_name,text,null,null,true,true")
plmFields+=("puppy_description,text,null,null,true,true")
plmFields+=("puppy_id,int,true,true,true,true")
plmFields+=("puppy_name,text,null,null,true,true")
plmFields+=("puppy_reg_numbers,text-array,null,null,true,null")
plmFields+=("puppy_registries,text-array,null,null,true,null")
plmFields+=("puppy_registry_ids,int-array,true,true,true,false")
plmFields+=("sire_breed,text,null,null,true,true")
plmFields+=("sire_id,int,true,true,true,true")
plmFields+=("sire_name,text,null,null,true,true")
plmFields+=("workflow_status,text,null,null,true,true")
plmFields+=("workflow_status_id,int,true,true,true,true")


function createIndexField {
	domain=$1
	field=$2
    
    OIFS="$IFS"
    IFS=',' read -a fieldDetails <<< "${field}"
    IFS="$OIFS"
    
    fieldName="${fieldDetails[0]}"
    fieldType="${fieldDetails[1]}"
    searchEnabled="${fieldDetails[2]}"
    facetEnabled="${fieldDetails[3]}"
    returnEnabled="${fieldDetails[4]}"
    sortEnabled="${fieldDetails[5]}"
    
    fieldOptions="--return-enabled ${returnEnabled}"
    if [ "${searchEnabled}" != "null" ]; then
    fieldOptions="${fieldOptions} --search-enabled ${searchEnabled}"
    fi
    
    if [ "${facetEnabled}" != "null" ]; then
    fieldOptions="${fieldOptions} --facet-enabled ${facetEnabled}"
    fi
    
    if [ "${sortEnabled}" != "null" ]; then
    fieldOptions="${fieldOptions} --sort-enabled ${sortEnabled}"
    fi
    
    aws cloudsearch define-index-field --domain-name $domain --name $fieldName --type $fieldType $fieldOptions
}


#================ MAIN =========================

#Breeds Index
breedDomain=`aws cloudsearch create-domain --domain-name ${breedsIndex} | jq -r ".DomainStatus.DomainName"`
echo "================ This is the domain: ${breedDomain} ================ "

aws cloudsearch update-service-access-policies \
  --domain-name $breedsIndex \
  --access-policies '{"Version": "2012-10-17", "Statement": [{ "Effect": "Allow", "Principal": {"AWS": "*"}, "Action": "cloudsearch:*"}]}'

echo "Access Policy Updated."

for field in "${breedFields[@]}"
do
	createIndexField $breedDomain $field
done
aws cloudsearch index-documents --domain-name $breedDomain

#External Index
externalDomain=`aws cloudsearch create-domain --domain-name ${externalIndex} | jq -r ".DomainStatus.DomainName"`
echo "================ This is the domain: ${externalDomain} ================ "

aws cloudsearch update-service-access-policies \
  --domain-name $externalIndex \
  --access-policies '{"Version": "2012-10-17", "Statement": [{ "Effect": "Allow", "Principal": {"AWS": "*"}, "Action": "cloudsearch:*"}]}'

echo "Access Policy Updated."

for field in "${externalFields[@]}"
do
	createIndexField $externalDomain $field
done
aws cloudsearch index-documents --domain-name $externalDomain


#Internal Index
internalDomain=`aws cloudsearch create-domain --domain-name ${internalIndex} | jq -r ".DomainStatus.DomainName"`
echo "================ This is the domain: ${internalDomain} ================ "

aws cloudsearch update-service-access-policies \
  --domain-name $internalIndex \
  --access-policies '{"Version": "2012-10-17", "Statement": [{ "Effect": "Allow", "Principal": {"AWS": "*"}, "Action": "cloudsearch:*"}]}'

echo "Access Policy Updated."

for field in "${internalFields[@]}"
do
	createIndexField $internalDomain $field
done
aws cloudsearch index-documents --domain-name $internalDomain

#PLM Index
plmDomain=`aws cloudsearch create-domain --domain-name ${plmIndex} | jq -r ".DomainStatus.DomainName"`
echo "================ This is the domain: ${plmDomain} ================ "

aws cloudsearch update-service-access-policies \
  --domain-name $plmIndex \
  --access-policies '{"Version": "2012-10-17", "Statement": [{ "Effect": "Allow", "Principal": {"AWS": "*"}, "Action": "cloudsearch:*"}]}'

echo "Access Policy Updated."

for field in "${plmFields[@]}"
do
	createIndexField $plmDomain $field
done
aws cloudsearch index-documents --domain-name $plmDomain

echo "Indexes Created Successfully!"
