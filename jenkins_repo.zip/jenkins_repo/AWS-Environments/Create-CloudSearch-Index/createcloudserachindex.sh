#!/bin/bash

cd /scripts/stage-creation/cloudsearch-creation

searchFacetReturnSort=("int" "double" "date" "latlon" "literal")
searchFacetReturn=("int-array" "date-array" "double-array" "literal-array")
returnSort=("text")
returnOnly=("text-array") 

function contains() {
    local n=$#
    local value=${!n}
    for ((i=1;i < $#;i++)) {
        if [ "${!i}" == "${value}" ]; then
            echo "y"
            return 0
        fi
    }
    echo "n"
    return 1
}


if [ "${searchGroup}" == 'all' ]
then
	domains=`aws cloudsearch describe-domains | jq -r ".DomainStatusList[].DomainName")`
else
	domains=`aws cloudsearch describe-domains | jq -r ".DomainStatusList[].DomainName" | grep "${searchGroup}"`
fi

# convert to array

domains=($domains)

for domain in "${domains[@]}"
do
	echo "================ This is domain: $domain ================ "
    
    if [ $(contains "${returnOnly[@]}" "${fieldType}") == "y" ]; then
	    aws cloudsearch define-index-field --domain-name $domain --name $fieldName --type $fieldType --return-enabled $returnEnabled
    elif [ $(contains "${returnSort[@]}" "${fieldType}") == "y" ]; then
	    aws cloudsearch define-index-field --domain-name $domain --name $fieldName --type $fieldType --return-enabled $returnEnabled --sort-enabled $sortEnabled
    elif [ $(contains "${searchFacetReturn[@]}" "${fieldType}") == "y" ]; then
	    aws cloudsearch define-index-field --domain-name $domain --name $fieldName --type $fieldType --search-enabled $searchEnabled --facet-enabled $facetEnabled --return-enabled $returnEnabled
    else
	    aws cloudsearch define-index-field --domain-name $domain --name $fieldName --type $fieldType --search-enabled $searchEnabled --facet-enabled $facetEnabled --return-enabled $returnEnabled --sort-enabled $sortEnabled
    fi
    
    aws cloudsearch index-documents --domain-name $domain
done




