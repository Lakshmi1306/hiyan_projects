#!/bin/bash

echo ""
echo ""
echo -e "============ PRODUCTION ============\n"
aws ec2 describe-instances | jq -r '.Reservations[].Instances[]|.PublicDnsName+ " : " + (.Tags[]?|select(.["Key"] == "Name")|.Value)' | grep -Ei 'prod|web|Worker|Admin|Core' | sort -t: -k2 | awk '{ t=$1 ; $1=$3; $3=t; print }' | uniq

echo -e "\n\n============ GREEN ============\n"
aws ec2 describe-instances | jq -r '.Reservations[].Instances[]|.PublicDnsName+ " : " + (.Tags[]?|select(.["Key"] == "Name")|.Value)' | grep -i green | sort -t: -k2 | awk '{ t=$1 ; $1=$3; $3=t; print }' | uniq

echo -e "\n\n============ STAGE ============\n"
aws ec2 describe-instances | jq -r '.Reservations[].Instances[]|.PublicDnsName+ " : " + (.Tags[]?|select(.["Key"] == "Name")|.Value)' | grep -i stage | sort -t: -k2 | awk '{ t=$1 ; $1=$3; $3=t; print }' | uniq

echo -e "\n\n============ ENG ============\n"
aws ec2 describe-instances | jq -r '.Reservations[].Instances[]|.PublicDnsName+ " : " + (.Tags[]?|select(.["Key"] == "Name")|.Value)' | grep -i eng | sort -t: -k2 | awk '{ t=$1 ; $1=$3; $3=t; print }' | uniq

echo -e "\n\n============ SANDBOX ============\n"
aws ec2 describe-instances | jq -r '.Reservations[].Instances[]|.PublicDnsName+ " : " + (.Tags[]?|select(.["Key"] == "Name")|.Value)' | grep -i sandbox | sort -t: -k2 | awk '{ t=$1 ; $1=$3; $3=t; print }' | uniq

echo -e "\n\n============ Jenkins ============\n"
aws ec2 describe-instances | jq -r '.Reservations[].Instances[]|.PublicDnsName+ " : " + (.Tags[]?|select(.["Key"] == "Name")|.Value)' | grep -i Jenkins | sort -t: -k2 | awk '{ t=$1 ; $1=$3; $3=t; print }' | uniq

echo -e "\n\n============ OTHER ============\n"
aws ec2 describe-instances | jq -r '.Reservations[].Instances[]|.PublicDnsName+ " : " + (.Tags[]?|select(.["Key"] == "Name")|.Value)' | grep -vi prod | grep -vi sandbox | grep -vi Admin | grep -vi Worker| grep -vi web| grep -vi stage | grep -vi Jenkins | grep -vi eng | grep -vi green | sort -t: -k2 | awk '{ t=$1 ; $1=$3; $3=t; print }' | uniq

echo -e "\n\n============ END ============\n"

echo ""
echo ""