#!/bin/bash

echo "!!! BUILD STARTING !!!"
cd /home/jenkinsSSHagent/mysql-binlogs

## CONSTANTS ##
results="$(mysql -hapi-production-read1.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com -u"${mysql_user}" -p"${mysql_pass}" -Bse 'SHOW BINARY LOGS')"
length=`mysql -hapi-production-read1.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com -u"${mysql_user}" -p"${mysql_pass}" -Bse 'SHOW BINARY LOGS' | wc -l`
directory_name="logs_one"


## PROGRAM START ##

echo "Checking to ensure there is enough space in the drive..."
space=$(df -h | awk 'FNR == 4 {print $4}')
space_available=$(echo "${space//G}")

if [ space_available > 11 ]
then 
	echo "There is enough space (greater than 11 GBs)...continuing..."
    echo "Retrieving files..."
	i=1
	loop_count=1

	while [ $loop_count -lt $length ]
	do

			binlog=$(echo $results | awk -v num="$i" '{print $num}')
			mysqlbinlog --read-from-remote-server --host=api-production-read1.cfmb9lsgwuwk.us-west-2.rds.amazonaws.com --port=3306 --base64-output=DECODE-ROWS --verbose --user "${mysql_user}" --password="${mysql_pass}"  --result-file=/home/jenkinsSSHagent/mysql-binlogs/$directory_name/$binlog "$binlog" &>/dev/null
			timestamp=$(cat /home/jenkinsSSHagent/mysql-binlogs/$directory_name/$binlog | awk 'FNR == 7 {print $1,$2}')
			timestamp=$(echo $timestamp | tr -d '#' | tr  ' ' '-')
            
            cd /home/jenkinsSSHagent/mysql-binlogs/$directory_name
            mv $binlog $timestamp-$binlog.txt
            
			((i=i+2))  # I needed to iterate num for every odd number to represent every other element in the $results string
			((loop_count=loop_count+1)) 
	done
    
    cd /home/jenkinsSSHagent/mysql-binlogs

	echo "Zipping Directory..."
	zip -r core-logs.zip logs_one &>/dev/null

	echo "S3 Step..."
	bucket=$(aws s3 ls | grep binlog | awk '{print $3}')
	if [ ! -z "$bucket" ]
	then
		echo "Removing old data..."
		aws s3 rm s3://binlog-data --recursive
		echo "Uploading data to bucket..."
		aws s3 cp core-logs.zip s3://binlog-data
	else
		echo "Bucket doesn't exist, contact Systems Engineering to create binlog-data bucket."
        exit 1
	fi

	echo "REMOVING LOCAL DATA..."
	rm -rf core-logs.zip
	cd logs_one
	rm -rf mysql*

	echo "!!! BUILD COMPLETE !!!"
	exit 0
else
	echo "Not enough space on the drive. Please contact Systems Engineering to clear space on Jenkins-Tertiary node."
	echo "Program requires a minimum of 8GB's available to run."
    exit 1
fi